# KGEditorWay - Part 5: Apache AGE Integration

## 🎯 Overview

Complete integration with **Apache AGE** (Apache Graph Extension) for PostgreSQL, enabling:
- Visual knowledge graph editing
- Cypher query building
- Bi-directional sync between UI and AGE
- Query result visualization
- Pre-built knowledge graph templates

---

## 📦 Project Structure

```
BahyWay.KGEditorWay.Infrastructure.AGE/
├── Client/
│   ├── AgeGraphClient.cs              # PostgreSQL + AGE connection
│   ├── AgeConnectionFactory.cs        # Connection pooling
│   └── AgeConfiguration.cs            # Configuration
├── Cypher/
│   ├── CypherQueryBuilder.cs          # Fluent Cypher builder
│   ├── CypherQueryParser.cs           # Parse Cypher strings
│   └── CypherQueryValidator.cs        # Validate queries
├── Converters/
│   ├── GraphToAgeConverter.cs         # Visual graph → AGE
│   ├── AgeToGraphConverter.cs         # AGE → Visual graph
│   └── ResultSetToGraphConverter.cs   # Query results → Visual
├── Repositories/
│   ├── KnowledgeGraphRepository.cs    # CRUD for knowledge graphs
│   └── GraphSchemaRepository.cs       # Schema management
├── Templates/
│   ├── IGraphTemplate.cs              # Template interface
│   ├── OrgChartTemplate.cs            # Organization hierarchy
│   ├── ProductCatalogTemplate.cs      # Product categories
│   └── NetworkTopologyTemplate.cs     # Network graph
└── Services/
    ├── GraphSyncService.cs            # Bi-directional sync
    └── QueryExecutionService.cs       # Execute Cypher queries
```

---

## 🔌 Apache AGE Client

### AgeGraphClient.cs

```csharp
// Infrastructure/AGE/Client/AgeGraphClient.cs
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Npgsql;
using BahyWay.SharedKernel.Results;

namespace BahyWay.KGEditorWay.Infrastructure.AGE.Client;

/// <summary>
/// Client for interacting with Apache AGE (A Graph Extension for PostgreSQL).
/// </summary>
public interface IAgeGraphClient
{
    Task<Result<AgeQueryResult>> ExecuteQueryAsync(string cypherQuery, Dictionary<string, object>? parameters = null);
    Task<r> CreateGraphAsync(string graphName);
    Task<r> DropGraphAsync(string graphName);
    Task<Result<List<string>>> ListGraphsAsync();
    Task<r> CreateLabelAsync(string graphName, string labelName, bool isVertex);
}

public class AgeGraphClient : IAgeGraphClient, IDisposable
{
    private readonly NpgsqlConnection _connection;
    private readonly string _defaultGraphName;
    
    public AgeGraphClient(string connectionString, string defaultGraphName = "knowledge_graph")
    {
        _connection = new NpgsqlConnection(connectionString);
        _defaultGraphName = defaultGraphName;
    }
    
    public async Task<r> OpenAsync()
    {
        try
        {
            await _connection.OpenAsync();
            
            // Load AGE extension
            await ExecuteSqlAsync("CREATE EXTENSION IF NOT EXISTS age;");
            await ExecuteSqlAsync("LOAD 'age';");
            await ExecuteSqlAsync("SET search_path = ag_catalog, \"$user\", public;");
            
            return Result.Success();
        }
        catch (Exception ex)
        {
            return Result.Failure(new Error("AGE.ConnectionFailed", ex.Message));
        }
    }
    
    public async Task<Result<AgeQueryResult>> ExecuteQueryAsync(
        string cypherQuery,
        Dictionary<string, object>? parameters = null)
    {
        try
        {
            if (_connection.State != System.Data.ConnectionState.Open)
            {
                await OpenAsync();
            }
            
            // Wrap Cypher query in AGE's cypher function
            var sql = $@"
                SELECT * FROM cypher('{_defaultGraphName}', $$
                    {cypherQuery}
                $$) as (result agtype);";
            
            await using var cmd = new NpgsqlCommand(sql, _connection);
            
            // Add parameters if provided
            if (parameters != null)
            {
                foreach (var param in parameters)
                {
                    cmd.Parameters.AddWithValue(param.Key, param.Value);
                }
            }
            
            var results = new List<Dictionary<string, object>>();
            
            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                var row = new Dictionary<string, object>();
                
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    var fieldName = reader.GetName(i);
                    var value = reader.GetValue(i);
                    row[fieldName] = value;
                }
                
                results.Add(row);
            }
            
            return Result.Success(new AgeQueryResult
            {
                Rows = results,
                RowCount = results.Count
            });
        }
        catch (Exception ex)
        {
            return Result.Failure<AgeQueryResult>(
                new Error("AGE.QueryFailed", ex.Message));
        }
    }
    
    public async Task<r> CreateGraphAsync(string graphName)
    {
        try
        {
            var sql = $"SELECT create_graph('{graphName}');";
            await ExecuteSqlAsync(sql);
            return Result.Success();
        }
        catch (Exception ex)
        {
            return Result.Failure(new Error("AGE.CreateGraphFailed", ex.Message));
        }
    }
    
    public async Task<r> DropGraphAsync(string graphName)
    {
        try
        {
            var sql = $"SELECT drop_graph('{graphName}', true);";
            await ExecuteSqlAsync(sql);
            return Result.Success();
        }
        catch (Exception ex)
        {
            return Result.Failure(new Error("AGE.DropGraphFailed", ex.Message));
        }
    }
    
    public async Task<Result<List<string>>> ListGraphsAsync()
    {
        try
        {
            var sql = "SELECT name FROM ag_catalog.ag_graph;";
            var graphs = new List<string>();
            
            await using var cmd = new NpgsqlCommand(sql, _connection);
            await using var reader = await cmd.ExecuteReaderAsync();
            
            while (await reader.ReadAsync())
            {
                graphs.Add(reader.GetString(0));
            }
            
            return Result.Success(graphs);
        }
        catch (Exception ex)
        {
            return Result.Failure<List<string>>(
                new Error("AGE.ListGraphsFailed", ex.Message));
        }
    }
    
    public async Task<r> CreateLabelAsync(string graphName, string labelName, bool isVertex)
    {
        try
        {
            var labelType = isVertex ? "VERTEX" : "EDGE";
            var sql = $"SELECT create_vlabel('{graphName}', '{labelName}');";
            
            if (!isVertex)
            {
                sql = $"SELECT create_elabel('{graphName}', '{labelName}');";
            }
            
            await ExecuteSqlAsync(sql);
            return Result.Success();
        }
        catch (Exception ex)
        {
            return Result.Failure(new Error("AGE.CreateLabelFailed", ex.Message));
        }
    }
    
    private async Task ExecuteSqlAsync(string sql)
    {
        await using var cmd = new NpgsqlCommand(sql, _connection);
        await cmd.ExecuteNonQueryAsync();
    }
    
    public void Dispose()
    {
        _connection?.Dispose();
    }
}

public class AgeQueryResult
{
    public List<Dictionary<string, object>> Rows { get; set; } = new();
    public int RowCount { get; set; }
}
```

---

## 🔨 Cypher Query Builder

### CypherQueryBuilder.cs

```csharp
// Infrastructure/AGE/Cypher/CypherQueryBuilder.cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BahyWay.KGEditorWay.Infrastructure.AGE.Cypher;

/// <summary>
/// Fluent builder for Cypher queries.
/// </summary>
public class CypherQueryBuilder
{
    private readonly List<string> _matchClauses = new();
    private readonly List<string> _whereClauses = new();
    private readonly List<string> _returnClauses = new();
    private readonly List<string> _createClauses = new();
    private readonly List<string> _mergeClauses = new();
    private readonly List<string> _setClauses = new();
    private readonly List<string> _deleteClauses = new();
    private readonly List<string> _orderByClauses = new();
    private readonly Dictionary<string, object> _parameters = new();
    private int? _skip;
    private int? _limit;
    
    public CypherQueryBuilder Match(string pattern)
    {
        _matchClauses.Add($"MATCH {pattern}");
        return this;
    }
    
    public CypherQueryBuilder OptionalMatch(string pattern)
    {
        _matchClauses.Add($"OPTIONAL MATCH {pattern}");
        return this;
    }
    
    public CypherQueryBuilder Where(string condition)
    {
        _whereClauses.Add(condition);
        return this;
    }
    
    public CypherQueryBuilder Return(params string[] expressions)
    {
        _returnClauses.AddRange(expressions);
        return this;
    }
    
    public CypherQueryBuilder Create(string pattern)
    {
        _createClauses.Add($"CREATE {pattern}");
        return this;
    }
    
    public CypherQueryBuilder Merge(string pattern)
    {
        _mergeClauses.Add($"MERGE {pattern}");
        return this;
    }
    
    public CypherQueryBuilder Set(string property, object value)
    {
        _setClauses.Add($"SET {property} = ${_parameters.Count}");
        _parameters[$"p{_parameters.Count}"] = value;
        return this;
    }
    
    public CypherQueryBuilder Delete(params string[] variables)
    {
        _deleteClauses.AddRange(variables.Select(v => $"DELETE {v}"));
        return this;
    }
    
    public CypherQueryBuilder DetachDelete(params string[] variables)
    {
        _deleteClauses.AddRange(variables.Select(v => $"DETACH DELETE {v}"));
        return this;
    }
    
    public CypherQueryBuilder OrderBy(string expression, bool descending = false)
    {
        var direction = descending ? "DESC" : "ASC";
        _orderByClauses.Add($"{expression} {direction}");
        return this;
    }
    
    public CypherQueryBuilder Skip(int count)
    {
        _skip = count;
        return this;
    }
    
    public CypherQueryBuilder Limit(int count)
    {
        _limit = count;
        return this;
    }
    
    public CypherQueryBuilder WithParameter(string name, object value)
    {
        _parameters[name] = value;
        return this;
    }
    
    public string Build()
    {
        var query = new StringBuilder();
        
        // MATCH clauses
        if (_matchClauses.Any())
        {
            query.AppendLine(string.Join("\n", _matchClauses));
        }
        
        // CREATE clauses
        if (_createClauses.Any())
        {
            query.AppendLine(string.Join("\n", _createClauses));
        }
        
        // MERGE clauses
        if (_mergeClauses.Any())
        {
            query.AppendLine(string.Join("\n", _mergeClauses));
        }
        
        // WHERE clause
        if (_whereClauses.Any())
        {
            query.AppendLine($"WHERE {string.Join(" AND ", _whereClauses)}");
        }
        
        // SET clauses
        if (_setClauses.Any())
        {
            query.AppendLine(string.Join("\n", _setClauses));
        }
        
        // DELETE clauses
        if (_deleteClauses.Any())
        {
            query.AppendLine(string.Join("\n", _deleteClauses));
        }
        
        // RETURN clause
        if (_returnClauses.Any())
        {
            query.AppendLine($"RETURN {string.Join(", ", _returnClauses)}");
        }
        
        // ORDER BY clause
        if (_orderByClauses.Any())
        {
            query.AppendLine($"ORDER BY {string.Join(", ", _orderByClauses)}");
        }
        
        // SKIP
        if (_skip.HasValue)
        {
            query.AppendLine($"SKIP {_skip.Value}");
        }
        
        // LIMIT
        if (_limit.HasValue)
        {
            query.AppendLine($"LIMIT {_limit.Value}");
        }
        
        return query.ToString().Trim();
    }
    
    public Dictionary<string, object> GetParameters() => _parameters;
}

// Example usage:
public static class CypherQueryExamples
{
    public static string FindPersonByName()
    {
        return new CypherQueryBuilder()
            .Match("(p:Person)")
            .Where("p.name = $name")
            .Return("p")
            .Build();
        // Result: MATCH (p:Person)
        //         WHERE p.name = $name
        //         RETURN p
    }
    
    public static string FindOrgChart()
    {
        return new CypherQueryBuilder()
            .Match("(ceo:Person {title: 'CEO'})")
            .Match("(ceo)-[:MANAGES*]->(employee:Person)")
            .Return("ceo", "employee")
            .OrderBy("employee.name")
            .Build();
    }
    
    public static string CreatePersonWithRelationship()
    {
        return new CypherQueryBuilder()
            .Create("(p:Person {name: $name, email: $email})")
            .Create("(p)-[:WORKS_IN]->(d:Department {name: $dept})")
            .Return("p", "d")
            .Build();
    }
    
    public static string FindShortestPath()
    {
        return new CypherQueryBuilder()
            .Match("p = shortestPath((start:Person {name: $startName})-[*]-(end:Person {name: $endName}))")
            .Return("p", "length(p) as pathLength")
            .Build();
    }
}
```

---

## 🔄 Graph Converters

### GraphToAgeConverter.cs

```csharp
// Infrastructure/AGE/Converters/GraphToAgeConverter.cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BahyWay.SharedKernel.Results;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.KGEditorWay.Infrastructure.AGE.Converters;

public interface IGraphToAgeConverter
{
    Task<Result<string>> ConvertToCypherAsync(Graph graph);
    Task<r> SyncGraphToAgeAsync(Graph graph, IAgeGraphClient client);
}

public class GraphToAgeConverter : IGraphToAgeConverter
{
    public async Task<Result<string>> ConvertToCypherAsync(Graph graph)
    {
        try
        {
            var cypherStatements = new List<string>();
            
            // Create nodes
            foreach (var node in graph.Nodes)
            {
                var properties = ConvertPropertiesToCypherMap(node.Properties);
                var label = GetNodeLabel(node.Type);
                
                var cypher = $"CREATE (n{node.Id.Value.ToString().Replace("-", "")}:{label} {properties})";
                cypherStatements.Add(cypher);
            }
            
            // Create relationships
            foreach (var edge in graph.Edges)
            {
                var sourceNodeVar = $"n{edge.SourceNodeId.Value.ToString().Replace("-", "")}";
                var targetNodeVar = $"n{edge.TargetNodeId.Value.ToString().Replace("-", "")}";
                var relType = GetRelationshipType(edge.Type);
                var properties = ConvertPropertiesToCypherMap(edge.Properties);
                
                var cypher = $"CREATE ({sourceNodeVar})-[:{relType} {properties}]->({targetNodeVar})";
                cypherStatements.Add(cypher);
            }
            
            var fullCypher = string.Join("\n", cypherStatements);
            return Result.Success(fullCypher);
        }
        catch (Exception ex)
        {
            return Result.Failure<string>(
                new Error("Converter.ConversionFailed", ex.Message));
        }
    }
    
    public async Task<r> SyncGraphToAgeAsync(Graph graph, IAgeGraphClient client)
    {
        try
        {
            // Clear existing graph data
            var clearQuery = new CypherQueryBuilder()
                .Match("(n)")
                .DetachDelete("n")
                .Build();
            
            await client.ExecuteQueryAsync(clearQuery);
            
            // Create all nodes
            foreach (var node in graph.Nodes)
            {
                var label = GetNodeLabel(node.Type);
                var properties = node.Properties.ToDictionary(p => p.Key, p => p.Value);
                properties["_visual_x"] = node.Position.X;
                properties["_visual_y"] = node.Position.Y;
                properties["_visual_id"] = node.Id.Value.ToString();
                
                var createNode = new CypherQueryBuilder()
                    .Create($"(n:{label})")
                    .Build();
                
                var result = await client.ExecuteQueryAsync(createNode);
                
                if (result.IsFailure)
                    return Result.Failure(result.Error);
                
                // Set properties
                foreach (var prop in properties)
                {
                    var setQuery = new CypherQueryBuilder()
                        .Match($"(n:{label})")
                        .Where($"n._visual_id = '{node.Id.Value}'")
                        .Set($"n.{prop.Key}", prop.Value)
                        .Build();
                    
                    await client.ExecuteQueryAsync(setQuery);
                }
            }
            
            // Create all relationships
            foreach (var edge in graph.Edges)
            {
                var relType = GetRelationshipType(edge.Type);
                var sourceNode = graph.Nodes.First(n => n.Id == edge.SourceNodeId);
                var targetNode = graph.Nodes.First(n => n.Id == edge.TargetNodeId);
                
                var createRel = new CypherQueryBuilder()
                    .Match($"(source)")
                    .Where($"source._visual_id = '{sourceNode.Id.Value}'")
                    .Match($"(target)")
                    .Where($"target._visual_id = '{targetNode.Id.Value}'")
                    .Create($"(source)-[r:{relType}]->(target)")
                    .Build();
                
                var result = await client.ExecuteQueryAsync(createRel);
                
                if (result.IsFailure)
                    return Result.Failure(result.Error);
                
                // Set relationship properties
                foreach (var prop in edge.Properties)
                {
                    // Set relationship properties
                }
            }
            
            return Result.Success();
        }
        catch (Exception ex)
        {
            return Result.Failure(new Error("Sync.Failed", ex.Message));
        }
    }
    
    private string ConvertPropertiesToCypherMap(IReadOnlyDictionary<string, object> properties)
    {
        if (!properties.Any())
            return "{}";
        
        var props = properties.Select(p =>
        {
            var value = p.Value is string 
                ? $"'{p.Value}'" 
                : p.Value.ToString();
            return $"{p.Key}: {value}";
        });
        
        return "{" + string.Join(", ", props) + "}";
    }
    
    private string GetNodeLabel(NodeType nodeType)
    {
        return nodeType.Name switch
        {
            "Entity" => "Entity",
            "Person" => "Person",
            "Department" => "Department",
            "Product" => "Product",
            _ => "Node"
        };
    }
    
    private string GetRelationshipType(EdgeType edgeType)
    {
        return edgeType.Name switch
        {
            "Relationship" => "RELATED_TO",
            "manages" => "MANAGES",
            "works_in" => "WORKS_IN",
            "reports_to" => "REPORTS_TO",
            _ => "CONNECTED_TO"
        };
    }
}
```

### AgeToGraphConverter.cs

```csharp
// Infrastructure/AGE/Converters/AgeToGraphConverter.cs
public class AgeToGraphConverter
{
    public async Task<Result<Graph>> ConvertFromAgeAsync(
        IAgeGraphClient client,
        string graphName)
    {
        try
        {
            // Query all nodes
            var nodesQuery = new CypherQueryBuilder()
                .Match("(n)")
                .Return("n")
                .Build();
            
            var nodesResult = await client.ExecuteQueryAsync(nodesQuery);
            
            if (nodesResult.IsFailure)
                return Result.Failure<Graph>(nodesResult.Error);
            
            // Query all relationships
            var relsQuery = new CypherQueryBuilder()
                .Match("()-[r]-()")
                .Return("r")
                .Build();
            
            var relsResult = await client.ExecuteQueryAsync(relsQuery);
            
            if (relsResult.IsFailure)
                return Result.Failure<Graph>(relsResult.Error);
            
            // Create graph
            var graph = Graph.Create(graphName, GraphType.Knowledge);
            
            // Convert nodes
            foreach (var row in nodesResult.Value.Rows)
            {
                // Parse AGE node data
                var nodeData = ParseAgeNode(row["n"]);
                
                var node = graph.AddNode(
                    nodeData.Name,
                    NodeType.Entity,
                    Position.Create(nodeData.X, nodeData.Y));
                
                if (node.IsSuccess)
                {
                    // Set properties
                    foreach (var prop in nodeData.Properties)
                    {
                        node.Value.SetProperty(prop.Key, prop.Value);
                    }
                }
            }
            
            // Convert relationships
            foreach (var row in relsResult.Value.Rows)
            {
                var relData = ParseAgeRelationship(row["r"]);
                
                // Create edge in graph
                // ... implementation
            }
            
            return Result.Success(graph);
        }
        catch (Exception ex)
        {
            return Result.Failure<Graph>(
                new Error("Converter.ImportFailed", ex.Message));
        }
    }
    
    private AgeNodeData ParseAgeNode(object ageNode)
    {
        // Parse AGE's agtype format
        // Implementation depends on Npgsql's AGE support
        return new AgeNodeData
        {
            Name = "Parsed Node",
            X = 100,
            Y = 100,
            Properties = new Dictionary<string, object>()
        };
    }
    
    private AgeRelationshipData ParseAgeRelationship(object ageRel)
    {
        // Parse AGE relationship
        return new AgeRelationshipData();
    }
}

internal class AgeNodeData
{
    public string Name { get; set; } = "";
    public double X { get; set; }
    public double Y { get; set; }
    public Dictionary<string, object> Properties { get; set; } = new();
}

internal class AgeRelationshipData
{
    public string Type { get; set; } = "";
    public string SourceId { get; set; } = "";
    public string TargetId { get; set; } = "";
    public Dictionary<string, object> Properties { get; set; } = new();
}
```

---

## 📚 Knowledge Graph Repository

```csharp
// Infrastructure/AGE/Repositories/KnowledgeGraphRepository.cs
public interface IKnowledgeGraphRepository
{
    Task<Result<Graph>> LoadGraphAsync(string graphName);
    Task<r> SaveGraphAsync(Graph graph);
    Task<Result<List<Graph>>> ListGraphsAsync();
    Task<r> DeleteGraphAsync(string graphName);
    Task<Result<AgeQueryResult>> ExecuteCypherAsync(string cypher);
}

public class KnowledgeGraphRepository : IKnowledgeGraphRepository
{
    private readonly IAgeGraphClient _client;
    private readonly IGraphToAgeConverter _toAgeConverter;
    private readonly AgeToGraphConverter _fromAgeConverter;
    
    public KnowledgeGraphRepository(
        IAgeGraphClient client,
        IGraphToAgeConverter toAgeConverter,
        AgeToGraphConverter fromAgeConverter)
    {
        _client = client;
        _toAgeConverter = toAgeConverter;
        _fromAgeConverter = fromAgeConverter;
    }
    
    public async Task<Result<Graph>> LoadGraphAsync(string graphName)
    {
        return await _fromAgeConverter.ConvertFromAgeAsync(_client, graphName);
    }
    
    public async Task<r> SaveGraphAsync(Graph graph)
    {
        return await _toAgeConverter.SyncGraphToAgeAsync(graph, _client);
    }
    
    public async Task<Result<List<Graph>>> ListGraphsAsync()
    {
        var graphsResult = await _client.ListGraphsAsync();
        
        if (graphsResult.IsFailure)
            return Result.Failure<List<Graph>>(graphsResult.Error);
        
        var graphs = new List<Graph>();
        
        foreach (var graphName in graphsResult.Value)
        {
            var graph = await LoadGraphAsync(graphName);
            if (graph.IsSuccess)
            {
                graphs.Add(graph.Value);
            }
        }
        
        return Result.Success(graphs);
    }
    
    public async Task<r> DeleteGraphAsync(string graphName)
    {
        return await _client.DropGraphAsync(graphName);
    }
    
    public async Task<Result<AgeQueryResult>> ExecuteCypherAsync(string cypher)
    {
        return await _client.ExecuteQueryAsync(cypher);
    }
}
```

---

**Part 5 continues with Visual Query Builder UI, Templates, and complete integration...**

**Continue to Part 6: Graph Execution Engine?**
