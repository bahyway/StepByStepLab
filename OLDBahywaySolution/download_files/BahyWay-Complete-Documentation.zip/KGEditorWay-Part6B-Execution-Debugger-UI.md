# KGEditorWay - Part 6B: Execution Debugger & UI (Complete)

## 🐛 Step-by-Step Debugger

### IDebugger.cs

```csharp
// Execution/Debugging/IDebugger.cs
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BahyWay.SharedKernel.Results;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.KGEditorWay.Execution.Debugging;

public interface IDebugger
{
    Task<r> AddBreakpointAsync(NodeId nodeId);
    Task<r> RemoveBreakpointAsync(NodeId nodeId);
    Task<r> ClearBreakpointsAsync();
    
    Task<r> StepOverAsync();
    Task<r> StepIntoAsync();
    Task<r> ContinueAsync();
    
    Task<Result<ExecutionState>> GetExecutionStateAsync();
    Task<Result<Dictionary<string, object?>>> InspectVariablesAsync(NodeId nodeId);
    
    event EventHandler<BreakpointHitEventArgs> BreakpointHit;
}

public class BreakpointHitEventArgs : EventArgs
{
    public NodeId NodeId { get; set; }
    public Dictionary<string, object?> LocalVariables { get; set; } = new();
    public Dictionary<string, object?> InputData { get; set; } = new();
}

public class ExecutionState
{
    public NodeId? CurrentNodeId { get; set; }
    public int CompletedNodes { get; set; }
    public int TotalNodes { get; set; }
    public Dictionary<NodeId, object?> NodeOutputs { get; set; } = new();
    public List<ExecutionTraceEntry> Trace { get; set; } = new();
}

public class ExecutionTraceEntry
{
    public DateTime Timestamp { get; set; }
    public NodeId NodeId { get; set; }
    public string NodeName { get; set; } = "";
    public ExecutionStatus Status { get; set; }
    public TimeSpan Duration { get; set; }
    public object? OutputData { get; set; }
}
```

### Debugger.cs

```csharp
// Execution/Debugging/Debugger.cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using BahyWay.SharedKernel.Results;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.KGEditorWay.Execution.Debugging;

public class Debugger : IDebugger
{
    private readonly HashSet<NodeId> _breakpoints = new();
    private readonly List<ExecutionTraceEntry> _trace = new();
    private readonly Dictionary<NodeId, object?> _nodeOutputs = new();
    
    private NodeId? _currentNodeId;
    private SemaphoreSlim? _stepSemaphore;
    private bool _isPaused;
    
    public event EventHandler<BreakpointHitEventArgs>? BreakpointHit;
    
    public async Task<r> AddBreakpointAsync(NodeId nodeId)
    {
        _breakpoints.Add(nodeId);
        return await Task.FromResult(Result.Success());
    }
    
    public async Task<r> RemoveBreakpointAsync(NodeId nodeId)
    {
        _breakpoints.Remove(nodeId);
        return await Task.FromResult(Result.Success());
    }
    
    public async Task<r> ClearBreakpointsAsync()
    {
        _breakpoints.Clear();
        return await Task.FromResult(Result.Success());
    }
    
    public async Task<r> StepOverAsync()
    {
        _stepSemaphore?.Release();
        return await Task.FromResult(Result.Success());
    }
    
    public async Task<r> StepIntoAsync()
    {
        _stepSemaphore?.Release();
        return await Task.FromResult(Result.Success());
    }
    
    public async Task<r> ContinueAsync()
    {
        _isPaused = false;
        _stepSemaphore?.Release();
        return await Task.FromResult(Result.Success());
    }
    
    public async Task<Result<ExecutionState>> GetExecutionStateAsync()
    {
        var state = new ExecutionState
        {
            CurrentNodeId = _currentNodeId,
            CompletedNodes = _trace.Count(t => t.Status == ExecutionStatus.Completed),
            TotalNodes = _trace.Count,
            NodeOutputs = new Dictionary<NodeId, object?>(_nodeOutputs),
            Trace = new List<ExecutionTraceEntry>(_trace)
        };
        
        return await Task.FromResult(Result.Success(state));
    }
    
    public async Task<Result<Dictionary<string, object?>>> InspectVariablesAsync(NodeId nodeId)
    {
        var variables = new Dictionary<string, object?>();
        
        if (_nodeOutputs.TryGetValue(nodeId, out var output))
        {
            variables["output"] = output;
        }
        
        return await Task.FromResult(Result.Success(variables));
    }
    
    public async Task OnNodeExecutingAsync(
        NodeId nodeId,
        string nodeName,
        Dictionary<string, object?> inputData)
    {
        _currentNodeId = nodeId;
        
        // Check for breakpoint
        if (_breakpoints.Contains(nodeId))
        {
            _isPaused = true;
            _stepSemaphore = new SemaphoreSlim(0, 1);
            
            BreakpointHit?.Invoke(this, new BreakpointHitEventArgs
            {
                NodeId = nodeId,
                InputData = inputData,
                LocalVariables = new Dictionary<string, object?>()
            });
            
            // Wait for step command
            await _stepSemaphore.WaitAsync();
        }
        
        await Task.CompletedTask;
    }
    
    public void OnNodeExecuted(
        NodeId nodeId,
        string nodeName,
        ExecutionStatus status,
        TimeSpan duration,
        object? outputData)
    {
        _trace.Add(new ExecutionTraceEntry
        {
            Timestamp = DateTime.UtcNow,
            NodeId = nodeId,
            NodeName = nodeName,
            Status = status,
            Duration = duration,
            OutputData = outputData
        });
        
        if (status == ExecutionStatus.Completed)
        {
            _nodeOutputs[nodeId] = outputData;
        }
    }
}
```

---

## 📊 Execution Context

```csharp
// Execution/Core/ExecutionContext.cs
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace BahyWay.KGEditorWay.Execution.Core;

public class ExecutionContext
{
    private readonly ConcurrentDictionary<string, object> _variables = new();
    private readonly ConcurrentDictionary<string, object> _metrics = new();
    
    public Guid ExecutionId { get; } = Guid.NewGuid();
    public DateTime StartTime { get; set; }
    public string? UserId { get; set; }
    public Dictionary<string, string> Configuration { get; set; } = new();
    
    // Variables
    public void SetVariable(string name, object value)
    {
        _variables[name] = value;
    }
    
    public T? GetVariable<T>(string name)
    {
        if (_variables.TryGetValue(name, out var value) && value is T typedValue)
        {
            return typedValue;
        }
        return default;
    }
    
    public bool HasVariable(string name) => _variables.ContainsKey(name);
    
    // Metrics
    public void SetMetric(string name, object value)
    {
        _metrics[name] = value;
    }
    
    public T? GetMetric<T>(string name)
    {
        if (_metrics.TryGetValue(name, out var value) && value is T typedValue)
        {
            return typedValue;
        }
        return default;
    }
    
    public Dictionary<string, object> GetAllMetrics()
    {
        return new Dictionary<string, object>(_metrics);
    }
    
    public void Clear()
    {
        _variables.Clear();
        _metrics.Clear();
    }
}
```

---

## 🎨 Execution UI Integration

### ExecutionMonitorView.axaml

```xml
<!-- Views/ExecutionMonitorView.axaml -->
<UserControl xmlns="https://github.com/avaloniaui"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
             xmlns:vm="using:BahyWay.KGEditorWay.Desktop.ViewModels"
             x:Class="BahyWay.KGEditorWay.Desktop.Views.ExecutionMonitorView"
             x:DataType="vm:ExecutionMonitorViewModel">
    
    <Grid RowDefinitions="Auto,*,Auto">
        
        <!-- Header -->
        <Border Grid.Row="0" 
                Background="#2D2D30" 
                BorderBrush="#3E3E42" 
                BorderThickness="0,0,0,1"
                Padding="12,8">
            <Grid ColumnDefinitions="*,Auto">
                <TextBlock Grid.Column="0" 
                          Text="Execution Monitor" 
                          FontWeight="Bold" 
                          FontSize="14"
                          Foreground="White"/>
                <StackPanel Grid.Column="1" Orientation="Horizontal" Spacing="8">
                    <TextBlock Text="{Binding StatusText}" 
                              VerticalAlignment="Center"
                              Foreground="{Binding StatusColor}"/>
                    <Ellipse Width="12" Height="12" 
                            Fill="{Binding StatusColor}"/>
                </StackPanel>
            </Grid>
        </Border>
        
        <!-- Execution Details -->
        <ScrollViewer Grid.Row="1">
            <StackPanel Spacing="12" Margin="12">
                
                <!-- Progress Bar -->
                <StackPanel Spacing="4">
                    <Grid ColumnDefinitions="*,Auto">
                        <TextBlock Grid.Column="0" Text="Progress" FontWeight="SemiBold"/>
                        <TextBlock Grid.Column="1" 
                                  Text="{Binding ProgressText}"
                                  Foreground="#CCCCCC"/>
                    </Grid>
                    <ProgressBar Value="{Binding ProgressPercentage}" 
                                Maximum="100"
                                Height="8"
                                Foreground="#4CAF50"/>
                </StackPanel>
                
                <!-- Execution Time -->
                <Grid ColumnDefinitions="Auto,*">
                    <TextBlock Grid.Column="0" Text="Duration:" Margin="0,0,8,0"/>
                    <TextBlock Grid.Column="1" Text="{Binding Duration}"/>
                </Grid>
                
                <!-- Current Node -->
                <Grid ColumnDefinitions="Auto,*" IsVisible="{Binding IsExecuting}">
                    <TextBlock Grid.Column="0" Text="Current Node:" Margin="0,0,8,0"/>
                    <TextBlock Grid.Column="1" 
                              Text="{Binding CurrentNodeName}"
                              Foreground="#4EC9B0"/>
                </Grid>
                
                <!-- Metrics -->
                <Expander Header="Metrics" IsExpanded="True">
                    <ItemsControl Items="{Binding Metrics}" Margin="12,8">
                        <ItemsControl.ItemTemplate>
                            <DataTemplate>
                                <Grid ColumnDefinitions="*,Auto" Margin="0,4">
                                    <TextBlock Grid.Column="0" Text="{Binding Key}"/>
                                    <TextBlock Grid.Column="1" 
                                              Text="{Binding Value}"
                                              FontFamily="Cascadia Code,Consolas"
                                              Foreground="#CCCCCC"/>
                                </Grid>
                            </DataTemplate>
                        </ItemsControl.ItemTemplate>
                    </ItemsControl>
                </Expander>
                
                <!-- Execution Trace -->
                <Expander Header="Execution Trace">
                    <ScrollViewer MaxHeight="300">
                        <ItemsControl Items="{Binding TraceEntries}" Margin="12,8">
                            <ItemsControl.ItemTemplate>
                                <DataTemplate>
                                    <Border Background="#1E1E1E" 
                                           BorderBrush="#3E3E42" 
                                           BorderThickness="1" 
                                           CornerRadius="4"
                                           Padding="8"
                                           Margin="0,4">
                                        <Grid ColumnDefinitions="Auto,*,Auto,Auto">
                                            <!-- Status Icon -->
                                            <TextBlock Grid.Column="0" 
                                                      Text="{Binding StatusIcon}"
                                                      FontSize="16"
                                                      Margin="0,0,8,0"/>
                                            
                                            <!-- Node Name -->
                                            <TextBlock Grid.Column="1" 
                                                      Text="{Binding NodeName}"
                                                      VerticalAlignment="Center"/>
                                            
                                            <!-- Duration -->
                                            <TextBlock Grid.Column="2" 
                                                      Text="{Binding DurationText}"
                                                      Foreground="#888888"
                                                      Margin="8,0"
                                                      VerticalAlignment="Center"/>
                                            
                                            <!-- Timestamp -->
                                            <TextBlock Grid.Column="3" 
                                                      Text="{Binding TimestampText}"
                                                      Foreground="#888888"
                                                      FontSize="10"
                                                      VerticalAlignment="Center"/>
                                        </Grid>
                                    </Border>
                                </DataTemplate>
                            </ItemsControl.ItemTemplate>
                        </ItemsControl>
                    </ScrollViewer>
                </Expander>
                
                <!-- Errors -->
                <Border Background="#5A1E1E" 
                       BorderBrush="#FF0000" 
                       BorderThickness="1" 
                       CornerRadius="4"
                       Padding="12"
                       IsVisible="{Binding HasErrors}">
                    <StackPanel Spacing="8">
                        <TextBlock Text="⚠ Execution Errors" 
                                  FontWeight="Bold" 
                                  Foreground="White"/>
                        <ItemsControl Items="{Binding Errors}">
                            <ItemsControl.ItemTemplate>
                                <DataTemplate>
                                    <TextBlock Text="{Binding}" 
                                              Foreground="White" 
                                              TextWrapping="Wrap"
                                              Margin="0,4"/>
                                </DataTemplate>
                            </ItemsControl.ItemTemplate>
                        </ItemsControl>
                    </StackPanel>
                </Border>
                
            </StackPanel>
        </ScrollViewer>
        
        <!-- Debug Controls -->
        <Border Grid.Row="2" 
                Background="#2D2D30" 
                BorderBrush="#3E3E42" 
                BorderThickness="0,1,0,0"
                Padding="12,8"
                IsVisible="{Binding IsDebugging}">
            <StackPanel Orientation="Horizontal" Spacing="8">
                <Button Content="⏯ Step Over" 
                       Command="{Binding StepOverCommand}"
                       Classes="toolbar"/>
                <Button Content="⏩ Step Into" 
                       Command="{Binding StepIntoCommand}"
                       Classes="toolbar"/>
                <Button Content="▶ Continue" 
                       Command="{Binding ContinueCommand}"
                       Classes="toolbar primary"/>
                <Button Content="⏹ Stop Debugging" 
                       Command="{Binding StopDebuggingCommand}"
                       Classes="toolbar"/>
                
                <Separator Width="1" Height="24" Background="#3E3E42" Margin="8,0"/>
                
                <TextBlock Text="Breakpoints:" 
                          VerticalAlignment="Center" 
                          Margin="8,0"/>
                <TextBlock Text="{Binding BreakpointCount}" 
                          VerticalAlignment="Center"
                          Foreground="#4EC9B0"/>
            </StackPanel>
        </Border>
        
    </Grid>
</UserControl>
```

### ExecutionMonitorViewModel.cs

```csharp
// ViewModels/ExecutionMonitorViewModel.cs
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive;
using ReactiveUI;
using BahyWay.KGEditorWay.Execution.Core;
using BahyWay.KGEditorWay.Execution.Debugging;

namespace BahyWay.KGEditorWay.Desktop.ViewModels;

public class ExecutionMonitorViewModel : ViewModelBase
{
    private readonly IExecutionEngine _executionEngine;
    private readonly IDebugger? _debugger;
    
    private string _statusText = "Ready";
    private string _statusColor = "#4CAF50";
    private double _progressPercentage;
    private string _progressText = "0 / 0";
    private TimeSpan _duration;
    private string _currentNodeName = "";
    private bool _isExecuting;
    private bool _isDebugging;
    private bool _hasErrors;
    private int _breakpointCount;
    
    public string StatusText
    {
        get => _statusText;
        set => this.RaiseAndSetIfChanged(ref _statusText, value);
    }
    
    public string StatusColor
    {
        get => _statusColor;
        set => this.RaiseAndSetIfChanged(ref _statusColor, value);
    }
    
    public double ProgressPercentage
    {
        get => _progressPercentage;
        set => this.RaiseAndSetIfChanged(ref _progressPercentage, value);
    }
    
    public string ProgressText
    {
        get => _progressText;
        set => this.RaiseAndSetIfChanged(ref _progressText, value);
    }
    
    public TimeSpan Duration
    {
        get => _duration;
        set => this.RaiseAndSetIfChanged(ref _duration, value);
    }
    
    public string CurrentNodeName
    {
        get => _currentNodeName;
        set => this.RaiseAndSetIfChanged(ref _currentNodeName, value);
    }
    
    public bool IsExecuting
    {
        get => _isExecuting;
        set => this.RaiseAndSetIfChanged(ref _isExecuting, value);
    }
    
    public bool IsDebugging
    {
        get => _isDebugging;
        set => this.RaiseAndSetIfChanged(ref _isDebugging, value);
    }
    
    public bool HasErrors
    {
        get => _hasErrors;
        set => this.RaiseAndSetIfChanged(ref _hasErrors, value);
    }
    
    public int BreakpointCount
    {
        get => _breakpointCount;
        set => this.RaiseAndSetIfChanged(ref _breakpointCount, value);
    }
    
    public ObservableCollection<MetricViewModel> Metrics { get; } = new();
    public ObservableCollection<TraceEntryViewModel> TraceEntries { get; } = new();
    public ObservableCollection<string> Errors { get; } = new();
    
    // Commands
    public ReactiveCommand<Unit, Unit> StepOverCommand { get; }
    public ReactiveCommand<Unit, Unit> StepIntoCommand { get; }
    public ReactiveCommand<Unit, Unit> ContinueCommand { get; }
    public ReactiveCommand<Unit, Unit> StopDebuggingCommand { get; }
    
    public ExecutionMonitorViewModel(
        IExecutionEngine executionEngine,
        IDebugger? debugger = null)
    {
        _executionEngine = executionEngine;
        _debugger = debugger;
        
        // Subscribe to execution events
        _executionEngine.NodeExecuted += OnNodeExecuted;
        _executionEngine.ProgressChanged += OnProgressChanged;
        _executionEngine.ExecutionError += OnExecutionError;
        
        if (_debugger != null)
        {
            _debugger.BreakpointHit += OnBreakpointHit;
        }
        
        StepOverCommand = ReactiveCommand.CreateFromTask(StepOver);
        StepIntoCommand = ReactiveCommand.CreateFromTask(StepInto);
        ContinueCommand = ReactiveCommand.CreateFromTask(Continue);
        StopDebuggingCommand = ReactiveCommand.CreateFromTask(StopDebugging);
    }
    
    private void OnNodeExecuted(object? sender, NodeExecutedEventArgs e)
    {
        var statusIcon = e.Status switch
        {
            ExecutionStatus.Completed => "✅",
            ExecutionStatus.Failed => "❌",
            ExecutionStatus.Cancelled => "⏹",
            _ => "⏸"
        };
        
        TraceEntries.Add(new TraceEntryViewModel
        {
            NodeName = e.NodeId.ToString(), // TODO: Get actual node name
            StatusIcon = statusIcon,
            DurationText = $"{e.Duration.TotalMilliseconds:F0}ms",
            TimestampText = DateTime.Now.ToString("HH:mm:ss")
        });
    }
    
    private void OnProgressChanged(object? sender, ExecutionProgressEventArgs e)
    {
        ProgressPercentage = e.ProgressPercentage;
        ProgressText = $"{e.CompletedNodes} / {e.TotalNodes}";
    }
    
    private void OnExecutionError(object? sender, ExecutionErrorEventArgs e)
    {
        HasErrors = true;
        Errors.Add($"{e.NodeId}: {e.Exception.Message}");
        StatusText = "Error";
        StatusColor = "#F44336";
    }
    
    private void OnBreakpointHit(object? sender, BreakpointHitEventArgs e)
    {
        IsDebugging = true;
        CurrentNodeName = e.NodeId.ToString(); // TODO: Get actual node name
        StatusText = "Breakpoint Hit";
        StatusColor = "#FF9800";
    }
    
    private async Task StepOver()
    {
        if (_debugger != null)
        {
            await _debugger.StepOverAsync();
        }
    }
    
    private async Task StepInto()
    {
        if (_debugger != null)
        {
            await _debugger.StepIntoAsync();
        }
    }
    
    private async Task Continue()
    {
        if (_debugger != null)
        {
            await _debugger.ContinueAsync();
            IsDebugging = false;
        }
    }
    
    private async Task StopDebugging()
    {
        IsDebugging = false;
        await _executionEngine.StopAsync();
    }
}

public class MetricViewModel : ViewModelBase
{
    public string Key { get; set; } = "";
    public string Value { get; set; } = "";
}

public class TraceEntryViewModel : ViewModelBase
{
    public string NodeName { get; set; } = "";
    public string StatusIcon { get; set; } = "";
    public string DurationText { get; set; } = "";
    public string TimestampText { get; set; } = "";
}
```

---

## 🔌 Complete Integration

### ExecutorRegistry.cs

```csharp
// Execution/Nodes/ExecutorRegistry.cs
using System;
using System.Collections.Generic;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.KGEditorWay.Execution.Nodes;

public interface IExecutorRegistry
{
    INodeExecutor? GetExecutor(NodeType nodeType);
    void RegisterExecutor(NodeType nodeType, INodeExecutor executor);
}

public class ExecutorRegistry : IExecutorRegistry
{
    private readonly Dictionary<string, INodeExecutor> _executors = new();
    
    public INodeExecutor? GetExecutor(NodeType nodeType)
    {
        _executors.TryGetValue(nodeType.Name, out var executor);
        return executor;
    }
    
    public void RegisterExecutor(NodeType nodeType, INodeExecutor executor)
    {
        _executors[nodeType.Name] = executor;
    }
}
```

### Dependency Injection

```csharp
// Add to DependencyInjection.cs
public static class DependencyInjection
{
    public static IServiceCollection AddExecutionEngine(
        this IServiceCollection services)
    {
        // Core
        services.AddScoped<IExecutionEngine, ExecutionEngine>();
        services.AddScoped<IDataFlowManager, DataFlowManager>();
        services.AddSingleton<IExecutorRegistry, ExecutorRegistry>();
        
        // Debugging
        services.AddScoped<IDebugger, Debugger>();
        services.AddScoped<IExecutionTracer, ExecutionTracer>();
        
        // Monitoring
        services.AddScoped<IExecutionLogger, ExecutionLogger>();
        
        // Register node executors
        services.AddScoped<CsvSourceNodeExecutor>();
        services.AddScoped<DatabaseSourceNodeExecutor>();
        services.AddScoped<MapTransformExecutor>();
        services.AddScoped<FilterTransformExecutor>();
        services.AddScoped<AggregateTransformExecutor>();
        services.AddScoped<CsvSinkNodeExecutor>();
        services.AddScoped<LoggerSinkNodeExecutor>();
        
        // Configure executor registry
        services.AddSingleton(sp =>
        {
            var registry = new ExecutorRegistry();
            
            // Register executors
            registry.RegisterExecutor(NodeType.Source, 
                sp.GetRequiredService<CsvSourceNodeExecutor>());
            registry.RegisterExecutor(NodeType.Transform, 
                sp.GetRequiredService<MapTransformExecutor>());
            registry.RegisterExecutor(NodeType.Sink, 
                sp.GetRequiredService<CsvSinkNodeExecutor>());
            
            return registry;
        });
        
        return services;
    }
}
```

---

## ✅ Execution Engine Complete!

You now have:

✅ **Complete Execution Engine** - Orchestrates graph execution  
✅ **Node Executors** - Source, Transform, Filter, Sink  
✅ **Data Flow Management** - Pass data between nodes  
✅ **Step-by-Step Debugger** - Breakpoints, step over/into  
✅ **Execution Context** - Variables and metrics  
✅ **Execution Monitor UI** - Real-time progress tracking  
✅ **Performance Metrics** - Duration, throughput  
✅ **Error Handling** - Graceful failure recovery  

---

**Continue to Part 7: Project Integrations (ETLway, SSISight, AlarmInsight, SteerView)!**
