# BahyWay AlarmManagement - Application Layer (CQRS)

This layer orchestrates the use cases of your application. It's where commands and queries live.

---

## 📦 Dependencies

```xml
<ItemGroup>
  <!-- Reference Domain Layer -->
  <ProjectReference Include="..\BahyWay.AlarmManagement.Domain\BahyWay.AlarmManagement.Domain.csproj" />
  <ProjectReference Include="..\..\SharedKernel\BahyWay.SharedKernel\BahyWay.SharedKernel.csproj" />
  
  <!-- CQRS & Mediator -->
  <PackageReference Include="MediatR" Version="12.2.0" />
  
  <!-- Validation -->
  <PackageReference Include="FluentValidation" Version="11.9.0" />
  <PackageReference Include="FluentValidation.DependencyInjectionExtensions" Version="11.9.0" />
  
  <!-- Mapping -->
  <PackageReference Include="AutoMapper" Version="12.0.1" />
  <PackageReference Include="AutoMapper.Extensions.Microsoft.DependencyInjection" Version="12.0.1" />
</ItemGroup>
```

---

## 🎯 CQRS Pattern

### Commands (Write Operations)

```csharp
// Commands/CreateAlarm/CreateAlarmCommand.cs
using MediatR;
using BahyWay.SharedKernel.Results;

namespace BahyWay.AlarmManagement.Application.Commands.CreateAlarm;

/// <summary>
/// Command to create a new alarm.
/// Commands represent intent to change state.
/// </summary>
public sealed record CreateAlarmCommand : IRequest<Result<AlarmDto>>
{
    public Guid AssetId { get; init; }
    public int SeverityValue { get; init; }
    public double Value { get; init; }
    public string Unit { get; init; } = string.Empty;
    public string Message { get; init; } = string.Empty;
    public string? Description { get; init; }
    public double? Latitude { get; init; }
    public double? Longitude { get; init; }
}

// Commands/CreateAlarm/CreateAlarmCommandValidator.cs
using FluentValidation;

namespace BahyWay.AlarmManagement.Application.Commands.CreateAlarm;

public sealed class CreateAlarmCommandValidator : AbstractValidator<CreateAlarmCommand>
{
    public CreateAlarmCommandValidator()
    {
        RuleFor(x => x.AssetId)
            .NotEmpty()
            .WithMessage("Asset ID is required");

        RuleFor(x => x.SeverityValue)
            .InclusiveBetween(1, 5)
            .WithMessage("Severity must be between 1 (Info) and 5 (Critical)");

        RuleFor(x => x.Unit)
            .NotEmpty()
            .WithMessage("Unit is required")
            .MaximumLength(20)
            .WithMessage("Unit cannot exceed 20 characters");

        RuleFor(x => x.Message)
            .NotEmpty()
            .WithMessage("Message is required")
            .MaximumLength(500)
            .WithMessage("Message cannot exceed 500 characters");

        RuleFor(x => x.Description)
            .MaximumLength(2000)
            .When(x => !string.IsNullOrEmpty(x.Description))
            .WithMessage("Description cannot exceed 2000 characters");

        RuleFor(x => x.Latitude)
            .InclusiveBetween(-90.0, 90.0)
            .When(x => x.Latitude.HasValue)
            .WithMessage("Latitude must be between -90 and 90");

        RuleFor(x => x.Longitude)
            .InclusiveBetween(-180.0, 180.0)
            .When(x => x.Longitude.HasValue)
            .WithMessage("Longitude must be between -180 and 180");
    }
}

// Commands/CreateAlarm/CreateAlarmCommandHandler.cs
using MediatR;
using AutoMapper;
using BahyWay.SharedKernel.Results;
using BahyWay.SharedKernel.Interfaces;
using BahyWay.AlarmManagement.Domain.Aggregates.Alarm;
using BahyWay.AlarmManagement.Domain.Aggregates.Asset;
using BahyWay.AlarmManagement.Domain.Repositories;
using BahyWay.AlarmManagement.Domain.ValueObjects;

namespace BahyWay.AlarmManagement.Application.Commands.CreateAlarm;

public sealed class CreateAlarmCommandHandler 
    : IRequestHandler<CreateAlarmCommand, Result<AlarmDto>>
{
    private readonly IAlarmRepository _alarmRepository;
    private readonly IAssetRepository _assetRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    private readonly ILogger<CreateAlarmCommandHandler> _logger;

    public CreateAlarmCommandHandler(
        IAlarmRepository alarmRepository,
        IAssetRepository assetRepository,
        IUnitOfWork unitOfWork,
        IMapper mapper,
        ILogger<CreateAlarmCommandHandler> logger)
    {
        _alarmRepository = alarmRepository;
        _assetRepository = assetRepository;
        _unitOfWork = unitOfWork;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<Result<AlarmDto>> Handle(
        CreateAlarmCommand request,
        CancellationToken cancellationToken)
    {
        try
        {
            // 1. Verify asset exists
            var assetId = AssetId.From(request.AssetId);
            var asset = await _assetRepository.GetByIdAsync(assetId, cancellationToken);

            if (asset == null)
            {
                return Result.Failure<AlarmDto>(
                    new Error("Asset.NotFound", $"Asset with ID '{request.AssetId}' not found", ErrorType.NotFound));
            }

            if (!asset.IsActive)
            {
                return Result.Failure<AlarmDto>(
                    new Error("Asset.Inactive", "Cannot create alarm for inactive asset", ErrorType.Validation));
            }

            // 2. Create domain objects
            var severity = AlarmSeverity.FromValue<AlarmSeverity>(request.SeverityValue);
            var alarmValue = AlarmValue.Create(request.Value, request.Unit);
            
            GeoLocation? location = null;
            if (request.Latitude.HasValue && request.Longitude.HasValue)
            {
                location = GeoLocation.Create(request.Latitude.Value, request.Longitude.Value);
            }

            // 3. Create alarm aggregate
            var alarm = Alarm.Create(
                assetId,
                severity,
                alarmValue,
                request.Message,
                request.Description,
                location);

            // 4. Persist
            await _alarmRepository.AddAsync(alarm, cancellationToken);
            await _unitOfWork.SaveChangesAsync(cancellationToken);

            _logger.LogInformation(
                "Created alarm {AlarmId} for asset {AssetId} with severity {Severity}",
                alarm.Id,
                assetId,
                severity.Name);

            // 5. Return DTO
            var dto = _mapper.Map<AlarmDto>(alarm);
            return Result.Success(dto);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating alarm for asset {AssetId}", request.AssetId);
            return Result.Failure<AlarmDto>(
                new Error("Alarm.CreationFailed", "Failed to create alarm", ErrorType.Failure));
        }
    }
}
```

### More Commands

```csharp
// Commands/AcknowledgeAlarm/AcknowledgeAlarmCommand.cs
public sealed record AcknowledgeAlarmCommand : IRequest<Result>
{
    public Guid AlarmId { get; init; }
    public string AcknowledgedBy { get; init; } = string.Empty;
}

// Commands/AcknowledgeAlarm/AcknowledgeAlarmCommandValidator.cs
public sealed class AcknowledgeAlarmCommandValidator : AbstractValidator<AcknowledgeAlarmCommand>
{
    public AcknowledgeAlarmCommandValidator()
    {
        RuleFor(x => x.AlarmId)
            .NotEmpty()
            .WithMessage("Alarm ID is required");

        RuleFor(x => x.AcknowledgedBy)
            .NotEmpty()
            .WithMessage("Acknowledged by is required")
            .MaximumLength(100)
            .WithMessage("Acknowledged by cannot exceed 100 characters");
    }
}

// Commands/AcknowledgeAlarm/AcknowledgeAlarmCommandHandler.cs
public sealed class AcknowledgeAlarmCommandHandler : IRequestHandler<AcknowledgeAlarmCommand, Result>
{
    private readonly IAlarmRepository _alarmRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ILogger<AcknowledgeAlarmCommandHandler> _logger;

    public AcknowledgeAlarmCommandHandler(
        IAlarmRepository alarmRepository,
        IUnitOfWork unitOfWork,
        ILogger<AcknowledgeAlarmCommandHandler> logger)
    {
        _alarmRepository = alarmRepository;
        _unitOfWork = unitOfWork;
        _logger = logger;
    }

    public async Task<Result> Handle(
        AcknowledgeAlarmCommand request,
        CancellationToken cancellationToken)
    {
        var alarmId = AlarmId.From(request.AlarmId);
        var alarm = await _alarmRepository.GetByIdAsync(alarmId, cancellationToken);

        if (alarm == null)
        {
            return Result.Failure(
                new Error("Alarm.NotFound", $"Alarm '{request.AlarmId}' not found", ErrorType.NotFound));
        }

        var result = alarm.Acknowledge(request.AcknowledgedBy);
        if (result.IsFailure)
        {
            return result;
        }

        _alarmRepository.Update(alarm);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        _logger.LogInformation(
            "Alarm {AlarmId} acknowledged by {User}",
            alarmId,
            request.AcknowledgedBy);

        return Result.Success();
    }
}

// Commands/ResolveAlarm/ResolveAlarmCommand.cs
public sealed record ResolveAlarmCommand : IRequest<Result>
{
    public Guid AlarmId { get; init; }
    public string ResolvedBy { get; init; } = string.Empty;
    public string Resolution { get; init; } = string.Empty;
}

// Commands/EscalateAlarm/EscalateAlarmCommand.cs
public sealed record EscalateAlarmCommand : IRequest<Result>
{
    public Guid AlarmId { get; init; }
    public string Reason { get; init; } = string.Empty;
}
```

---

### Queries (Read Operations)

```csharp
// Queries/GetAlarm/GetAlarmQuery.cs
using MediatR;
using BahyWay.SharedKernel.Results;

namespace BahyWay.AlarmManagement.Application.Queries.GetAlarm;

public sealed record GetAlarmQuery : IRequest<Result<AlarmDto>>
{
    public Guid AlarmId { get; init; }
}

// Queries/GetAlarm/GetAlarmQueryHandler.cs
public sealed class GetAlarmQueryHandler : IRequestHandler<GetAlarmQuery, Result<AlarmDto>>
{
    private readonly IAlarmRepository _alarmRepository;
    private readonly IMapper _mapper;

    public GetAlarmQueryHandler(IAlarmRepository alarmRepository, IMapper mapper)
    {
        _alarmRepository = alarmRepository;
        _mapper = mapper;
    }

    public async Task<Result<AlarmDto>> Handle(
        GetAlarmQuery request,
        CancellationToken cancellationToken)
    {
        var alarmId = AlarmId.From(request.AlarmId);
        var alarm = await _alarmRepository.GetByIdAsync(alarmId, cancellationToken);

        if (alarm == null)
        {
            return Result.Failure<AlarmDto>(
                new Error("Alarm.NotFound", $"Alarm '{request.AlarmId}' not found", ErrorType.NotFound));
        }

        var dto = _mapper.Map<AlarmDto>(alarm);
        return Result.Success(dto);
    }
}

// Queries/GetActiveAlarms/GetActiveAlarmsQuery.cs
public sealed record GetActiveAlarmsQuery : IRequest<Result<List<AlarmDto>>>
{
    public int? PageNumber { get; init; }
    public int? PageSize { get; init; }
    public int? MinSeverity { get; init; }
}

// Queries/GetActiveAlarms/GetActiveAlarmsQueryHandler.cs
public sealed class GetActiveAlarmsQueryHandler 
    : IRequestHandler<GetActiveAlarmsQuery, Result<List<AlarmDto>>>
{
    private readonly IAlarmRepository _alarmRepository;
    private readonly IMapper _mapper;

    public GetActiveAlarmsQueryHandler(IAlarmRepository alarmRepository, IMapper mapper)
    {
        _alarmRepository = alarmRepository;
        _mapper = mapper;
    }

    public async Task<Result<List<AlarmDto>>> Handle(
        GetActiveAlarmsQuery request,
        CancellationToken cancellationToken)
    {
        var alarms = await _alarmRepository.GetActiveAlarmsAsync(cancellationToken);

        // Apply filters
        if (request.MinSeverity.HasValue)
        {
            alarms = alarms
                .Where(a => a.Severity.Value >= request.MinSeverity.Value)
                .ToList();
        }

        // Apply pagination
        if (request.PageNumber.HasValue && request.PageSize.HasValue)
        {
            alarms = alarms
                .Skip((request.PageNumber.Value - 1) * request.PageSize.Value)
                .Take(request.PageSize.Value)
                .ToList();
        }

        var dtos = _mapper.Map<List<AlarmDto>>(alarms);
        return Result.Success(dtos);
    }
}

// Queries/GetAlarmStatistics/GetAlarmStatisticsQuery.cs
public sealed record GetAlarmStatisticsQuery : IRequest<Result<AlarmStatisticsDto>>
{
    public DateTime? StartDate { get; init; }
    public DateTime? EndDate { get; init; }
}

// Queries/GetAlarmStatistics/GetAlarmStatisticsQueryHandler.cs
public sealed class GetAlarmStatisticsQueryHandler 
    : IRequestHandler<GetAlarmStatisticsQuery, Result<AlarmStatisticsDto>>
{
    private readonly IAlarmRepository _alarmRepository;

    public GetAlarmStatisticsQueryHandler(IAlarmRepository alarmRepository)
    {
        _alarmRepository = alarmRepository;
    }

    public async Task<Result<AlarmStatisticsDto>> Handle(
        GetAlarmStatisticsQuery request,
        CancellationToken cancellationToken)
    {
        var activeCount = await _alarmRepository.GetActiveAlarmCountAsync(cancellationToken);
        var bySeverity = await _alarmRepository.GetAlarmCountBySeverityAsync(cancellationToken);

        var statistics = new AlarmStatisticsDto
        {
            ActiveAlarmCount = activeCount,
            AlarmsBySeverity = bySeverity.ToDictionary(
                kvp => kvp.Key.Name,
                kvp => kvp.Value),
            GeneratedAt = DateTime.UtcNow
        };

        return Result.Success(statistics);
    }
}
```

---

## 📊 DTOs (Data Transfer Objects)

```csharp
// DTOs/AlarmDto.cs
namespace BahyWay.AlarmManagement.Application.DTOs;

public sealed class AlarmDto
{
    public Guid Id { get; init; }
    public Guid AssetId { get; init; }
    public string AssetName { get; init; } = string.Empty;
    public int SeverityValue { get; init; }
    public string SeverityName { get; init; } = string.Empty;
    public string SeverityDescription { get; init; } = string.Empty;
    public string StatusName { get; init; } = string.Empty;
    public double Value { get; init; }
    public string Unit { get; init; } = string.Empty;
    public string Message { get; init; } = string.Empty;
    public string? Description { get; init; }
    public LocationDto? Location { get; init; }
    public DateTime OccurredAt { get; init; }
    public DateTime? AcknowledgedAt { get; init; }
    public DateTime? ResolvedAt { get; init; }
    public string? AcknowledgedBy { get; init; }
    public string? ResolvedBy { get; init; }
    public string? Resolution { get; init; }
    public int EscalationCount { get; init; }
    public bool IsOverdue { get; init; }
    public TimeSpan Age { get; init; }
}

// DTOs/LocationDto.cs
public sealed class LocationDto
{
    public double Latitude { get; init; }
    public double Longitude { get; init; }
    public double? Altitude { get; init; }
}

// DTOs/AssetDto.cs
public sealed class AssetDto
{
    public Guid Id { get; init; }
    public string Name { get; init; } = string.Empty;
    public string? Description { get; init; }
    public string TypeName { get; init; } = string.Empty;
    public LocationDto? Location { get; init; }
    public bool IsActive { get; init; }
    public DateTime CreatedAt { get; init; }
    public DateTime? LastMaintenanceDate { get; init; }
}

// DTOs/AlarmStatisticsDto.cs
public sealed class AlarmStatisticsDto
{
    public int ActiveAlarmCount { get; init; }
    public Dictionary<string, int> AlarmsBySeverity { get; init; } = new();
    public DateTime GeneratedAt { get; init; }
}
```

---

## 🗺️ AutoMapper Profiles

```csharp
// Mappings/AlarmMappingProfile.cs
using AutoMapper;
using BahyWay.AlarmManagement.Domain.Aggregates.Alarm;
using BahyWay.AlarmManagement.Domain.Aggregates.Asset;
using BahyWay.AlarmManagement.Domain.ValueObjects;
using BahyWay.AlarmManagement.Application.DTOs;

namespace BahyWay.AlarmManagement.Application.Mappings;

public sealed class AlarmMappingProfile : Profile
{
    public AlarmMappingProfile()
    {
        // Alarm -> AlarmDto
        CreateMap<Alarm, AlarmDto>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id.Value))
            .ForMember(dest => dest.AssetId, opt => opt.MapFrom(src => src.AssetId.Value))
            .ForMember(dest => dest.SeverityValue, opt => opt.MapFrom(src => src.Severity.Value))
            .ForMember(dest => dest.SeverityName, opt => opt.MapFrom(src => src.Severity.Name))
            .ForMember(dest => dest.SeverityDescription, opt => opt.MapFrom(src => src.Severity.Description))
            .ForMember(dest => dest.StatusName, opt => opt.MapFrom(src => src.Status.Name))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value.Value))
            .ForMember(dest => dest.Unit, opt => opt.MapFrom(src => src.Value.Unit))
            .ForMember(dest => dest.IsOverdue, opt => opt.MapFrom(src => src.IsOverdue()))
            .ForMember(dest => dest.Age, opt => opt.MapFrom(src => src.GetAge()));

        // Asset -> AssetDto
        CreateMap<Asset, AssetDto>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id.Value))
            .ForMember(dest => dest.TypeName, opt => opt.MapFrom(src => src.Type.Name));

        // GeoLocation -> LocationDto
        CreateMap<GeoLocation, LocationDto>();
    }
}
```

---

## 🛡️ Pipeline Behaviors

```csharp
// Behaviors/ValidationBehavior.cs
using FluentValidation;
using MediatR;
using BahyWay.SharedKernel.Results;
using BahyWay.SharedKernel.Exceptions;

namespace BahyWay.AlarmManagement.Application.Behaviors;

/// <summary>
/// Validates commands/queries before they reach handlers.
/// </summary>
public sealed class ValidationBehavior<TRequest, TResponse> 
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : IRequest<TResponse>
{
    private readonly IEnumerable<IValidator<TRequest>> _validators;

    public ValidationBehavior(IEnumerable<IValidator<TRequest>> validators)
    {
        _validators = validators;
    }

    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken cancellationToken)
    {
        if (!_validators.Any())
        {
            return await next();
        }

        var context = new ValidationContext<TRequest>(request);

        var validationResults = await Task.WhenAll(
            _validators.Select(v => v.ValidateAsync(context, cancellationToken)));

        var failures = validationResults
            .Where(r => !r.IsValid)
            .SelectMany(r => r.Errors)
            .ToList();

        if (failures.Any())
        {
            var errors = failures
                .GroupBy(f => f.PropertyName)
                .ToDictionary(
                    g => g.Key,
                    g => g.Select(f => f.ErrorMessage).ToArray());

            throw new ValidationException(errors);
        }

        return await next();
    }
}

// Behaviors/LoggingBehavior.cs
using MediatR;
using Microsoft.Extensions.Logging;
using System.Diagnostics;

public sealed class LoggingBehavior<TRequest, TResponse> 
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : IRequest<TResponse>
{
    private readonly ILogger<LoggingBehavior<TRequest, TResponse>> _logger;

    public LoggingBehavior(ILogger<LoggingBehavior<TRequest, TResponse>> logger)
    {
        _logger = logger;
    }

    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken cancellationToken)
    {
        var requestName = typeof(TRequest).Name;
        
        _logger.LogInformation(
            "Handling {RequestName}",
            requestName);

        var stopwatch = Stopwatch.StartNew();

        try
        {
            var response = await next();

            stopwatch.Stop();

            _logger.LogInformation(
                "Handled {RequestName} in {ElapsedMs}ms",
                requestName,
                stopwatch.ElapsedMilliseconds);

            return response;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();

            _logger.LogError(
                ex,
                "Error handling {RequestName} after {ElapsedMs}ms",
                requestName,
                stopwatch.ElapsedMilliseconds);

            throw;
        }
    }
}

// Behaviors/TransactionBehavior.cs
using MediatR;
using BahyWay.SharedKernel.Interfaces;

public sealed class TransactionBehavior<TRequest, TResponse> 
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : IRequest<TResponse>
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly ILogger<TransactionBehavior<TRequest, TResponse>> _logger;

    public TransactionBehavior(
        IUnitOfWork unitOfWork,
        ILogger<TransactionBehavior<TRequest, TResponse>> logger)
    {
        _unitOfWork = unitOfWork;
        _logger = logger;
    }

    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken cancellationToken)
    {
        // Only for commands (writes)
        if (!typeof(TRequest).Name.EndsWith("Command"))
        {
            return await next();
        }

        try
        {
            await _unitOfWork.BeginTransactionAsync(cancellationToken);

            var response = await next();

            await _unitOfWork.CommitTransactionAsync(cancellationToken);

            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Transaction failed for {RequestName}", typeof(TRequest).Name);
            
            await _unitOfWork.RollbackTransactionAsync(cancellationToken);
            
            throw;
        }
    }
}
```

---

## 🔧 Dependency Injection

```csharp
// DependencyInjection.cs
using Microsoft.Extensions.DependencyInjection;
using FluentValidation;
using MediatR;
using BahyWay.AlarmManagement.Application.Behaviors;

namespace BahyWay.AlarmManagement.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplicationLayer(this IServiceCollection services)
    {
        var assembly = typeof(DependencyInjection).Assembly;

        // MediatR
        services.AddMediatR(cfg =>
        {
            cfg.RegisterServicesFromAssembly(assembly);
            
            // Add pipeline behaviors
            cfg.AddBehavior(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));
            cfg.AddBehavior(typeof(IPipelineBehavior<,>), typeof(LoggingBehavior<,>));
            cfg.AddBehavior(typeof(IPipelineBehavior<,>), typeof(TransactionBehavior<,>));
        });

        // FluentValidation
        services.AddValidatorsFromAssembly(assembly);

        // AutoMapper
        services.AddAutoMapper(assembly);

        return services;
    }
}
```

---

## ✅ Application Layer Benefits

✅ **CQRS Separation:** Clear separation between reads and writes  
✅ **Validation:** Automatic validation before handlers  
✅ **Logging:** Centralized logging for all operations  
✅ **Transactions:** Automatic transaction management  
✅ **Mapping:** Clean separation between domain and DTOs  
✅ **Testability:** Each handler can be unit tested  
✅ **Traceability:** Full audit trail of all operations  

---

**Next: Infrastructure Layer (Repositories, EF Core, External Services)**
