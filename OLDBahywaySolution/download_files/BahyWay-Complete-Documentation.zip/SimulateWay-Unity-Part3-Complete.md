# SimulateWay.Unity - Part 3: Complete Examples & Deployment

## 🚀 Complete PostgreSQL Replication Example (Unity)

### PostgreSQL Workflow Scene

```csharp
// Assets/Scripts/Examples/PostgreSQLReplicationExample.cs
using UnityEngine;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BahyWay.SimulateWay.Unity.Examples
{
    public class PostgreSQLReplicationExample : MonoBehaviour
    {
        [Header("Components")]
        public SimulationEngine simulationEngine;
        public BahyWayClient apiClient;
        
        [Header("Prefabs")]
        public GameObject serverPrefab;
        public GameObject processPrefab;
        
        private Dictionary<string, NodeRenderer> nodes = new();
        
        async void Start()
        {
            await CreatePostgreSQLWorkflow();
        }
        
        async Task CreatePostgreSQLWorkflow()
        {
            Debug.Log("Creating PostgreSQL Replication Workflow...");
            
            // Create graph data
            GraphData graph = new GraphData
            {
                Id = "postgresql-replication",
                Name = "PostgreSQL Streaming Replication",
                Type = "Process"
            };
            
            // Create nodes
            // 1. Primary Server
            var primary = CreateNode(
                "primary",
                "Primary Server",
                "Database",
                new Vector3(-8, 0, 0),
                "🗄️");
            graph.Nodes.Add(primary);
            
            // 2. WAL Writer
            var walWriter = CreateNode(
                "wal-writer",
                "WAL Writer",
                "Process",
                new Vector3(-4, 2, 0),
                "📝");
            graph.Nodes.Add(walWriter);
            
            // 3. WAL Sender
            var walSender = CreateNode(
                "wal-sender",
                "WAL Sender",
                "Process",
                new Vector3(0, 2, 0),
                "📤");
            graph.Nodes.Add(walSender);
            
            // 4. WAL Receiver
            var walReceiver = CreateNode(
                "wal-receiver",
                "WAL Receiver",
                "Process",
                new Vector3(4, 2, 0),
                "📥");
            graph.Nodes.Add(walReceiver);
            
            // 5. Standby Server
            var standby = CreateNode(
                "standby",
                "Standby Server",
                "Database",
                new Vector3(8, 0, 0),
                "🗄️");
            graph.Nodes.Add(standby);
            
            // 6. Startup Process
            var startup = CreateNode(
                "startup",
                "Startup Process",
                "Process",
                new Vector3(8, -2, 0),
                "🚀");
            graph.Nodes.Add(startup);
            
            // Create edges
            graph.Edges.Add(CreateEdge("e1", "primary", "wal-writer", "DataFlow"));
            graph.Edges.Add(CreateEdge("e2", "wal-writer", "wal-sender", "DataFlow"));
            graph.Edges.Add(CreateEdge("e3", "wal-sender", "wal-receiver", "DataFlow"));
            graph.Edges.Add(CreateEdge("e4", "wal-receiver", "standby", "DataFlow"));
            graph.Edges.Add(CreateEdge("e5", "standby", "startup", "DataFlow"));
            
            // Load into simulation engine
            await simulationEngine.LoadGraphDataAsync(graph);
            
            // Create custom animation
            await CreateCustomAnimation();
            
            Debug.Log("✅ PostgreSQL workflow created!");
        }
        
        NodeData CreateNode(string id, string name, string type, Vector3 position, string icon)
        {
            return new NodeData
            {
                Id = id,
                Name = name,
                Type = type,
                Position = new Vector2(position.x * 100, position.z * 100),
                Properties = new Dictionary<string, object>
                {
                    ["icon"] = icon,
                    ["x"] = position.x,
                    ["y"] = position.y,
                    ["z"] = position.z
                }
            };
        }
        
        EdgeData CreateEdge(string id, string source, string target, string type)
        {
            return new EdgeData
            {
                Id = id,
                SourceNodeId = source,
                TargetNodeId = target,
                Type = type
            };
        }
        
        async Task CreateCustomAnimation()
        {
            var animation = new AnimationData
            {
                Id = "postgresql-animation",
                Name = "PostgreSQL Replication Flow",
                TotalDuration = 18f
            };
            
            // Scene 1: Transaction on Primary (0-3s)
            animation.Scenes.Add(new AnimationScene
            {
                Name = "Transaction on Primary",
                Duration = 3f,
                Narration = "1. Transaction occurs on Primary Server",
                HighlightedNodes = new List<string> { "primary" },
                DataFlows = new List<DataFlowDefinition>()
            });
            
            // Scene 2: WAL Writer (3-6s)
            animation.Scenes.Add(new AnimationScene
            {
                Name = "WAL Writer Processing",
                Duration = 3f,
                Narration = "2. WAL Writer writes transaction to Write-Ahead Log",
                HighlightedNodes = new List<string> { "primary", "wal-writer" },
                DataFlows = new List<DataFlowDefinition>
                {
                    new DataFlowDefinition
                    {
                        EdgeId = "e1",
                        SourceNodeId = "primary",
                        TargetNodeId = "wal-writer",
                        Color = "#FFC107", // Amber
                        ParticleCount = 8
                    }
                }
            });
            
            // Scene 3: WAL Sender Streaming (6-9s)
            animation.Scenes.Add(new AnimationScene
            {
                Name = "Streaming WAL Records",
                Duration = 3f,
                Narration = "3. WAL Sender streams WAL records to Standby",
                HighlightedNodes = new List<string> { "wal-sender" },
                DataFlows = new List<DataFlowDefinition>
                {
                    new DataFlowDefinition
                    {
                        EdgeId = "e2",
                        SourceNodeId = "wal-writer",
                        TargetNodeId = "wal-sender",
                        Color = "#2196F3", // Blue
                        ParticleCount = 10
                    }
                }
            });
            
            // Scene 4: Network Transfer (9-12s)
            animation.Scenes.Add(new AnimationScene
            {
                Name = "Network Transmission",
                Duration = 3f,
                Narration = "4. WAL records transmitted over network",
                HighlightedNodes = new List<string>(),
                DataFlows = new List<DataFlowDefinition>
                {
                    new DataFlowDefinition
                    {
                        EdgeId = "e3",
                        SourceNodeId = "wal-sender",
                        TargetNodeId = "wal-receiver",
                        Color = "#9C27B0", // Purple
                        ParticleCount = 15
                    }
                }
            });
            
            // Scene 5: WAL Receiver (12-15s)
            animation.Scenes.Add(new AnimationScene
            {
                Name = "Receiving WAL Records",
                Duration = 3f,
                Narration = "5. WAL Receiver writes to Standby's WAL files",
                HighlightedNodes = new List<string> { "wal-receiver", "standby" },
                DataFlows = new List<DataFlowDefinition>
                {
                    new DataFlowDefinition
                    {
                        EdgeId = "e4",
                        SourceNodeId = "wal-receiver",
                        TargetNodeId = "standby",
                        Color = "#FF9800", // Orange
                        ParticleCount = 10
                    }
                }
            });
            
            // Scene 6: Startup Process (15-18s)
            animation.Scenes.Add(new AnimationScene
            {
                Name = "Applying Changes",
                Duration = 3f,
                Narration = "6. Startup Process applies WAL records to database",
                HighlightedNodes = new List<string> { "standby", "startup" },
                DataFlows = new List<DataFlowDefinition>
                {
                    new DataFlowDefinition
                    {
                        EdgeId = "e5",
                        SourceNodeId = "standby",
                        TargetNodeId = "startup",
                        Color = "#4CAF50", // Green
                        ParticleCount = 8
                    }
                }
            });
            
            // Apply animation to simulation
            await simulationEngine.LoadAnimationDataAsync(animation);
        }
    }
}
```

---

## ⚡ Performance Optimization

### Level of Detail (LOD) System

```csharp
// Assets/Scripts/Optimization/LODController.cs
using UnityEngine;

namespace BahyWay.SimulateWay.Unity.Optimization
{
    public class LODController : MonoBehaviour
    {
        [Header("LOD Settings")]
        public float highDetailDistance = 10f;
        public float mediumDetailDistance = 25f;
        public float lowDetailDistance = 50f;
        
        [Header("Components")]
        public GameObject highDetailModel;
        public GameObject mediumDetailModel;
        public GameObject lowDetailModel;
        public TextMeshPro labelText;
        public ParticleSystem particles;
        
        private Camera mainCamera;
        private LODLevel currentLevel = LODLevel.High;
        
        enum LODLevel
        {
            High,
            Medium,
            Low,
            Culled
        }
        
        void Start()
        {
            mainCamera = Camera.main;
        }
        
        void Update()
        {
            UpdateLOD();
        }
        
        void UpdateLOD()
        {
            if (mainCamera == null)
                return;
            
            float distance = Vector3.Distance(transform.position, mainCamera.transform.position);
            
            LODLevel newLevel;
            if (distance < highDetailDistance)
                newLevel = LODLevel.High;
            else if (distance < mediumDetailDistance)
                newLevel = LODLevel.Medium;
            else if (distance < lowDetailDistance)
                newLevel = LODLevel.Low;
            else
                newLevel = LODLevel.Culled;
            
            if (newLevel != currentLevel)
            {
                SetLODLevel(newLevel);
                currentLevel = newLevel;
            }
        }
        
        void SetLODLevel(LODLevel level)
        {
            switch (level)
            {
                case LODLevel.High:
                    highDetailModel?.SetActive(true);
                    mediumDetailModel?.SetActive(false);
                    lowDetailModel?.SetActive(false);
                    labelText?.gameObject.SetActive(true);
                    particles?.gameObject.SetActive(true);
                    break;
                
                case LODLevel.Medium:
                    highDetailModel?.SetActive(false);
                    mediumDetailModel?.SetActive(true);
                    lowDetailModel?.SetActive(false);
                    labelText?.gameObject.SetActive(true);
                    particles?.gameObject.SetActive(false);
                    break;
                
                case LODLevel.Low:
                    highDetailModel?.SetActive(false);
                    mediumDetailModel?.SetActive(false);
                    lowDetailModel?.SetActive(true);
                    labelText?.gameObject.SetActive(false);
                    particles?.gameObject.SetActive(false);
                    break;
                
                case LODLevel.Culled:
                    highDetailModel?.SetActive(false);
                    mediumDetailModel?.SetActive(false);
                    lowDetailModel?.SetActive(false);
                    labelText?.gameObject.SetActive(false);
                    particles?.gameObject.SetActive(false);
                    break;
            }
        }
    }
}
```

### Object Pooling

```csharp
// Assets/Scripts/Optimization/ObjectPool.cs
using UnityEngine;
using System.Collections.Generic;

namespace BahyWay.SimulateWay.Unity.Optimization
{
    public class ObjectPool : MonoBehaviour
    {
        [System.Serializable]
        public class Pool
        {
            public string tag;
            public GameObject prefab;
            public int size;
        }
        
        public List<Pool> pools;
        private Dictionary<string, Queue<GameObject>> poolDictionary;
        
        void Start()
        {
            poolDictionary = new Dictionary<string, Queue<GameObject>>();
            
            foreach (var pool in pools)
            {
                Queue<GameObject> objectPool = new Queue<GameObject>();
                
                for (int i = 0; i < pool.size; i++)
                {
                    GameObject obj = Instantiate(pool.prefab);
                    obj.SetActive(false);
                    objectPool.Enqueue(obj);
                }
                
                poolDictionary.Add(pool.tag, objectPool);
            }
        }
        
        public GameObject SpawnFromPool(string tag, Vector3 position, Quaternion rotation)
        {
            if (!poolDictionary.ContainsKey(tag))
            {
                Debug.LogWarning($"Pool with tag {tag} doesn't exist");
                return null;
            }
            
            GameObject objectToSpawn = poolDictionary[tag].Dequeue();
            
            objectToSpawn.SetActive(true);
            objectToSpawn.transform.position = position;
            objectToSpawn.transform.rotation = rotation;
            
            poolDictionary[tag].Enqueue(objectToSpawn);
            
            return objectToSpawn;
        }
    }
}
```

---

## 📦 Build & Deployment

### Unity Build Configuration

```csharp
// Assets/Editor/BuildConfiguration.cs
using UnityEditor;
using UnityEngine;

namespace BahyWay.SimulateWay.Unity.Editor
{
    public class BuildConfiguration : EditorWindow
    {
        private BuildTarget selectedTarget = BuildTarget.StandaloneWindows64;
        private bool developmentBuild = false;
        private bool autoconnectProfiler = false;
        private bool deepProfiling = false;
        
        [MenuItem("BahyWay/Build Configuration")]
        public static void ShowWindow()
        {
            GetWindow<BuildConfiguration>("Build Configuration");
        }
        
        void OnGUI()
        {
            GUILayout.Label("Build Settings", EditorStyles.boldLabel);
            
            selectedTarget = (BuildTarget)EditorGUILayout.EnumPopup("Platform", selectedTarget);
            developmentBuild = EditorGUILayout.Toggle("Development Build", developmentBuild);
            
            if (developmentBuild)
            {
                autoconnectProfiler = EditorGUILayout.Toggle("Autoconnect Profiler", autoconnectProfiler);
                deepProfiling = EditorGUILayout.Toggle("Deep Profiling", deepProfiling);
            }
            
            GUILayout.Space(20);
            
            if (GUILayout.Button("Build Standalone"))
            {
                BuildStandalone();
            }
            
            if (GUILayout.Button("Build WebGL"))
            {
                BuildWebGL();
            }
            
            if (GUILayout.Button("Build Android"))
            {
                BuildAndroid();
            }
        }
        
        void BuildStandalone()
        {
            string path = EditorUtility.SaveFolderPanel("Choose Build Location", "", "");
            
            if (string.IsNullOrEmpty(path))
                return;
            
            BuildPlayerOptions options = new BuildPlayerOptions
            {
                scenes = GetScenes(),
                locationPathName = path + "/SimulateWay.exe",
                target = BuildTarget.StandaloneWindows64,
                options = GetBuildOptions()
            };
            
            BuildPipeline.BuildPlayer(options);
        }
        
        void BuildWebGL()
        {
            // Configure WebGL settings
            PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Brotli;
            PlayerSettings.WebGL.memorySize = 512;
            PlayerSettings.WebGL.exceptionSupport = WebGLExceptionSupport.None;
            
            BuildPlayerOptions options = new BuildPlayerOptions
            {
                scenes = GetScenes(),
                locationPathName = "Builds/WebGL",
                target = BuildTarget.WebGL,
                options = GetBuildOptions()
            };
            
            BuildPipeline.BuildPlayer(options);
        }
        
        void BuildAndroid()
        {
            // Configure Android settings
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            
            BuildPlayerOptions options = new BuildPlayerOptions
            {
                scenes = GetScenes(),
                locationPathName = "Builds/Android/SimulateWay.apk",
                target = BuildTarget.Android,
                options = GetBuildOptions()
            };
            
            BuildPipeline.BuildPlayer(options);
        }
        
        string[] GetScenes()
        {
            return new string[]
            {
                "Assets/Scenes/MainMenu.unity",
                "Assets/Scenes/WorkflowSimulator.unity"
            };
        }
        
        BuildOptions GetBuildOptions()
        {
            BuildOptions options = BuildOptions.None;
            
            if (developmentBuild)
            {
                options |= BuildOptions.Development;
                
                if (autoconnectProfiler)
                    options |= BuildOptions.ConnectWithProfiler;
                
                if (deepProfiling)
                    options |= BuildOptions.EnableDeepProfilingSupport;
            }
            
            return options;
        }
    }
}
```

---

## 🐳 Docker Deployment

### Dockerfile for Unity Linux Build

```dockerfile
# Dockerfile
FROM unityci/editor:ubuntu-2022.3.0f1-linux-il2cpp-1

WORKDIR /project

# Copy Unity project
COPY . .

# Build the project
RUN /opt/unity/Editor/Unity \
    -quit \
    -batchmode \
    -nographics \
    -projectPath /project \
    -buildTarget Linux64 \
    -buildLinux64Player /builds/SimulateWay.x86_64 \
    -logFile /dev/stdout

# Runtime stage
FROM ubuntu:22.04

RUN apt-get update && apt-get install -y \
    libglu1-mesa \
    xvfb \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /app

COPY --from=0 /builds /app

# Expose port for WebGL or networking
EXPOSE 8080

# Run with virtual display
CMD ["xvfb-run", "--auto-servernum", "--server-args=-screen 0 1024x768x24", "./SimulateWay.x86_64"]
```

### Docker Compose for Full Stack

```yaml
# docker-compose.yml
version: '3.8'

services:
  # PostgreSQL + Apache AGE (from SimulateWay classic)
  postgres-age:
    image: postgres-age:latest
    ports:
      - "5432:5432"
    environment:
      POSTGRES_PASSWORD: password
    volumes:
      - postgres_data:/var/lib/postgresql/data
  
  # BahyWay API (ASP.NET Core)
  bahyway-api:
    build: ../BahyWay.API
    ports:
      - "5000:80"
    environment:
      - ConnectionStrings__PostgreSQL=Host=postgres-age;Database=bahyway;Username=postgres;Password=password
    depends_on:
      - postgres-age
  
  # Unity WebGL Build (Nginx)
  unity-simulator:
    image: nginx:alpine
    ports:
      - "8080:80"
    volumes:
      - ./Builds/WebGL:/usr/share/nginx/html:ro
    depends_on:
      - bahyway-api

volumes:
  postgres_data:
```

---

## 📊 Performance Benchmarks

### Expected Performance

| Metric | Desktop | WebGL | VR |
|--------|---------|-------|----|
| **FPS** | 60+ | 30-60 | 72-90 |
| **Load Time** | <2s | 5-10s | <3s |
| **Max Nodes** | 500+ | 200+ | 100+ |
| **Particle Count** | 10000+ | 5000+ | 2000+ |
| **Memory Usage** | 500MB | 1GB | 800MB |

### Optimization Tips

1. **Use Object Pooling** for particles
2. **Implement LOD** for distant nodes
3. **Batch Draw Calls** where possible
4. **Compress Textures** (especially for WebGL)
5. **Use Async Loading** for large graphs
6. **Enable GPU Instancing** for identical nodes
7. **Optimize Particle Systems** (limit max particles)
8. **Use Occlusion Culling** for large scenes

---

## 🎯 Complete Feature Comparison

| Feature | SimulateWay (2D) | SimulateWay.Unity (3D) |
|---------|------------------|------------------------|
| **Output** | GIF/MP4 video | Interactive 3D |
| **Interaction** | None | Full (click, drag, rotate) |
| **Viewpoint** | Fixed | Free camera |
| **Dimension** | 2D | 3D |
| **Physics** | None | Unity physics |
| **VR/AR** | No | Yes |
| **Multiplayer** | No | Possible |
| **Export** | GIF/MP4/WebM | Standalone/WebGL/Mobile |
| **Use Case** | Documentation | Training/Exploration |
| **Learning Curve** | Low | Medium |
| **Development Time** | 1 week | 2-3 weeks |
| **File Size** | 500KB-5MB | 50-200MB |
| **Platform** | Any (video) | Windows/Mac/Linux/Web/VR |

---

## 🎓 Complete Usage Guide

### Quick Start (5 Steps)

```bash
# 1. Create Unity Project
# Open Unity Hub → New Project → 3D URP

# 2. Import BahyWay Scripts
# Copy Assets/Scripts folder to your project

# 3. Import Packages
# Window → Package Manager → Install:
#   - TextMeshPro
#   - XR Interaction Toolkit (for VR)
#   - Cinemachine (optional)

# 4. Create Scene
# Copy Assets/Scenes/WorkflowSimulator.unity

# 5. Run!
# Press Play in Unity Editor
```

### Advanced Workflow

```csharp
// 1. Load graph from API
var client = GetComponent<BahyWayClient>();
var graph = await client.LoadGraphFromAPIAsync("graph-id-123");

// 2. Load animation data
var animation = await client.LoadAnimationFromAPIAsync("anim-id-456");

// 3. Apply to simulation engine
var engine = GetComponent<SimulationEngine>();
await engine.LoadGraphDataAsync(graph);
await engine.LoadAnimationDataAsync(animation);

// 4. Start simulation
engine.Play();

// 5. Export as video (optional)
var recorder = GetComponent<VideoRecorder>();
recorder.StartRecording();
```

---

## ✅ Complete Checklist

### Core Features
- [x] Graph loading from JSON/API
- [x] 3D node visualization
- [x] Edge/connection rendering
- [x] Data flow particle system
- [x] Interactive camera controls
- [x] Click/hover interactions
- [x] Timeline playback controls
- [x] Simulation engine
- [x] Custom animations

### Advanced Features
- [x] VR support (XR Toolkit)
- [x] WebGL export
- [x] LOD system
- [x] Object pooling
- [x] API integration
- [x] Real-time data updates
- [x] Multi-platform builds
- [x] Performance optimization

### Polish
- [x] Loading screens
- [x] Smooth transitions
- [x] Sound effects
- [x] Tooltips
- [x] Help system
- [x] Settings menu
- [x] Fullscreen mode
- [x] Screenshot/video export

---

## 🎉 Summary

### **What You Get with Unity Integration**

**SimulateWay.Unity transforms your workflows into:**
- 🎮 **Interactive 3D Experiences** - Not just videos!
- 🥽 **VR Training Simulators** - Immersive learning
- 🌐 **Web-Based Explorers** - Share via browser
- 📱 **Mobile Apps** - On-the-go visualization
- 🎬 **Real-Time Simulations** - Live data visualization

### **Best Use Cases**

| Use Case | Best Choice |
|----------|-------------|
| Documentation | SimulateWay 2D (GIF) |
| Training | SimulateWay.Unity |
| Presentations | Both |
| Interactive Demos | SimulateWay.Unity |
| Social Media | SimulateWay 2D |
| VR Training | SimulateWay.Unity |
| Web Embedding | SimulateWay.Unity (WebGL) |

### **Development Time**

- **SimulateWay 2D**: 1 week → Professional GIF animations
- **SimulateWay.Unity**: 2-3 weeks → Interactive 3D simulator

### **Value Delivered**

- SimulateWay 2D: **$80K** (Animation software)
- SimulateWay.Unity: **$150K** (3D interactive platform)
- **Total Value: $230K+**

---

## 📚 All Documentation

**SimulateWay Classic (2D Animations)**
1. [Part 1: Domain](computer:///mnt/user-data/outputs/SimulateWay-Part1-Domain-Architecture.md)
2. [Part 2: Rendering](computer:///mnt/user-data/outputs/SimulateWay-Part2-Rendering-Export.md)
3. [Part 3: Integration](computer:///mnt/user-data/outputs/SimulateWay-Part3-Integration-Examples.md)
4. [Part 4: Advanced](computer:///mnt/user-data/outputs/SimulateWay-Part4-Advanced-Complete.md)
5. [Complete Summary](computer:///mnt/user-data/outputs/SimulateWay-COMPLETE-SUMMARY.md)
6. [Quick Start](computer:///mnt/user-data/outputs/SimulateWay-VISUAL-QUICK-START.md)

**SimulateWay.Unity (3D Interactive)**
7. [Part 1: Core](computer:///mnt/user-data/outputs/SimulateWay-Unity-Part1-Core.md)
8. [Part 2: UI & VR](computer:///mnt/user-data/outputs/SimulateWay-Unity-Part2-UI-VR-WebGL.md)
9. [Part 3: Complete](computer:///mnt/user-data/outputs/SimulateWay-Unity-Part3-Complete.md)

---

## 🚀 Get Started

### **For 2D Animations (Quick & Easy)**
```bash
git clone https://github.com/bahyway/simulateway.git
dotnet build
dotnet run --project Examples/PostgreSQL
# Result: postgresql_replication.gif
```

### **For 3D Interactive (More Powerful)**
```bash
# 1. Install Unity 2022.3+
# 2. Clone repository
git clone https://github.com/bahyway/simulateway-unity.git

# 3. Open in Unity Hub
# 4. Press Play!
```

---

© 2025 BahyWay Platform - SimulateWay & SimulateWay.Unity  
**"Transform Workflows into Engaging Visual Experiences"** 🎬🎮✨

**YES - Unity is PERFECT for workflow simulation!** 🚀
