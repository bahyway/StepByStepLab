# BahyWay AlarmManagement - Infrastructure Layer

This layer implements all interfaces defined in Domain and Application layers. It contains all external concerns: database, APIs, file system, etc.

---

## 📦 Dependencies

```xml
<ItemGroup>
  <!-- Domain & Application -->
  <ProjectReference Include="..\BahyWay.AlarmManagement.Domain\BahyWay.AlarmManagement.Domain.csproj" />
  <ProjectReference Include="..\BahyWay.AlarmManagement.Application\BahyWay.AlarmManagement.Application.csproj" />
  <ProjectReference Include="..\..\BuildingBlocks\BahyWay.BuildingBlocks.Infrastructure\BahyWay.BuildingBlocks.Infrastructure.csproj" />
  
  <!-- Entity Framework Core -->
  <PackageReference Include="Microsoft.EntityFrameworkCore" Version="8.0.0" />
  <PackageReference Include="Microsoft.EntityFrameworkCore.Design" Version="8.0.0" />
  <PackageReference Include="Npgsql.EntityFrameworkCore.PostgreSQL" Version="8.0.0" />
  
  <!-- HTTP Client -->
  <PackageReference Include="Microsoft.Extensions.Http" Version="8.0.0" />
  <PackageReference Include="Microsoft.Extensions.Http.Polly" Version="8.0.0" />
  
  <!-- Caching -->
  <PackageReference Include="Microsoft.Extensions.Caching.StackExchangeRedis" Version="8.0.0" />
  
  <!-- Configuration -->
  <PackageReference Include="Microsoft.Extensions.Options.ConfigurationExtensions" Version="8.0.0" />
</ItemGroup>
```

---

## 💾 EF Core DbContext

```csharp
// Persistence/AlarmManagementDbContext.cs
using Microsoft.EntityFrameworkCore;
using BahyWay.SharedKernel.Domain;
using BahyWay.SharedKernel.Interfaces;
using BahyWay.AlarmManagement.Domain.Aggregates.Alarm;
using BahyWay.AlarmManagement.Domain.Aggregates.Asset;

namespace BahyWay.AlarmManagement.Infrastructure.Persistence;

public sealed class AlarmManagementDbContext : DbContext, IUnitOfWork
{
    private readonly IDomainEventDispatcher _domainEventDispatcher;

    public DbSet<Alarm> Alarms => Set<Alarm>();
    public DbSet<Asset> Assets => Set<Asset>();

    public AlarmManagementDbContext(
        DbContextOptions<AlarmManagementDbContext> options,
        IDomainEventDispatcher domainEventDispatcher)
        : base(options)
    {
        _domainEventDispatcher = domainEventDispatcher;
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Apply all configurations
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(AlarmManagementDbContext).Assembly);

        // Schema
        modelBuilder.HasDefaultSchema("alarm_management");
    }

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        // Get all domain events before saving
        var domainEvents = ChangeTracker
            .Entries<AggregateRoot<AlarmId>>()
            .Select(e => e.Entity)
            .Where(e => e.DomainEvents.Any())
            .SelectMany(e => e.DomainEvents)
            .ToList();

        // Also check Asset aggregates
        var assetEvents = ChangeTracker
            .Entries<AggregateRoot<AssetId>>()
            .Select(e => e.Entity)
            .Where(e => e.DomainEvents.Any())
            .SelectMany(e => e.DomainEvents)
            .ToList();

        domainEvents.AddRange(assetEvents);

        // Save changes
        var result = await base.SaveChangesAsync(cancellationToken);

        // Dispatch domain events after successful save
        if (domainEvents.Any())
        {
            await _domainEventDispatcher.DispatchAsync(domainEvents, cancellationToken);

            // Clear events
            ChangeTracker
                .Entries<AggregateRoot<AlarmId>>()
                .Select(e => e.Entity)
                .ToList()
                .ForEach(e => e.ClearDomainEvents());

            ChangeTracker
                .Entries<AggregateRoot<AssetId>>()
                .Select(e => e.Entity)
                .ToList()
                .ForEach(e => e.ClearDomainEvents());
        }

        return result;
    }

    public async Task BeginTransactionAsync(CancellationToken cancellationToken = default)
    {
        if (Database.CurrentTransaction == null)
        {
            await Database.BeginTransactionAsync(cancellationToken);
        }
    }

    public async Task CommitTransactionAsync(CancellationToken cancellationToken = default)
    {
        if (Database.CurrentTransaction != null)
        {
            await Database.CommitTransactionAsync(cancellationToken);
        }
    }

    public async Task RollbackTransactionAsync(CancellationToken cancellationToken = default)
    {
        if (Database.CurrentTransaction != null)
        {
            await Database.RollbackTransactionAsync(cancellationToken);
        }
    }
}
```

---

## 🗃️ EF Core Configurations

```csharp
// Persistence/Configurations/AlarmConfiguration.cs
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using BahyWay.AlarmManagement.Domain.Aggregates.Alarm;
using BahyWay.AlarmManagement.Domain.Aggregates.Asset;
using BahyWay.AlarmManagement.Domain.ValueObjects;

namespace BahyWay.AlarmManagement.Infrastructure.Persistence.Configurations;

internal sealed class AlarmConfiguration : IEntityTypeConfiguration<Alarm>
{
    public void Configure(EntityTypeBuilder<Alarm> builder)
    {
        builder.ToTable("alarms");

        // Primary Key
        builder.HasKey(a => a.Id);
        builder.Property(a => a.Id)
            .HasConversion(
                id => id.Value,
                value => AlarmId.From(value))
            .HasColumnName("id");

        // Foreign Key
        builder.Property(a => a.AssetId)
            .HasConversion(
                id => id.Value,
                value => AssetId.From(value))
            .HasColumnName("asset_id")
            .IsRequired();

        builder.HasIndex(a => a.AssetId)
            .HasDatabaseName("ix_alarms_asset_id");

        // Severity (stored as int)
        builder.Property(a => a.Severity)
            .HasConversion(
                severity => severity.Value,
                value => AlarmSeverity.FromValue<AlarmSeverity>(value))
            .HasColumnName("severity")
            .IsRequired();

        builder.HasIndex(a => a.Severity)
            .HasDatabaseName("ix_alarms_severity");

        // Status (stored as int)
        builder.Property(a => a.Status)
            .HasConversion(
                status => status.Value,
                value => AlarmStatus.FromValue<AlarmStatus>(value))
            .HasColumnName("status")
            .IsRequired();

        builder.HasIndex(a => a.Status)
            .HasDatabaseName("ix_alarms_status");

        // Value Object (owned entity)
        builder.OwnsOne(a => a.Value, valueBuilder =>
        {
            valueBuilder.Property(v => v.Value)
                .HasColumnName("value")
                .IsRequired();

            valueBuilder.Property(v => v.Unit)
                .HasColumnName("unit")
                .HasMaxLength(20)
                .IsRequired();

            valueBuilder.Property(v => v.MeasuredAt)
                .HasColumnName("measured_at")
                .IsRequired();
        });

        // Location (owned entity, nullable)
        builder.OwnsOne(a => a.Location, locationBuilder =>
        {
            locationBuilder.Property(l => l.Latitude)
                .HasColumnName("latitude")
                .HasPrecision(10, 7);

            locationBuilder.Property(l => l.Longitude)
                .HasColumnName("longitude")
                .HasPrecision(10, 7);

            locationBuilder.Property(l => l.Altitude)
                .HasColumnName("altitude")
                .HasPrecision(10, 2);
        });

        // Strings
        builder.Property(a => a.Message)
            .HasColumnName("message")
            .HasMaxLength(500)
            .IsRequired();

        builder.Property(a => a.Description)
            .HasColumnName("description")
            .HasMaxLength(2000);

        builder.Property(a => a.AcknowledgedBy)
            .HasColumnName("acknowledged_by")
            .HasMaxLength(100);

        builder.Property(a => a.ResolvedBy)
            .HasColumnName("resolved_by")
            .HasMaxLength(100);

        builder.Property(a => a.Resolution)
            .HasColumnName("resolution")
            .HasMaxLength(2000);

        // Timestamps
        builder.Property(a => a.OccurredAt)
            .HasColumnName("occurred_at")
            .IsRequired();

        builder.HasIndex(a => a.OccurredAt)
            .HasDatabaseName("ix_alarms_occurred_at");

        builder.Property(a => a.AcknowledgedAt)
            .HasColumnName("acknowledged_at");

        builder.Property(a => a.ResolvedAt)
            .HasColumnName("resolved_at");

        // Metrics
        builder.Property(a => a.EscalationCount)
            .HasColumnName("escalation_count")
            .HasDefaultValue(0);

        // Concurrency
        builder.Property(a => a.Version)
            .HasColumnName("version")
            .IsRowVersion();

        // Ignore domain events (not persisted)
        builder.Ignore(a => a.DomainEvents);
    }
}

// Persistence/Configurations/AssetConfiguration.cs
internal sealed class AssetConfiguration : IEntityTypeConfiguration<Asset>
{
    public void Configure(EntityTypeBuilder<Asset> builder)
    {
        builder.ToTable("assets");

        builder.HasKey(a => a.Id);
        builder.Property(a => a.Id)
            .HasConversion(
                id => id.Value,
                value => AssetId.From(value))
            .HasColumnName("id");

        builder.Property(a => a.Name)
            .HasColumnName("name")
            .HasMaxLength(200)
            .IsRequired();

        builder.HasIndex(a => a.Name)
            .IsUnique()
            .HasDatabaseName("uq_assets_name");

        builder.Property(a => a.Description)
            .HasColumnName("description")
            .HasMaxLength(2000);

        builder.Property(a => a.Type)
            .HasConversion(
                type => type.Value,
                value => AssetType.FromValue<AssetType>(value))
            .HasColumnName("type")
            .IsRequired();

        builder.OwnsOne(a => a.Location, locationBuilder =>
        {
            locationBuilder.Property(l => l.Latitude)
                .HasColumnName("latitude")
                .HasPrecision(10, 7);

            locationBuilder.Property(l => l.Longitude)
                .HasColumnName("longitude")
                .HasPrecision(10, 7);

            locationBuilder.Property(l => l.Altitude)
                .HasColumnName("altitude")
                .HasPrecision(10, 2);
        });

        builder.Property(a => a.IsActive)
            .HasColumnName("is_active")
            .HasDefaultValue(true)
            .IsRequired();

        builder.HasIndex(a => a.IsActive)
            .HasDatabaseName("ix_assets_is_active");

        builder.Property(a => a.CreatedAt)
            .HasColumnName("created_at")
            .IsRequired();

        builder.Property(a => a.LastMaintenanceDate)
            .HasColumnName("last_maintenance_date");

        builder.Property(a => a.Version)
            .HasColumnName("version")
            .IsRowVersion();

        builder.Ignore(a => a.DomainEvents);
        builder.Ignore(a => a.Thresholds); // Handle separately if needed
    }
}
```

---

## 📚 Repository Implementations

```csharp
// Persistence/Repositories/AlarmRepository.cs
using Microsoft.EntityFrameworkCore;
using BahyWay.AlarmManagement.Domain.Aggregates.Alarm;
using BahyWay.AlarmManagement.Domain.Aggregates.Asset;
using BahyWay.AlarmManagement.Domain.Repositories;
using BahyWay.SharedKernel.Domain;

namespace BahyWay.AlarmManagement.Infrastructure.Persistence.Repositories;

internal sealed class AlarmRepository : IAlarmRepository
{
    private readonly AlarmManagementDbContext _context;

    public AlarmRepository(AlarmManagementDbContext context)
    {
        _context = context;
    }

    public async Task<Alarm?> GetByIdAsync(AlarmId id, CancellationToken cancellationToken = default)
    {
        return await _context.Alarms
            .FirstOrDefaultAsync(a => a.Id == id, cancellationToken);
    }

    public async Task<List<Alarm>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _context.Alarms
            .OrderByDescending(a => a.OccurredAt)
            .ToListAsync(cancellationToken);
    }

    public async Task AddAsync(Alarm aggregate, CancellationToken cancellationToken = default)
    {
        await _context.Alarms.AddAsync(aggregate, cancellationToken);
    }

    public void Update(Alarm aggregate)
    {
        _context.Alarms.Update(aggregate);
    }

    public void Remove(Alarm aggregate)
    {
        _context.Alarms.Remove(aggregate);
    }

    public async Task<bool> ExistsAsync(AlarmId id, CancellationToken cancellationToken = default)
    {
        return await _context.Alarms
            .AnyAsync(a => a.Id == id, cancellationToken);
    }

    public async Task<List<Alarm>> FindAsync(
        ISpecification<Alarm> specification,
        CancellationToken cancellationToken = default)
    {
        return await ApplySpecification(specification)
            .ToListAsync(cancellationToken);
    }

    public async Task<List<Alarm>> GetActiveAlarmsAsync(CancellationToken cancellationToken = default)
    {
        return await _context.Alarms
            .Where(a => a.Status == AlarmStatus.Active)
            .OrderByDescending(a => a.Severity.Value)
            .ThenByDescending(a => a.OccurredAt)
            .ToListAsync(cancellationToken);
    }

    public async Task<List<Alarm>> GetCriticalAlarmsAsync(CancellationToken cancellationToken = default)
    {
        return await _context.Alarms
            .Where(a => a.Severity == AlarmSeverity.Critical && a.Status == AlarmStatus.Active)
            .OrderBy(a => a.OccurredAt)
            .ToListAsync(cancellationToken);
    }

    public async Task<List<Alarm>> GetOverdueAlarmsAsync(CancellationToken cancellationToken = default)
    {
        var now = DateTime.UtcNow;
        
        return await _context.Alarms
            .Where(a => a.Status == AlarmStatus.Active)
            .ToListAsync(cancellationToken)
            .ContinueWith(task => 
                task.Result.Where(a => a.IsOverdue()).ToList(), 
                cancellationToken);
    }

    public async Task<List<Alarm>> GetAlarmsByAssetAsync(
        AssetId assetId,
        CancellationToken cancellationToken = default)
    {
        return await _context.Alarms
            .Where(a => a.AssetId == assetId)
            .OrderByDescending(a => a.OccurredAt)
            .ToListAsync(cancellationToken);
    }

    public async Task<List<Alarm>> GetAlarmsInDateRangeAsync(
        DateTime startDate,
        DateTime endDate,
        CancellationToken cancellationToken = default)
    {
        return await _context.Alarms
            .Where(a => a.OccurredAt >= startDate && a.OccurredAt <= endDate)
            .OrderByDescending(a => a.OccurredAt)
            .ToListAsync(cancellationToken);
    }

    public async Task<int> GetActiveAlarmCountAsync(CancellationToken cancellationToken = default)
    {
        return await _context.Alarms
            .CountAsync(a => a.Status == AlarmStatus.Active, cancellationToken);
    }

    public async Task<Dictionary<AlarmSeverity, int>> GetAlarmCountBySeverityAsync(
        CancellationToken cancellationToken = default)
    {
        var alarms = await _context.Alarms
            .Where(a => a.Status == AlarmStatus.Active)
            .GroupBy(a => a.Severity)
            .Select(g => new { Severity = g.Key, Count = g.Count() })
            .ToListAsync(cancellationToken);

        return alarms.ToDictionary(x => x.Severity, x => x.Count);
    }

    private IQueryable<Alarm> ApplySpecification(ISpecification<Alarm> specification)
    {
        var query = _context.Alarms.AsQueryable();

        if (specification.Criteria != null)
        {
            query = query.Where(specification.Criteria);
        }

        query = specification.Includes
            .Aggregate(query, (current, include) => current.Include(include));

        if (specification.OrderBy != null)
        {
            query = query.OrderBy(specification.OrderBy);
        }
        else if (specification.OrderByDescending != null)
        {
            query = query.OrderByDescending(specification.OrderByDescending);
        }

        if (specification.IsPagingEnabled)
        {
            query = query.Skip(specification.Skip).Take(specification.Take);
        }

        return query;
    }
}

// Persistence/Repositories/AssetRepository.cs
internal sealed class AssetRepository : IAssetRepository
{
    private readonly AlarmManagementDbContext _context;

    public AssetRepository(AlarmManagementDbContext context)
    {
        _context = context;
    }

    public async Task<Asset?> GetByIdAsync(AssetId id, CancellationToken cancellationToken = default)
    {
        return await _context.Assets
            .FirstOrDefaultAsync(a => a.Id == id, cancellationToken);
    }

    public async Task<List<Asset>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _context.Assets.ToListAsync(cancellationToken);
    }

    public async Task AddAsync(Asset aggregate, CancellationToken cancellationToken = default)
    {
        await _context.Assets.AddAsync(aggregate, cancellationToken);
    }

    public void Update(Asset aggregate)
    {
        _context.Assets.Update(aggregate);
    }

    public void Remove(Asset aggregate)
    {
        _context.Assets.Remove(aggregate);
    }

    public async Task<bool> ExistsAsync(AssetId id, CancellationToken cancellationToken = default)
    {
        return await _context.Assets
            .AnyAsync(a => a.Id == id, cancellationToken);
    }

    public async Task<List<Asset>> FindAsync(
        ISpecification<Asset> specification,
        CancellationToken cancellationToken = default)
    {
        // Similar to AlarmRepository
        throw new NotImplementedException();
    }

    public async Task<List<Asset>> GetActiveAssetsAsync(CancellationToken cancellationToken = default)
    {
        return await _context.Assets
            .Where(a => a.IsActive)
            .OrderBy(a => a.Name)
            .ToListAsync(cancellationToken);
    }

    public async Task<Asset?> GetByNameAsync(string name, CancellationToken cancellationToken = default)
    {
        return await _context.Assets
            .FirstOrDefaultAsync(a => a.Name == name, cancellationToken);
    }

    public async Task<List<Asset>> GetAssetsByTypeAsync(
        AssetType type,
        CancellationToken cancellationToken = default)
    {
        return await _context.Assets
            .Where(a => a.Type == type)
            .OrderBy(a => a.Name)
            .ToListAsync(cancellationToken);
    }

    public async Task<List<Asset>> GetAssetsNearLocationAsync(
        GeoLocation location,
        double radiusKm,
        CancellationToken cancellationToken = default)
    {
        // Get all assets with locations
        var assets = await _context.Assets
            .Where(a => a.Location != null)
            .ToListAsync(cancellationToken);

        // Filter by distance in memory (or use PostGIS for better performance)
        return assets
            .Where(a => a.Location!.DistanceTo(location) <= radiusKm)
            .OrderBy(a => a.Location!.DistanceTo(location))
            .ToList();
    }
}
```

---

## 🔗 External Services

```csharp
// ExternalServices/RulesEngineService.cs
using System.Net.Http.Json;

namespace BahyWay.AlarmManagement.Infrastructure.ExternalServices;

public interface IRulesEngineService
{
    Task<RuleEvaluationResult> EvaluateAlarmRulesAsync(
        Guid alarmId,
        CancellationToken cancellationToken = default);
}

internal sealed class RulesEngineService : IRulesEngineService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<RulesEngineService> _logger;

    public RulesEngineService(HttpClient httpClient, ILogger<RulesEngineService> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
    }

    public async Task<RuleEvaluationResult> EvaluateAlarmRulesAsync(
        Guid alarmId,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var request = new { rule_set = "alarm-rules", context = new { alarm_id = alarmId } };

            var response = await _httpClient.PostAsJsonAsync(
                "/api/evaluate",
                request,
                cancellationToken);

            response.EnsureSuccessStatusCode();

            var result = await response.Content.ReadFromJsonAsync<RuleEvaluationResult>(
                cancellationToken);

            return result ?? new RuleEvaluationResult { Success = false };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to evaluate rules for alarm {AlarmId}", alarmId);
            return new RuleEvaluationResult { Success = false, Error = ex.Message };
        }
    }
}

public sealed class RuleEvaluationResult
{
    public bool Success { get; init; }
    public string? Error { get; init; }
    public Dictionary<string, object>? Actions { get; init; }
}

// ExternalServices/NotificationService.cs
public interface INotificationService
{
    Task SendAlarmNotificationAsync(
        AlarmDto alarm,
        string[] recipients,
        CancellationToken cancellationToken = default);
}

internal sealed class NotificationService : INotificationService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<NotificationService> _logger;

    public NotificationService(HttpClient httpClient, ILogger<NotificationService> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
    }

    public async Task SendAlarmNotificationAsync(
        AlarmDto alarm,
        string[] recipients,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var notification = new
            {
                type = "alarm",
                severity = alarm.SeverityName,
                message = alarm.Message,
                recipients = recipients,
                metadata = new { alarm_id = alarm.Id, asset_id = alarm.AssetId }
            };

            await _httpClient.PostAsJsonAsync(
                "/api/notifications/send",
                notification,
                cancellationToken);

            _logger.LogInformation(
                "Sent notification for alarm {AlarmId} to {RecipientCount} recipients",
                alarm.Id,
                recipients.Length);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to send notification for alarm {AlarmId}", alarm.Id);
            // Don't throw - notifications are non-critical
        }
    }
}
```

---

## 📬 Domain Event Handlers

```csharp
// EventHandlers/AlarmCreatedEventHandler.cs
using MediatR;
using BahyWay.SharedKernel.Interfaces;
using BahyWay.AlarmManagement.Domain.Events;

namespace BahyWay.AlarmManagement.Infrastructure.EventHandlers;

internal sealed class AlarmCreatedEventHandler : IDomainEventHandler<AlarmCreatedEvent>
{
    private readonly INotificationService _notificationService;
    private readonly IRulesEngineService _rulesEngineService;
    private readonly ILogger<AlarmCreatedEventHandler> _logger;

    public AlarmCreatedEventHandler(
        INotificationService notificationService,
        IRulesEngineService rulesEngineService,
        ILogger<AlarmCreatedEventHandler> logger)
    {
        _notificationService = notificationService;
        _rulesEngineService = rulesEngineService;
        _logger = logger;
    }

    public async Task Handle(AlarmCreatedEvent domainEvent, CancellationToken cancellationToken)
    {
        _logger.LogInformation(
            "Handling AlarmCreatedEvent for alarm {AlarmId}",
            domainEvent.AlarmId);

        // Evaluate rules
        var ruleResult = await _rulesEngineService.EvaluateAlarmRulesAsync(
            domainEvent.AlarmId.Value,
            cancellationToken);

        if (ruleResult.Success && ruleResult.Actions != null)
        {
            // Execute actions based on rule evaluation
            if (ruleResult.Actions.ContainsKey("notify"))
            {
                // Send notifications
                // Implementation depends on your notification requirements
            }
        }

        // Log to external system, send to message queue, etc.
    }
}

// EventHandlers/AlarmEscalatedEventHandler.cs
internal sealed class AlarmEscalatedEventHandler : IDomainEventHandler<AlarmEscalatedEvent>
{
    private readonly INotificationService _notificationService;
    private readonly ILogger<AlarmEscalatedEventHandler> _logger;

    public AlarmEscalatedEventHandler(
        INotificationService notificationService,
        ILogger<AlarmEscalatedEventHandler> logger)
    {
        _notificationService = notificationService;
        _logger = logger;
    }

    public async Task Handle(AlarmEscalatedEvent domainEvent, CancellationToken cancellationToken)
    {
        _logger.LogWarning(
            "Alarm {AlarmId} escalated from {OldSeverity} to {NewSeverity}. Reason: {Reason}",
            domainEvent.AlarmId,
            domainEvent.OldSeverity.Name,
            domainEvent.NewSeverity.Name,
            domainEvent.Reason);

        // Send urgent notifications
        // Trigger additional workflows
        // Update dashboards
    }
}
```

---

## 🔧 Dependency Injection

```csharp
// DependencyInjection.cs
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using BahyWay.SharedKernel.Interfaces;
using BahyWay.AlarmManagement.Domain.Repositories;
using BahyWay.AlarmManagement.Infrastructure.Persistence;
using BahyWay.AlarmManagement.Infrastructure.Persistence.Repositories;
using BahyWay.AlarmManagement.Infrastructure.ExternalServices;

namespace BahyWay.AlarmManagement.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructureLayer(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        // Database
        services.AddDbContext<AlarmManagementDbContext>(options =>
            options.UseNpgsql(
                configuration.GetConnectionString("AlarmManagement"),
                npgsqlOptions =>
                {
                    npgsqlOptions.MigrationsHistoryTable("__migrations_history", "alarm_management");
                    npgsqlOptions.EnableRetryOnFailure(3);
                }));

        // Unit of Work
        services.AddScoped<IUnitOfWork>(sp => sp.GetRequiredService<AlarmManagementDbContext>());

        // Repositories
        services.AddScoped<IAlarmRepository, AlarmRepository>();
        services.AddScoped<IAssetRepository, AssetRepository>();

        // External Services
        services.AddHttpClient<IRulesEngineService, RulesEngineService>(client =>
        {
            client.BaseAddress = new Uri(configuration["Services:RulesEngine:Url"]!);
            client.Timeout = TimeSpan.FromSeconds(30);
        })
        .AddPolicyHandler(GetRetryPolicy())
        .AddPolicyHandler(GetCircuitBreakerPolicy());

        services.AddHttpClient<INotificationService, NotificationService>(client =>
        {
            client.BaseAddress = new Uri(configuration["Services:Notifications:Url"]!);
            client.Timeout = TimeSpan.FromSeconds(10);
        });

        // Domain Event Dispatcher
        services.AddScoped<IDomainEventDispatcher, DomainEventDispatcher>();

        // Caching (if needed)
        services.AddStackExchangeRedisCache(options =>
        {
            options.Configuration = configuration.GetConnectionString("Redis");
        });

        return services;
    }

    private static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy()
    {
        return HttpPolicyExtensions
            .HandleTransientHttpError()
            .WaitAndRetryAsync(3, retryAttempt => 
                TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));
    }

    private static IAsyncPolicy<HttpResponseMessage> GetCircuitBreakerPolicy()
    {
        return HttpPolicyExtensions
            .HandleTransientHttpError()
            .CircuitBreakerAsync(5, TimeSpan.FromSeconds(30));
    }
}

// Domain Event Dispatcher Implementation
internal sealed class DomainEventDispatcher : IDomainEventDispatcher
{
    private readonly IServiceProvider _serviceProvider;

    public DomainEventDispatcher(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    public async Task DispatchAsync(
        IEnumerable<IDomainEvent> domainEvents,
        CancellationToken cancellationToken = default)
    {
        foreach (var domainEvent in domainEvents)
        {
            var handlerType = typeof(IDomainEventHandler<>).MakeGenericType(domainEvent.GetType());
            var handlers = _serviceProvider.GetServices(handlerType);

            foreach (var handler in handlers)
            {
                var method = handlerType.GetMethod(nameof(IDomainEventHandler<IDomainEvent>.Handle));
                await (Task)method!.Invoke(handler, new object[] { domainEvent, cancellationToken })!;
            }
        }
    }
}
```

---

## 🗄️ Database Migration

```bash
# Install EF Core tools
dotnet tool install --global dotnet-ef

# Create initial migration
dotnet ef migrations add InitialCreate \
    --project src/BahyWay.AlarmManagement.Infrastructure \
    --startup-project src/BahyWay.AlarmManagement.API \
    --output-dir Persistence/Migrations

# Update database
dotnet ef database update \
    --project src/BahyWay.AlarmManagement.Infrastructure \
    --startup-project src/BahyWay.AlarmManagement.API
```

---

## ✅ Infrastructure Layer Benefits

✅ **EF Core:** Type-safe database access  
✅ **Value Converters:** Domain types stored correctly  
✅ **Domain Events:** Automatically dispatched after save  
✅ **Transactions:** Automatic transaction management  
✅ **Specifications:** Reusable query logic  
✅ **HTTP Clients:** Configured with retry & circuit breaker  
✅ **Testability:** Can mock all interfaces  

---

**Next: API Layer & Avalonia Desktop App**
