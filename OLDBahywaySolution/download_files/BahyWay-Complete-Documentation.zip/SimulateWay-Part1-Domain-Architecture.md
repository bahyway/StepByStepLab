# SimulateWay - Workflow Animation & Simulation Engine

## 🎬 Overview

**SimulateWay** is a comprehensive animation and simulation engine for the BahyWay platform that transforms static workflow diagrams into dynamic, step-by-step animated GIF/video explanations. Perfect for technical documentation, training materials, and architectural presentations.

---

## 🎯 What SimulateWay Does

### **Core Capabilities**
1. **Animate Workflows** - Convert KGEditorWay graphs into step-by-step animations
2. **Timeline Editor** - Visual timeline for controlling animation sequences
3. **Multiple Export Formats** - GIF, MP4, WebM, animated SVG
4. **Highlighting System** - Highlight active nodes, edges, and data flow
5. **Text Annotations** - Add explanatory text that appears at each step
6. **Custom Transitions** - Fade, slide, zoom, pulse effects
7. **Data Visualization** - Show data flowing through the pipeline
8. **Playback Controls** - Play, pause, step-forward, step-back

---

## 📦 Project Structure

```
BahyWay.SimulateWay/
├── Domain/
│   ├── Aggregates/
│   │   ├── Animation/
│   │   │   ├── Animation.cs                 # Root aggregate
│   │   │   ├── AnimationId.cs
│   │   │   ├── Timeline.cs                  # Animation timeline
│   │   │   ├── Keyframe.cs                  # Animation keyframe
│   │   │   └── AnimationState.cs
│   │   ├── Scene/
│   │   │   ├── Scene.cs                     # Single animation scene
│   │   │   ├── SceneId.cs
│   │   │   ├── SceneElement.cs              # Elements in scene
│   │   │   └── SceneTransition.cs
│   │   └── Effect/
│   │       ├── Effect.cs                    # Animation effect
│   │       ├── HighlightEffect.cs
│   │       ├── FadeEffect.cs
│   │       ├── PulseEffect.cs
│   │       └── DataFlowEffect.cs
│   └── ValueObjects/
│       ├── Duration.cs                      # Animation duration
│       ├── EasingFunction.cs                # Easing curves
│       ├── Color.cs
│       └── AnimationCurve.cs
├── Application/
│   ├── Commands/
│   │   ├── CreateAnimation/
│   │   ├── AddKeyframe/
│   │   ├── UpdateTimeline/
│   │   └── ExportAnimation/
│   ├── Queries/
│   │   ├── GetAnimation/
│   │   ├── GetTimeline/
│   │   └── PreviewFrame/
│   └── Services/
│       ├── IAnimationEngine.cs
│       ├── ITimelineService.cs
│       └── IExportService.cs
├── Infrastructure/
│   ├── Rendering/
│   │   ├── SkiaSharpRenderer.cs             # 2D rendering
│   │   ├── CanvasRenderer.cs
│   │   └── SvgRenderer.cs
│   ├── Export/
│   │   ├── GifExporter.cs                   # GIF export
│   │   ├── Mp4Exporter.cs                   # Video export
│   │   ├── WebMExporter.cs
│   │   └── AnimatedSvgExporter.cs
│   ├── Effects/
│   │   ├── HighlightEffectRenderer.cs
│   │   ├── FadeEffectRenderer.cs
│   │   ├── PulseEffectRenderer.cs
│   │   └── DataFlowEffectRenderer.cs
│   └── Timeline/
│       ├── TimelineEngine.cs
│       └── KeyframeInterpolator.cs
└── Desktop/
    ├── ViewModels/
    │   ├── AnimationEditorViewModel.cs
    │   ├── TimelineViewModel.cs
    │   ├── KeyframeEditorViewModel.cs
    │   └── PreviewViewModel.cs
    └── Views/
        ├── AnimationEditorView.axaml
        ├── TimelineView.axaml
        ├── KeyframeEditorView.axaml
        └── PreviewView.axaml
```

---

## 🎨 Domain Model

### Animation.cs

```csharp
// Domain/Aggregates/Animation/Animation.cs
using System;
using System.Collections.Generic;
using BahyWay.SharedKernel;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.SimulateWay.Domain.Aggregates.Animation;

public class Animation : AggregateRoot<AnimationId>
{
    private readonly List<Scene> _scenes = new();
    private readonly Timeline _timeline;
    
    public string Name { get; private set; }
    public string Description { get; private set; }
    public GraphId SourceGraphId { get; private set; }
    public Duration TotalDuration { get; private set; }
    public AnimationSettings Settings { get; private set; }
    public IReadOnlyList<Scene> Scenes => _scenes.AsReadOnly();
    public Timeline Timeline => _timeline;
    
    private Animation() { } // EF
    
    private Animation(
        AnimationId id,
        string name,
        GraphId sourceGraphId,
        AnimationSettings settings) : base(id)
    {
        Name = Guard.Against.NullOrEmpty(name, nameof(name));
        SourceGraphId = Guard.Against.Null(sourceGraphId, nameof(sourceGraphId));
        Settings = Guard.Against.Null(settings, nameof(settings));
        _timeline = new Timeline(Duration.FromSeconds(0));
        TotalDuration = Duration.FromSeconds(0);
    }
    
    public static Animation Create(
        string name,
        GraphId sourceGraphId,
        AnimationSettings settings)
    {
        var animation = new Animation(
            AnimationId.Create(),
            name,
            sourceGraphId,
            settings);
        
        animation.AddDomainEvent(new AnimationCreatedEvent(animation.Id, name));
        
        return animation;
    }
    
    public Result<Scene> AddScene(
        string name,
        Duration duration,
        List<SceneElement> elements)
    {
        var scene = Scene.Create(name, duration, elements);
        
        if (scene.IsFailure)
            return Result.Failure<Scene>(scene.Error);
        
        _scenes.Add(scene.Value);
        
        // Update timeline
        _timeline.AddKeyframe(TotalDuration, scene.Value);
        TotalDuration = TotalDuration.Add(duration);
        
        AddDomainEvent(new SceneAddedEvent(Id, scene.Value.Id));
        
        return Result.Success(scene.Value);
    }
    
    public Result<Keyframe> AddKeyframe(
        Duration time,
        Scene scene,
        KeyframeType type)
    {
        if (time > TotalDuration)
        {
            return Result.Failure<Keyframe>(
                new Error("Animation.InvalidTime", 
                    "Keyframe time exceeds animation duration"));
        }
        
        var keyframe = _timeline.AddKeyframe(time, scene, type);
        
        AddDomainEvent(new KeyframeAddedEvent(Id, keyframe.Id));
        
        return Result.Success(keyframe);
    }
    
    public Result UpdateSettings(AnimationSettings settings)
    {
        Settings = Guard.Against.Null(settings, nameof(settings));
        
        AddDomainEvent(new AnimationSettingsUpdatedEvent(Id));
        
        return Result.Success();
    }
    
    public Result<Scene> GetSceneAtTime(Duration time)
    {
        return _timeline.GetSceneAtTime(time);
    }
}

public class AnimationId : EntityId
{
    private AnimationId(Guid value) : base(value) { }
    
    public static AnimationId Create() => new(Guid.NewGuid());
    public static AnimationId From(Guid value) => new(value);
}

public class AnimationSettings : ValueObject
{
    public int Width { get; init; } = 1920;
    public int Height { get; init; } = 1080;
    public int FrameRate { get; init; } = 30;
    public Color BackgroundColor { get; init; } = Color.White;
    public bool ShowGrid { get; init; } = false;
    public bool ShowTimestamps { get; init; } = true;
    
    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Width;
        yield return Height;
        yield return FrameRate;
        yield return BackgroundColor;
        yield return ShowGrid;
        yield return ShowTimestamps;
    }
}
```

### Scene.cs

```csharp
// Domain/Aggregates/Animation/Scene.cs
public class Scene : Entity<SceneId>
{
    private readonly List<SceneElement> _elements = new();
    private readonly List<Effect> _effects = new();
    
    public string Name { get; private set; }
    public Duration Duration { get; private set; }
    public string? Narration { get; private set; }
    public IReadOnlyList<SceneElement> Elements => _elements.AsReadOnly();
    public IReadOnlyList<Effect> Effects => _effects.AsReadOnly();
    
    private Scene() { } // EF
    
    private Scene(
        SceneId id,
        string name,
        Duration duration,
        List<SceneElement> elements) : base(id)
    {
        Name = Guard.Against.NullOrEmpty(name, nameof(name));
        Duration = Guard.Against.Null(duration, nameof(duration));
        _elements.AddRange(elements);
    }
    
    public static Result<Scene> Create(
        string name,
        Duration duration,
        List<SceneElement> elements)
    {
        var scene = new Scene(
            SceneId.Create(),
            name,
            duration,
            elements);
        
        return Result.Success(scene);
    }
    
    public Result AddEffect(Effect effect)
    {
        _effects.Add(Guard.Against.Null(effect, nameof(effect)));
        return Result.Success();
    }
    
    public Result SetNarration(string narration)
    {
        Narration = narration;
        return Result.Success();
    }
    
    public Result<SceneElement> HighlightElement(string elementId)
    {
        var element = _elements.FirstOrDefault(e => e.ElementId == elementId);
        
        if (element == null)
        {
            return Result.Failure<SceneElement>(
                new Error("Scene.ElementNotFound", 
                    $"Element '{elementId}' not found in scene"));
        }
        
        element.SetHighlighted(true);
        
        return Result.Success(element);
    }
}

public class SceneId : EntityId
{
    private SceneId(Guid value) : base(value) { }
    
    public static SceneId Create() => new(Guid.NewGuid());
    public static SceneId From(Guid value) => new(value);
}

public class SceneElement : ValueObject
{
    public string ElementId { get; init; } = ""; // NodeId or EdgeId from graph
    public ElementType Type { get; init; } = ElementType.Node;
    public bool IsHighlighted { get; private set; }
    public bool IsVisible { get; private set; } = true;
    public double Opacity { get; private set; } = 1.0;
    
    public void SetHighlighted(bool highlighted) => IsHighlighted = highlighted;
    public void SetVisible(bool visible) => IsVisible = visible;
    public void SetOpacity(double opacity) => Opacity = Math.Clamp(opacity, 0, 1);
    
    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return ElementId;
        yield return Type;
    }
}

public enum ElementType
{
    Node,
    Edge,
    Annotation,
    DataPacket
}
```

### Timeline.cs

```csharp
// Domain/Aggregates/Animation/Timeline.cs
public class Timeline : ValueObject
{
    private readonly List<Keyframe> _keyframes = new();
    
    public Duration Duration { get; private set; }
    public IReadOnlyList<Keyframe> Keyframes => _keyframes.AsReadOnly();
    
    public Timeline(Duration duration)
    {
        Duration = duration;
    }
    
    public Keyframe AddKeyframe(Duration time, Scene scene, KeyframeType type = KeyframeType.Normal)
    {
        var keyframe = new Keyframe(
            KeyframeId.Create(),
            time,
            scene,
            type);
        
        _keyframes.Add(keyframe);
        _keyframes.Sort((a, b) => a.Time.CompareTo(b.Time));
        
        return keyframe;
    }
    
    public Result<Scene> GetSceneAtTime(Duration time)
    {
        if (time > Duration)
        {
            return Result.Failure<Scene>(
                new Error("Timeline.InvalidTime", "Time exceeds timeline duration"));
        }
        
        // Find the keyframe at or before this time
        var keyframe = _keyframes
            .Where(k => k.Time <= time)
            .OrderByDescending(k => k.Time)
            .FirstOrDefault();
        
        if (keyframe == null)
        {
            return Result.Failure<Scene>(
                new Error("Timeline.NoKeyframe", "No keyframe found at specified time"));
        }
        
        return Result.Success(keyframe.Scene);
    }
    
    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Duration;
        foreach (var kf in _keyframes)
            yield return kf;
    }
}

public class Keyframe : Entity<KeyframeId>
{
    public Duration Time { get; private set; }
    public Scene Scene { get; private set; }
    public KeyframeType Type { get; private set; }
    public EasingFunction Easing { get; private set; } = EasingFunction.Linear;
    
    public Keyframe(
        KeyframeId id,
        Duration time,
        Scene scene,
        KeyframeType type) : base(id)
    {
        Time = time;
        Scene = scene;
        Type = type;
    }
    
    public void SetEasing(EasingFunction easing)
    {
        Easing = easing;
    }
}

public class KeyframeId : EntityId
{
    private KeyframeId(Guid value) : base(value) { }
    
    public static KeyframeId Create() => new(Guid.NewGuid());
}

public enum KeyframeType
{
    Normal,
    Hold,      // Hold current frame
    Smooth     // Smooth interpolation to next
}
```

---

## 🎭 Animation Effects

### Effect.cs

```csharp
// Domain/Aggregates/Effect/Effect.cs
public abstract class Effect : Entity<EffectId>
{
    public string Name { get; protected set; } = "";
    public Duration StartTime { get; protected set; }
    public Duration Duration { get; protected set; }
    public string TargetElementId { get; protected set; } = "";
    
    protected Effect(
        EffectId id,
        string name,
        Duration startTime,
        Duration duration,
        string targetElementId) : base(id)
    {
        Name = name;
        StartTime = startTime;
        Duration = duration;
        TargetElementId = targetElementId;
    }
    
    public abstract EffectType GetEffectType();
}

public class EffectId : EntityId
{
    private EffectId(Guid value) : base(value) { }
    
    public static EffectId Create() => new(Guid.NewGuid());
}

public enum EffectType
{
    Highlight,
    Fade,
    Pulse,
    Zoom,
    Slide,
    DataFlow,
    Glow
}
```

### HighlightEffect.cs

```csharp
// Domain/Aggregates/Effect/HighlightEffect.cs
public class HighlightEffect : Effect
{
    public Color HighlightColor { get; private set; }
    public double BorderWidth { get; private set; }
    public bool Animated { get; private set; }
    
    private HighlightEffect(
        EffectId id,
        Duration startTime,
        Duration duration,
        string targetElementId,
        Color highlightColor,
        double borderWidth,
        bool animated) 
        : base(id, "Highlight", startTime, duration, targetElementId)
    {
        HighlightColor = highlightColor;
        BorderWidth = borderWidth;
        Animated = animated;
    }
    
    public static HighlightEffect Create(
        Duration startTime,
        Duration duration,
        string targetElementId,
        Color highlightColor,
        double borderWidth = 3.0,
        bool animated = true)
    {
        return new HighlightEffect(
            EffectId.Create(),
            startTime,
            duration,
            targetElementId,
            highlightColor,
            borderWidth,
            animated);
    }
    
    public override EffectType GetEffectType() => EffectType.Highlight;
}
```

### DataFlowEffect.cs

```csharp
// Domain/Aggregates/Effect/DataFlowEffect.cs
public class DataFlowEffect : Effect
{
    public string SourceNodeId { get; private set; }
    public string TargetNodeId { get; private set; }
    public Color FlowColor { get; private set; }
    public double ParticleSpeed { get; private set; }
    public int ParticleCount { get; private set; }
    public object? Data { get; private set; }
    
    private DataFlowEffect(
        EffectId id,
        Duration startTime,
        Duration duration,
        string edgeId,
        string sourceNodeId,
        string targetNodeId,
        Color flowColor,
        double particleSpeed,
        int particleCount) 
        : base(id, "DataFlow", startTime, duration, edgeId)
    {
        SourceNodeId = sourceNodeId;
        TargetNodeId = targetNodeId;
        FlowColor = flowColor;
        ParticleSpeed = particleSpeed;
        ParticleCount = particleCount;
    }
    
    public static DataFlowEffect Create(
        Duration startTime,
        Duration duration,
        string edgeId,
        string sourceNodeId,
        string targetNodeId,
        Color flowColor,
        double particleSpeed = 1.0,
        int particleCount = 5)
    {
        return new DataFlowEffect(
            EffectId.Create(),
            startTime,
            duration,
            edgeId,
            sourceNodeId,
            targetNodeId,
            flowColor,
            particleSpeed,
            particleCount);
    }
    
    public void SetData(object data)
    {
        Data = data;
    }
    
    public override EffectType GetEffectType() => EffectType.DataFlow;
}
```

---

## 📐 Value Objects

### Duration.cs

```csharp
// Domain/ValueObjects/Duration.cs
public class Duration : ValueObject, IComparable<Duration>
{
    public double TotalSeconds { get; init; }
    
    private Duration(double totalSeconds)
    {
        if (totalSeconds < 0)
            throw new ArgumentException("Duration cannot be negative", nameof(totalSeconds));
        
        TotalSeconds = totalSeconds;
    }
    
    public static Duration FromSeconds(double seconds) => new(seconds);
    public static Duration FromMilliseconds(double milliseconds) => new(milliseconds / 1000.0);
    public static Duration FromMinutes(double minutes) => new(minutes * 60.0);
    
    public Duration Add(Duration other) => new(TotalSeconds + other.TotalSeconds);
    public Duration Subtract(Duration other) => new(Math.Max(0, TotalSeconds - other.TotalSeconds));
    
    public int CompareTo(Duration? other)
    {
        if (other == null) return 1;
        return TotalSeconds.CompareTo(other.TotalSeconds);
    }
    
    public static bool operator >(Duration a, Duration b) => a.TotalSeconds > b.TotalSeconds;
    public static bool operator <(Duration a, Duration b) => a.TotalSeconds < b.TotalSeconds;
    public static bool operator <=(Duration a, Duration b) => a.TotalSeconds <= b.TotalSeconds;
    
    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return TotalSeconds;
    }
    
    public override string ToString() => $"{TotalSeconds:F2}s";
}
```

### EasingFunction.cs

```csharp
// Domain/ValueObjects/EasingFunction.cs
public class EasingFunction : Enumeration
{
    public static readonly EasingFunction Linear = new(1, nameof(Linear));
    public static readonly EasingFunction EaseIn = new(2, nameof(EaseIn));
    public static readonly EasingFunction EaseOut = new(3, nameof(EaseOut));
    public static readonly EasingFunction EaseInOut = new(4, nameof(EaseInOut));
    public static readonly EasingFunction EaseInQuad = new(5, nameof(EaseInQuad));
    public static readonly EasingFunction EaseOutQuad = new(6, nameof(EaseOutQuad));
    public static readonly EasingFunction EaseInOutQuad = new(7, nameof(EaseInOutQuad));
    public static readonly EasingFunction EaseInCubic = new(8, nameof(EaseInCubic));
    public static readonly EasingFunction EaseOutCubic = new(9, nameof(EaseOutCubic));
    public static readonly EasingFunction EaseInOutCubic = new(10, nameof(EaseInOutCubic));
    public static readonly EasingFunction Bounce = new(11, nameof(Bounce));
    public static readonly EasingFunction Elastic = new(12, nameof(Elastic));
    
    private EasingFunction(int id, string name) : base(id, name) { }
    
    public double Apply(double t)
    {
        return Name switch
        {
            nameof(Linear) => t,
            nameof(EaseIn) => t * t,
            nameof(EaseOut) => t * (2 - t),
            nameof(EaseInOut) => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
            nameof(EaseInQuad) => t * t,
            nameof(EaseOutQuad) => t * (2 - t),
            nameof(EaseInOutQuad) => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
            nameof(EaseInCubic) => t * t * t,
            nameof(EaseOutCubic) => (--t) * t * t + 1,
            nameof(EaseInOutCubic) => t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1,
            nameof(Bounce) => ApplyBounce(t),
            nameof(Elastic) => ApplyElastic(t),
            _ => t
        };
    }
    
    private static double ApplyBounce(double t)
    {
        if (t < 1 / 2.75)
            return 7.5625 * t * t;
        if (t < 2 / 2.75)
            return 7.5625 * (t -= 1.5 / 2.75) * t + 0.75;
        if (t < 2.5 / 2.75)
            return 7.5625 * (t -= 2.25 / 2.75) * t + 0.9375;
        return 7.5625 * (t -= 2.625 / 2.75) * t + 0.984375;
    }
    
    private static double ApplyElastic(double t)
    {
        return Math.Sin(13 * Math.PI / 2 * t) * Math.Pow(2, 10 * (t - 1));
    }
}
```

---

**Continue to Part 2: Rendering Engine, Timeline UI, and Export?**
