# ETLway Visual Identity Guide

## 🎨 Brand Overview

**Brand Name:** ETLway  
**Tagline:** The way data moves  
**Parent Brand:** BahyWay Platform  
**Industry:** Data Engineering / ETL Software  
**Target Audience:** Data Engineers, Data Teams, Modern Tech Companies  

---

## 📐 Logo System

### Primary Logo
```
┌────────────────────────────┐
│  ╔═══╗                     │
│  ║ E ║  ETLway             │
│  ╚═══╝                     │
│  [Icon] [Wordmark]         │
└────────────────────────────┘
```

### Logo Components

**1. Icon (Symbol Mark)**
- Geometric square with rounded corners (8px radius)
- Gradient fill: Blue (#2563EB) → Purple (#8B5CF6)
- Letter "E" in bold white
- Subtle data flow elements (dots/lines)
- Size: 40x40px minimum

**2. Wordmark**
- "ETL" in bold weight (700)
- "way" in regular weight (400)
- Typography: Inter / SF Pro / System Font
- Color: "ETL" = Light (#F1F5F9), "way" = Gray (#94A3B8)

**3. Tagline**
- "THE WAY DATA MOVES"
- Small caps, letter-spacing: 1px
- Color: Muted Gray (#64748B)
- Optional element

---

## 🎨 Color Palette

### Primary Colors

**ETL Blue (Primary)**
- Hex: `#2563EB`
- RGB: `37, 99, 235`
- HSL: `220, 83%, 53%`
- Usage: Primary actions, links, accents
- Meaning: Trust, technology, reliability

**Flow Purple (Accent)**
- Hex: `#8B5CF6`
- RGB: `139, 92, 246`
- HSL: `258, 90%, 66%`
- Usage: Gradients, highlights, premium features
- Meaning: Innovation, creativity, premium

**Success Green**
- Hex: `#10B981`
- RGB: `16, 185, 129`
- HSL: `160, 84%, 39%`
- Usage: Success states, positive feedback
- Meaning: Movement, flow, success

### Neutral Colors

**Dark Background**
- Hex: `#0F172A`
- RGB: `15, 23, 42`
- Usage: Main background, dark theme

**Dark Surface**
- Hex: `#1E293B`
- RGB: `30, 41, 59`
- Usage: Cards, panels, elevated surfaces

**Gray Text**
- Hex: `#94A3B8`
- RGB: `148, 163, 184`
- Usage: Secondary text, subtitles

**Light Text**
- Hex: `#F1F5F9`
- RGB: `241, 245, 249`
- Usage: Primary text, headings

**White**
- Hex: `#FFFFFF`
- RGB: `255, 255, 255`
- Usage: Pure white for contrast

### Semantic Colors

**Error Red**
- Hex: `#EF4444`
- Usage: Errors, destructive actions

**Warning Orange**
- Hex: `#F59E0B`
- Usage: Warnings, cautions

**Info Blue**
- Hex: `#3B82F6`
- Usage: Information, tips

---

## 📝 Typography

### Font Stack

**Primary Font: Inter**
- Fallback: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif
- Weights: 300 (Light), 400 (Regular), 500 (Medium), 600 (Semibold), 700 (Bold), 900 (Black)
- Usage: All UI elements, marketing, documentation

**Monospace Font: JetBrains Mono**
- Fallback: 'Courier New', Consolas, monospace
- Weights: 400 (Regular), 700 (Bold)
- Usage: Code blocks, technical content

### Type Scale

```
H1: 4rem (64px)     - Weight: 900 - Line: 1.1
H2: 3rem (48px)     - Weight: 800 - Line: 1.2
H3: 2rem (32px)     - Weight: 700 - Line: 1.3
H4: 1.5rem (24px)   - Weight: 600 - Line: 1.4
Body: 1rem (16px)   - Weight: 400 - Line: 1.6
Small: 0.875rem     - Weight: 400 - Line: 1.5
Tiny: 0.75rem       - Weight: 500 - Line: 1.4
```

### Typography Rules

**Headings:**
- Use gradient for hero headings (Blue → Light)
- Bold weights for impact
- Tight line-height for large text

**Body Text:**
- Comfortable line-height: 1.6-1.8
- Gray color for secondary text (#94A3B8)
- White/Light for primary text (#F1F5F9)

**Code:**
- Monospace font required
- Slightly darker background
- Syntax highlighting preferred

---

## 🎯 Logo Variations

### 1. Full Logo (Primary)
```
[Icon] ETLway
       THE WAY DATA MOVES
```
Use: Website header, marketing materials, presentations

### 2. Horizontal Logo
```
[Icon] ETLway
```
Use: Navigation bars, headers, compact spaces

### 3. Icon Only
```
[Icon]
```
Use: Favicons, social media avatars, app icons

### 4. Wordmark Only
```
ETLway
```
Use: Text-heavy contexts, footer

### 5. Monochrome Versions

**White Logo**
- Use on dark backgrounds
- All elements in white (#FFFFFF)

**Dark Logo**
- Use on light backgrounds
- Icon: Dark gradient, Text: Dark gray

**Single Color**
- All blue (#2563EB) for special cases

---

## 📏 Logo Usage Guidelines

### Clear Space
- Minimum clear space: 1/2 icon height on all sides
- Keep area around logo free of text, images, other logos

### Minimum Sizes
- Digital: 32px height (icon), 120px width (full logo)
- Print: 0.5 inches height minimum

### DO's ✅
- Use approved color versions
- Maintain aspect ratio
- Ensure legibility
- Use on appropriate backgrounds

### DON'Ts ❌
- Don't stretch or distort
- Don't change colors
- Don't add effects (drop shadow, outline)
- Don't rotate or tilt
- Don't place on busy backgrounds
- Don't recreate the logo

---

## 🎨 Design Patterns

### Gradients

**Primary Gradient**
```css
background: linear-gradient(135deg, #2563EB, #8B5CF6);
```
Use: CTAs, premium features, hero sections

**Subtle Gradient**
```css
background: linear-gradient(135deg, rgba(37,99,235,0.1), rgba(139,92,246,0.1));
```
Use: Backgrounds, cards, subtle accents

**Text Gradient**
```css
background: linear-gradient(135deg, #FFFFFF, #2563EB);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;
```
Use: Hero headings, special text

### Shadows

**Small Shadow**
```css
box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12);
```

**Medium Shadow**
```css
box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
```

**Large Shadow**
```css
box-shadow: 0 10px 30px rgba(37, 99, 235, 0.2);
```

**Glow Effect**
```css
box-shadow: 0 10px 30px rgba(37, 99, 235, 0.4);
```

### Border Radius

```
Small:  4px  - Buttons, tags
Medium: 8px  - Cards, inputs
Large:  12px - Panels, modals
XLarge: 16px - Hero sections
```

---

## 🖼️ Iconography

### Style Guidelines

**Icon Style:**
- Line-based, geometric
- 2px stroke weight
- Rounded line caps
- 24x24px base size
- Outline style preferred

**Icon Colors:**
- Primary: Use brand blue (#2563EB)
- Secondary: Use gray (#94A3B8)
- On dark: Use light (#F1F5F9)

**Common Icons:**
```
⚡ Performance/Speed
🎨 Design/Visual
🔗 Connection/Integration
🌐 Cross-platform/Global
📊 Data/Analytics
🤖 AI/Automation
🔒 Security
🚀 Launch/Deploy
```

---

## 🎬 Motion & Animation

### Animation Principles

**Duration:**
- Micro-interactions: 150-200ms
- Standard transitions: 300ms
- Complex animations: 400-600ms

**Easing:**
```css
/* Smooth ease-out (preferred) */
transition-timing-function: cubic-bezier(0.16, 1, 0.3, 1);

/* Standard ease */
transition-timing-function: ease-in-out;
```

**Common Animations:**

**Hover States:**
```css
transform: translateY(-2px);
box-shadow: 0 10px 30px rgba(37, 99, 235, 0.4);
```

**Button Press:**
```css
transform: scale(0.98);
```

**Fade In:**
```css
opacity: 0 → 1;
transform: translateY(10px) → translateY(0);
```

---

## 📱 Responsive Design

### Breakpoints

```css
/* Mobile */
@media (max-width: 640px) { }

/* Tablet */
@media (max-width: 1024px) { }

/* Desktop */
@media (min-width: 1025px) { }

/* Large Desktop */
@media (min-width: 1440px) { }
```

### Font Scaling

```
Mobile:  Base 14px, H1: 2rem
Tablet:  Base 15px, H1: 3rem
Desktop: Base 16px, H1: 4rem
```

---

## 🌐 Web Components

### Buttons

**Primary Button:**
```css
background: linear-gradient(135deg, #2563EB, #8B5CF6);
color: white;
padding: 0.75rem 1.5rem;
border-radius: 8px;
font-weight: 600;
```

**Secondary Button:**
```css
background: transparent;
border: 2px solid #2563EB;
color: #2563EB;
```

**States:**
- Hover: Lift up (-2px), add glow
- Active: Scale down (0.98)
- Disabled: Opacity 0.5, no hover

### Cards

```css
background: #1E293B;
padding: 2rem;
border-radius: 12px;
border: 1px solid rgba(37, 99, 235, 0.2);

/* Hover */
transform: translateY(-5px);
border-color: #2563EB;
box-shadow: 0 10px 30px rgba(37, 99, 235, 0.2);
```

### Inputs

```css
background: #0F172A;
border: 2px solid #334155;
border-radius: 8px;
padding: 0.75rem 1rem;
color: #F1F5F9;

/* Focus */
border-color: #2563EB;
outline: none;
box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
```

---

## 📸 Photography & Imagery

### Style Guidelines

**Preferred:**
- Dark, moody backgrounds
- Technology-focused imagery
- Abstract data visualizations
- Modern, clean compositions

**Avoid:**
- Stock photos (generic office)
- Overly bright images
- Cluttered compositions
- Outdated technology

**Overlays:**
```css
/* Dark overlay for text readability */
background: linear-gradient(rgba(15, 23, 42, 0.8), rgba(15, 23, 42, 0.9));
```

---

## 📊 Data Visualization

### Colors for Charts

**Categorical:**
1. Blue: #2563EB
2. Purple: #8B5CF6
3. Green: #10B981
4. Orange: #F59E0B
5. Pink: #EC4899
6. Cyan: #06B6D4

**Sequential:**
```
Light → Dark
#DBEAFE → #2563EB → #1E40AF
```

**Diverging:**
```
Negative ← Zero → Positive
#EF4444 ← #94A3B8 → #10B981
```

---

## 🎁 Marketing Assets

### Social Media Sizes

**Twitter/X:**
- Profile: 400x400px
- Header: 1500x500px
- Post: 1200x675px

**LinkedIn:**
- Profile: 400x400px
- Cover: 1584x396px
- Post: 1200x627px

**GitHub:**
- Profile: 460x460px
- Repo Social: 1280x640px

### Email Templates

**Width:** 600px max  
**Background:** Dark (#0F172A)  
**CTA Button:** Primary gradient  
**Font:** System fonts for compatibility  

---

## ✅ Brand Checklist

### Before Launch:
- [ ] Logo finalized in all variations
- [ ] Color palette applied consistently
- [ ] Typography hierarchy established
- [ ] Icon set created
- [ ] Website designed
- [ ] Marketing materials prepared
- [ ] Social media assets ready
- [ ] Documentation styled
- [ ] Email templates created
- [ ] Brand guidelines document shared

### Monthly Review:
- [ ] Consistency across all channels
- [ ] Color usage appropriate
- [ ] Logo not distorted anywhere
- [ ] Typography readable
- [ ] Responsive design working
- [ ] Accessibility maintained

---

## 📞 Brand Contacts

**Brand Owner:** BahyWay Design Team  
**Questions:** brand@bahyway.com  
**Asset Requests:** assets@etlway.com  

---

**Version:** 1.0  
**Last Updated:** November 2025  
**Review Frequency:** Quarterly  

© 2025 ETLway by BahyWay. All brand assets proprietary.
