# KGEditorWay - Avalonia UI Implementation (Complete)

## 📦 Part 1: Project Setup & Dependencies

### Project File

```xml
<!-- BahyWay.KGEditorWay.Desktop.csproj -->
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <OutputType>WinExe</OutputType>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <BuiltInComInteropSupport>true</BuiltInComInteropSupport>
    <ApplicationManifest>app.manifest</ApplicationManifest>
    <AvaloniaUseCompiledBindingsByDefault>true</AvaloniaUseCompiledBindingsByDefault>
  </PropertyGroup>

  <ItemGroup>
    <!-- Avalonia Core -->
    <PackageReference Include="Avalonia" Version="11.0.7" />
    <PackageReference Include="Avalonia.Desktop" Version="11.0.7" />
    <PackageReference Include="Avalonia.Themes.Fluent" Version="11.0.7" />
    <PackageReference Include="Avalonia.Fonts.Inter" Version="11.0.7" />
    
    <!-- Avalonia Diagnostics (Dev only) -->
    <PackageReference Condition="'$(Configuration)' == 'Debug'" Include="Avalonia.Diagnostics" Version="11.0.7" />
    
    <!-- MVVM -->
    <PackageReference Include="ReactiveUI" Version="19.5.31" />
    <PackageReference Include="ReactiveUI.Fody" Version="19.5.31" />
    
    <!-- Icons -->
    <PackageReference Include="Avalonia.Svg.Skia" Version="11.0.0.18" />
    
    <!-- Dependency Injection -->
    <PackageReference Include="Microsoft.Extensions.DependencyInjection" Version="8.0.0" />
    <PackageReference Include="Microsoft.Extensions.Hosting" Version="8.0.0" />
  </ItemGroup>

  <ItemGroup>
    <!-- Reference Domain & Application layers -->
    <ProjectReference Include="..\BahyWay.KGEditorWay.Domain\BahyWay.KGEditorWay.Domain.csproj" />
    <ProjectReference Include="..\BahyWay.KGEditorWay.Application\BahyWay.KGEditorWay.Application.csproj" />
  </ItemGroup>
</Project>
```

---

## 🎨 Part 2: Main Application Entry

### Program.cs

```csharp
// Program.cs
using System;
using Avalonia;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace BahyWay.KGEditorWay.Desktop;

internal class Program
{
    [STAThread]
    public static void Main(string[] args)
    {
        try
        {
            BuildAvaloniaApp()
                .StartWithClassicDesktopLifetime(args);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Fatal error: {ex}");
            throw;
        }
    }

    public static AppBuilder BuildAvaloniaApp()
        => AppBuilder.Configure<App>()
            .UsePlatformDetect()
            .WithInterFont()
            .LogToTrace();
}
```

### App.axaml

```xml
<!-- App.axaml -->
<Application xmlns="https://github.com/avaloniaui"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
             x:Class="BahyWay.KGEditorWay.Desktop.App"
             RequestedThemeVariant="Dark">
    
    <Application.Styles>
        <FluentTheme />
        
        <!-- Custom Styles -->
        <StyleInclude Source="/Styles/GraphCanvasStyles.axaml"/>
        <StyleInclude Source="/Styles/NodeStyles.axaml"/>
        <StyleInclude Source="/Styles/ToolbarStyles.axaml"/>
    </Application.Styles>
    
    <Application.Resources>
        <!-- Colors -->
        <SolidColorBrush x:Key="CanvasBackgroundBrush">#252525</SolidColorBrush>
        <SolidColorBrush x:Key="GridLineBrush">#2A2A2A</SolidColorBrush>
        <SolidColorBrush x:Key="NodeBackgroundBrush">#1E1E1E</SolidColorBrush>
        <SolidColorBrush x:Key="NodeBorderBrush">#2196F3</SolidColorBrush>
        <SolidColorBrush x:Key="ConnectionBrush">#666666</SolidColorBrush>
        <SolidColorBrush x:Key="PortBrush">#4CAF50</SolidColorBrush>
        
        <!-- Converters -->
        <local:NodeTypeToColorConverter x:Key="NodeTypeToColorConverter"/>
        <local:BoolToVisibilityConverter x:Key="BoolToVisibilityConverter"/>
    </Application.Resources>
</Application>
```

### App.axaml.cs

```csharp
// App.axaml.cs
using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using Microsoft.Extensions.DependencyInjection;
using BahyWay.KGEditorWay.Desktop.ViewModels;
using BahyWay.KGEditorWay.Desktop.Views;
using BahyWay.KGEditorWay.Desktop.Services;

namespace BahyWay.KGEditorWay.Desktop;

public partial class App : Application
{
    public IServiceProvider? Services { get; private set; }

    public override void Initialize()
    {
        AvaloniaXamlLoader.Load(this);
        
        // Setup DI
        var services = new ServiceCollection();
        ConfigureServices(services);
        Services = services.BuildServiceProvider();
    }

    public override void OnFrameworkInitializationCompleted()
    {
        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            var mainViewModel = Services!.GetRequiredService<MainViewModel>();
            desktop.MainWindow = new MainWindow
            {
                DataContext = mainViewModel
            };
        }

        base.OnFrameworkInitializationCompleted();
    }

    private void ConfigureServices(IServiceCollection services)
    {
        // ViewModels
        services.AddSingleton<MainViewModel>();
        services.AddTransient<GraphCanvasViewModel>();
        services.AddTransient<ToolboxViewModel>();
        services.AddTransient<PropertiesPanelViewModel>();
        
        // Services
        services.AddSingleton<IGraphService, GraphService>();
        services.AddSingleton<IClipboardService, ClipboardService>();
        services.AddSingleton<IDialogService, DialogService>();
        services.AddSingleton<IFileService, FileService>();
        
        // TODO: Add Application and Infrastructure layer services
    }
}
```

---

## 🎯 Part 3: Core Models & ViewModels

### NodeViewModel.cs

```csharp
// ViewModels/NodeViewModel.cs
using System;
using System.Collections.ObjectModel;
using System.Reactive;
using System.Reactive.Linq;
using ReactiveUI;
using BahyWay.KGEditorWay.Domain.Aggregates.Node;

namespace BahyWay.KGEditorWay.Desktop.ViewModels;

public class NodeViewModel : ViewModelBase
{
    private double _x;
    private double _y;
    private double _width = 200;
    private double _height = 100;
    private bool _isSelected;
    private bool _isDragging;
    private string _name = string.Empty;
    
    public Guid NodeId { get; }
    public NodeType NodeType { get; }
    
    public string Name
    {
        get => _name;
        set => this.RaiseAndSetIfChanged(ref _name, value);
    }
    
    public double X
    {
        get => _x;
        set => this.RaiseAndSetIfChanged(ref _x, value);
    }
    
    public double Y
    {
        get => _y;
        set => this.RaiseAndSetIfChanged(ref _y, value);
    }
    
    public double Width
    {
        get => _width;
        set => this.RaiseAndSetIfChanged(ref _width, value);
    }
    
    public double Height
    {
        get => _height;
        set => this.RaiseAndSetIfChanged(ref _height, value);
    }
    
    public bool IsSelected
    {
        get => _isSelected;
        set => this.RaiseAndSetIfChanged(ref _isSelected, value);
    }
    
    public bool IsDragging
    {
        get => _isDragging;
        set => this.RaiseAndSetIfChanged(ref _isDragging, value);
    }
    
    public string TypeIcon => NodeType.Icon;
    public string TypeColor => NodeType.Color;
    
    public ObservableCollection<PortViewModel> InputPorts { get; } = new();
    public ObservableCollection<PortViewModel> OutputPorts { get; } = new();
    
    // Commands
    public ReactiveCommand<Unit, Unit> DeleteCommand { get; }
    public ReactiveCommand<Unit, Unit> DuplicateCommand { get; }
    public ReactiveCommand<Unit, Unit> EditPropertiesCommand { get; }
    
    // Events
    public event EventHandler<NodeMovedEventArgs>? NodeMoved;
    public event EventHandler? NodeDeleted;
    public event EventHandler? PropertiesRequested;
    
    public NodeViewModel(Guid nodeId, string name, NodeType nodeType, double x, double y)
    {
        NodeId = nodeId;
        Name = name;
        NodeType = nodeType;
        X = x;
        Y = y;
        
        DeleteCommand = ReactiveCommand.Create(OnDelete);
        DuplicateCommand = ReactiveCommand.Create(OnDuplicate);
        EditPropertiesCommand = ReactiveCommand.Create(OnEditProperties);
        
        // Initialize ports based on node type
        InitializePorts(nodeType);
    }
    
    private void InitializePorts(NodeType nodeType)
    {
        switch (nodeType.Name)
        {
            case "Source":
                OutputPorts.Add(new PortViewModel("Output", PortDirection.Output, this));
                break;
            
            case "Transform":
                InputPorts.Add(new PortViewModel("Input", PortDirection.Input, this));
                OutputPorts.Add(new PortViewModel("Output", PortDirection.Output, this));
                break;
            
            case "Filter":
                InputPorts.Add(new PortViewModel("Input", PortDirection.Input, this));
                OutputPorts.Add(new PortViewModel("Passed", PortDirection.Output, this));
                OutputPorts.Add(new PortViewModel("Filtered", PortDirection.Output, this));
                break;
            
            case "Join":
                InputPorts.Add(new PortViewModel("Left", PortDirection.Input, this));
                InputPorts.Add(new PortViewModel("Right", PortDirection.Input, this));
                OutputPorts.Add(new PortViewModel("Output", PortDirection.Output, this));
                break;
            
            case "Sink":
                InputPorts.Add(new PortViewModel("Input", PortDirection.Input, this));
                break;
        }
    }
    
    public void UpdatePosition(double newX, double newY)
    {
        var oldX = X;
        var oldY = Y;
        
        X = newX;
        Y = newY;
        
        NodeMoved?.Invoke(this, new NodeMovedEventArgs(oldX, oldY, newX, newY));
    }
    
    public void Move(double deltaX, double deltaY)
    {
        UpdatePosition(X + deltaX, Y + deltaY);
    }
    
    public PortViewModel? GetPort(string portName, PortDirection direction)
    {
        var ports = direction == PortDirection.Input ? InputPorts : OutputPorts;
        return ports.FirstOrDefault(p => p.Name == portName);
    }
    
    private void OnDelete()
    {
        NodeDeleted?.Invoke(this, EventArgs.Empty);
    }
    
    private void OnDuplicate()
    {
        // Will be handled by parent ViewModel
    }
    
    private void OnEditProperties()
    {
        PropertiesRequested?.Invoke(this, EventArgs.Empty);
    }
}

public class NodeMovedEventArgs : EventArgs
{
    public double OldX { get; }
    public double OldY { get; }
    public double NewX { get; }
    public double NewY { get; }
    
    public NodeMovedEventArgs(double oldX, double oldY, double newX, double newY)
    {
        OldX = oldX;
        OldY = oldY;
        NewX = newX;
        NewY = newY;
    }
}
```

### PortViewModel.cs

```csharp
// ViewModels/PortViewModel.cs
using System;
using ReactiveUI;
using Avalonia;

namespace BahyWay.KGEditorWay.Desktop.ViewModels;

public enum PortDirection
{
    Input,
    Output
}

public class PortViewModel : ViewModelBase
{
    private bool _isConnecting;
    private bool _isHighlighted;
    
    public string Name { get; }
    public PortDirection Direction { get; }
    public NodeViewModel OwnerNode { get; }
    
    public bool IsConnecting
    {
        get => _isConnecting;
        set => this.RaiseAndSetIfChanged(ref _isConnecting, value);
    }
    
    public bool IsHighlighted
    {
        get => _isHighlighted;
        set => this.RaiseAndSetIfChanged(ref _isHighlighted, value);
    }
    
    // Port position in canvas coordinates
    public Point CanvasPosition
    {
        get
        {
            var nodeX = OwnerNode.X;
            var nodeY = OwnerNode.Y;
            var nodeWidth = OwnerNode.Width;
            var nodeHeight = OwnerNode.Height;
            
            // Calculate port position based on direction and index
            if (Direction == PortDirection.Input)
            {
                var index = OwnerNode.InputPorts.IndexOf(this);
                var spacing = nodeHeight / (OwnerNode.InputPorts.Count + 1);
                return new Point(nodeX, nodeY + spacing * (index + 1));
            }
            else
            {
                var index = OwnerNode.OutputPorts.IndexOf(this);
                var spacing = nodeHeight / (OwnerNode.OutputPorts.Count + 1);
                return new Point(nodeX + nodeWidth, nodeY + spacing * (index + 1));
            }
        }
    }
    
    public event EventHandler<PortClickedEventArgs>? PortClicked;
    
    public PortViewModel(string name, PortDirection direction, NodeViewModel ownerNode)
    {
        Name = name;
        Direction = direction;
        OwnerNode = ownerNode;
        
        // Update position when node moves
        ownerNode.PropertyChanged += (s, e) =>
        {
            if (e.PropertyName == nameof(NodeViewModel.X) || 
                e.PropertyName == nameof(NodeViewModel.Y))
            {
                this.RaisePropertyChanged(nameof(CanvasPosition));
            }
        };
    }
    
    public void OnClicked()
    {
        PortClicked?.Invoke(this, new PortClickedEventArgs(this));
    }
}

public class PortClickedEventArgs : EventArgs
{
    public PortViewModel Port { get; }
    
    public PortClickedEventArgs(PortViewModel port)
    {
        Port = port;
    }
}
```

### ConnectionViewModel.cs

```csharp
// ViewModels/ConnectionViewModel.cs
using System;
using ReactiveUI;
using Avalonia;
using Avalonia.Media;

namespace BahyWay.KGEditorWay.Desktop.ViewModels;

public class ConnectionViewModel : ViewModelBase
{
    private bool _isSelected;
    private Geometry? _pathGeometry;
    
    public Guid ConnectionId { get; }
    public PortViewModel SourcePort { get; }
    public PortViewModel TargetPort { get; }
    
    public bool IsSelected
    {
        get => _isSelected;
        set => this.RaiseAndSetIfChanged(ref _isSelected, value);
    }
    
    public Geometry? PathGeometry
    {
        get => _pathGeometry;
        private set => this.RaiseAndSetIfChanged(ref _pathGeometry, value);
    }
    
    public IBrush StrokeBrush => IsSelected 
        ? new SolidColorBrush(Color.Parse("#2196F3")) 
        : new SolidColorBrush(Color.Parse("#666666"));
    
    public double StrokeThickness => IsSelected ? 3 : 2;
    
    public ConnectionViewModel(Guid connectionId, PortViewModel sourcePort, PortViewModel targetPort)
    {
        ConnectionId = connectionId;
        SourcePort = sourcePort;
        TargetPort = targetPort;
        
        // Update path when ports move
        SourcePort.PropertyChanged += (s, e) =>
        {
            if (e.PropertyName == nameof(PortViewModel.CanvasPosition))
                UpdatePath();
        };
        
        TargetPort.PropertyChanged += (s, e) =>
        {
            if (e.PropertyName == nameof(PortViewModel.CanvasPosition))
                UpdatePath();
        };
        
        // Subscribe to selection changes
        this.WhenAnyValue(x => x.IsSelected)
            .Subscribe(_ =>
            {
                this.RaisePropertyChanged(nameof(StrokeBrush));
                this.RaisePropertyChanged(nameof(StrokeThickness));
            });
        
        UpdatePath();
    }
    
    public void UpdatePath()
    {
        PathGeometry = CreateBezierPath(SourcePort.CanvasPosition, TargetPort.CanvasPosition);
    }
    
    private Geometry CreateBezierPath(Point start, Point end)
    {
        var pathFigure = new PathFigure { StartPoint = start };
        
        // Calculate control points for smooth Bezier curve
        var dx = Math.Abs(end.X - start.X);
        var handleDistance = Math.Min(dx * 0.5, 200);
        
        var control1 = new Point(start.X + handleDistance, start.Y);
        var control2 = new Point(end.X - handleDistance, end.Y);
        
        pathFigure.Segments = new PathSegments
        {
            new BezierSegment
            {
                Point1 = control1,
                Point2 = control2,
                Point3 = end
            }
        };
        
        return new PathGeometry { Figures = new PathFigures { pathFigure } };
    }
}
```

---

## 🎨 Part 4: Main Canvas ViewModel

### GraphCanvasViewModel.cs

```csharp
// ViewModels/GraphCanvasViewModel.cs
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive;
using System.Reactive.Linq;
using ReactiveUI;
using Avalonia;
using Avalonia.Media;

namespace BahyWay.KGEditorWay.Desktop.ViewModels;

public class GraphCanvasViewModel : ViewModelBase
{
    private double _zoom = 1.0;
    private double _panX = 0;
    private double _panY = 0;
    private bool _isPanning;
    private Point _lastPanPoint;
    private PortViewModel? _connectionStartPort;
    private Point _connectionEndPoint;
    private bool _isDrawingConnection;
    
    public ObservableCollection<NodeViewModel> Nodes { get; } = new();
    public ObservableCollection<ConnectionViewModel> Connections { get; } = new();
    
    public double Zoom
    {
        get => _zoom;
        set
        {
            value = Math.Clamp(value, 0.1, 3.0);
            this.RaiseAndSetIfChanged(ref _zoom, value);
            UpdateTransform();
        }
    }
    
    public double PanX
    {
        get => _panX;
        set
        {
            this.RaiseAndSetIfChanged(ref _panX, value);
            UpdateTransform();
        }
    }
    
    public double PanY
    {
        get => _panY;
        set
        {
            this.RaiseAndSetIfChanged(ref _panY, value);
            UpdateTransform();
        }
    }
    
    public bool IsPanning
    {
        get => _isPanning;
        set => this.RaiseAndSetIfChanged(ref _isPanning, value);
    }
    
    public bool IsDrawingConnection
    {
        get => _isDrawingConnection;
        set => this.RaiseAndSetIfChanged(ref _isDrawingConnection, value);
    }
    
    public Point ConnectionEndPoint
    {
        get => _connectionEndPoint;
        set => this.RaiseAndSetIfChanged(ref _connectionEndPoint, value);
    }
    
    private Matrix _canvasTransform = Matrix.Identity;
    public Matrix CanvasTransform
    {
        get => _canvasTransform;
        private set => this.RaiseAndSetIfChanged(ref _canvasTransform, value);
    }
    
    // Commands
    public ReactiveCommand<NodeType, Unit> AddNodeCommand { get; }
    public ReactiveCommand<Unit, Unit> DeleteSelectedCommand { get; }
    public ReactiveCommand<Unit, Unit> ZoomInCommand { get; }
    public ReactiveCommand<Unit, Unit> ZoomOutCommand { get; }
    public ReactiveCommand<Unit, Unit> FitToViewCommand { get; }
    public ReactiveCommand<Unit, Unit> ResetZoomCommand { get; }
    public ReactiveCommand<Unit, Unit> SelectAllCommand { get; }
    public ReactiveCommand<Unit, Unit> DeselectAllCommand { get; }
    
    public GraphCanvasViewModel()
    {
        AddNodeCommand = ReactiveCommand.Create<NodeType>(AddNode);
        DeleteSelectedCommand = ReactiveCommand.Create(DeleteSelected);
        ZoomInCommand = ReactiveCommand.Create(ZoomIn);
        ZoomOutCommand = ReactiveCommand.Create(ZoomOut);
        FitToViewCommand = ReactiveCommand.Create(FitToView);
        ResetZoomCommand = ReactiveCommand.Create(ResetZoom);
        SelectAllCommand = ReactiveCommand.Create(SelectAll);
        DeselectAllCommand = ReactiveCommand.Create(DeselectAll);
        
        // Add some sample nodes for testing
        InitializeSampleGraph();
    }
    
    private void InitializeSampleGraph()
    {
        var sourceNode = new NodeViewModel(
            Guid.NewGuid(),
            "CSV Source",
            NodeType.Source,
            100,
            100);
        
        var transformNode = new NodeViewModel(
            Guid.NewGuid(),
            "Transform Data",
            NodeType.Transform,
            400,
            100);
        
        var sinkNode = new NodeViewModel(
            Guid.NewGuid(),
            "PostgreSQL Sink",
            NodeType.Sink,
            700,
            100);
        
        Nodes.Add(sourceNode);
        Nodes.Add(transformNode);
        Nodes.Add(sinkNode);
        
        // Subscribe to node events
        foreach (var node in Nodes)
        {
            SubscribeToNodeEvents(node);
        }
        
        // Create connections
        var conn1 = new ConnectionViewModel(
            Guid.NewGuid(),
            sourceNode.OutputPorts[0],
            transformNode.InputPorts[0]);
        
        var conn2 = new ConnectionViewModel(
            Guid.NewGuid(),
            transformNode.OutputPorts[0],
            sinkNode.InputPorts[0]);
        
        Connections.Add(conn1);
        Connections.Add(conn2);
    }
    
    private void AddNode(NodeType nodeType)
    {
        // Add node at center of viewport
        var centerX = -PanX / Zoom + 400;
        var centerY = -PanY / Zoom + 300;
        
        var node = new NodeViewModel(
            Guid.NewGuid(),
            $"New {nodeType.Name}",
            nodeType,
            centerX,
            centerY);
        
        Nodes.Add(node);
        SubscribeToNodeEvents(node);
    }
    
    private void SubscribeToNodeEvents(NodeViewModel node)
    {
        node.NodeMoved += OnNodeMoved;
        node.NodeDeleted += OnNodeDeleted;
        node.PropertiesRequested += OnNodePropertiesRequested;
        
        // Subscribe to port clicks
        foreach (var port in node.InputPorts.Concat(node.OutputPorts))
        {
            port.PortClicked += OnPortClicked;
        }
    }
    
    private void OnNodeMoved(object? sender, NodeMovedEventArgs e)
    {
        // Connections will update automatically via bindings
    }
    
    private void OnNodeDeleted(object? sender, EventArgs e)
    {
        if (sender is NodeViewModel node)
        {
            // Remove all connections to/from this node
            var connectionsToRemove = Connections
                .Where(c => c.SourcePort.OwnerNode == node || c.TargetPort.OwnerNode == node)
                .ToList();
            
            foreach (var conn in connectionsToRemove)
            {
                Connections.Remove(conn);
            }
            
            Nodes.Remove(node);
        }
    }
    
    private void OnNodePropertiesRequested(object? sender, EventArgs e)
    {
        // TODO: Show properties panel
    }
    
    private void OnPortClicked(object? sender, PortClickedEventArgs e)
    {
        if (!IsDrawingConnection)
        {
            // Start drawing connection
            if (e.Port.Direction == PortDirection.Output)
            {
                _connectionStartPort = e.Port;
                IsDrawingConnection = true;
                ConnectionEndPoint = e.Port.CanvasPosition;
            }
        }
        else
        {
            // Complete connection
            if (e.Port.Direction == PortDirection.Input && _connectionStartPort != null)
            {
                CreateConnection(_connectionStartPort, e.Port);
            }
            
            IsDrawingConnection = false;
            _connectionStartPort = null;
        }
    }
    
    private void CreateConnection(PortViewModel sourcePort, PortViewModel targetPort)
    {
        // Check if connection already exists
        var existingConnection = Connections.FirstOrDefault(c =>
            c.TargetPort == targetPort);
        
        if (existingConnection != null)
        {
            // Remove old connection (input ports can only have one connection)
            Connections.Remove(existingConnection);
        }
        
        var connection = new ConnectionViewModel(
            Guid.NewGuid(),
            sourcePort,
            targetPort);
        
        Connections.Add(connection);
    }
    
    public void UpdateConnectionDrawing(Point mousePosition)
    {
        if (IsDrawingConnection)
        {
            ConnectionEndPoint = mousePosition;
        }
    }
    
    public void HandleNodeDrag(NodeViewModel node, double deltaX, double deltaY)
    {
        node.Move(deltaX / Zoom, deltaY / Zoom);
    }
    
    public void StartPan(Point position)
    {
        IsPanning = true;
        _lastPanPoint = position;
    }
    
    public void UpdatePan(Point position)
    {
        if (IsPanning)
        {
            var deltaX = position.X - _lastPanPoint.X;
            var deltaY = position.Y - _lastPanPoint.Y;
            
            PanX += deltaX;
            PanY += deltaY;
            
            _lastPanPoint = position;
        }
    }
    
    public void EndPan()
    {
        IsPanning = false;
    }
    
    private void UpdateTransform()
    {
        CanvasTransform = Matrix.CreateTranslation(PanX, PanY) * 
                         Matrix.CreateScale(Zoom, Zoom);
    }
    
    private void DeleteSelected()
    {
        var selectedNodes = Nodes.Where(n => n.IsSelected).ToList();
        foreach (var node in selectedNodes)
        {
            Nodes.Remove(node);
        }
        
        var selectedConnections = Connections.Where(c => c.IsSelected).ToList();
        foreach (var conn in selectedConnections)
        {
            Connections.Remove(conn);
        }
    }
    
    private void ZoomIn()
    {
        Zoom *= 1.2;
    }
    
    private void ZoomOut()
    {
        Zoom /= 1.2;
    }
    
    private void FitToView()
    {
        if (!Nodes.Any()) return;
        
        var minX = Nodes.Min(n => n.X);
        var minY = Nodes.Min(n => n.Y);
        var maxX = Nodes.Max(n => n.X + n.Width);
        var maxY = Nodes.Max(n => n.Y + n.Height);
        
        var contentWidth = maxX - minX;
        var contentHeight = maxY - minY;
        
        // Assuming canvas size of 800x600 (adjust as needed)
        var canvasWidth = 800;
        var canvasHeight = 600;
        
        var scaleX = canvasWidth / contentWidth;
        var scaleY = canvasHeight / contentHeight;
        
        Zoom = Math.Min(scaleX, scaleY) * 0.9; // 90% to add padding
        
        PanX = -minX * Zoom + (canvasWidth - contentWidth * Zoom) / 2;
        PanY = -minY * Zoom + (canvasHeight - contentHeight * Zoom) / 2;
    }
    
    private void ResetZoom()
    {
        Zoom = 1.0;
        PanX = 0;
        PanY = 0;
    }
    
    private void SelectAll()
    {
        foreach (var node in Nodes)
        {
            node.IsSelected = true;
        }
    }
    
    private void DeselectAll()
    {
        foreach (var node in Nodes)
        {
            node.IsSelected = false;
        }
        
        foreach (var conn in Connections)
        {
            conn.IsSelected = false;
        }
    }
}
```

---

**Next Part: XAML Views (MainWindow, GraphCanvas, Node views)** - Continue? 🚀
