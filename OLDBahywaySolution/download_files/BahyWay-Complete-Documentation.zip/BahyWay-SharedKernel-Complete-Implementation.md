# BahyWay SharedKernel - Complete Implementation

This is the **heart** of your architecture. Every project depends on this. Get this right, and everything else follows.

---

## 📦 Project Structure

```
BahyWay.SharedKernel/
├── Domain/
│   ├── Entity.cs
│   ├── ValueObject.cs
│   ├── AggregateRoot.cs
│   ├── Enumeration.cs
│   ├── IDomainEvent.cs
│   ├── DomainEvent.cs
│   └── IRepository.cs
├── Exceptions/
│   ├── DomainException.cs
│   ├── BusinessRuleException.cs
│   ├── NotFoundException.cs
│   └── ValidationException.cs
├── Guards/
│   └── Guard.cs
├── Results/
│   ├── Result.cs
│   ├── Result{T}.cs
│   └── Error.cs
└── Interfaces/
    ├── IUnitOfWork.cs
    ├── IDomainEventDispatcher.cs
    └── IAuditable.cs
```

---

## 🔨 Complete Implementation

### 1. Entity Base Class

```csharp
// Domain/Entity.cs
using System;
using System.Collections.Generic;

namespace BahyWay.SharedKernel.Domain;

/// <summary>
/// Base class for all entities in the domain.
/// Entities have a unique identity that remains constant throughout their lifetime.
/// </summary>
/// <typeparam name="TId">The type of the entity's identifier</typeparam>
public abstract class Entity<TId> : IEquatable<Entity<TId>>
    where TId : notnull
{
    private readonly List<IDomainEvent> _domainEvents = new();

    /// <summary>
    /// Gets the unique identifier of the entity.
    /// </summary>
    public TId Id { get; protected set; } = default!;

    /// <summary>
    /// Gets the collection of domain events raised by this entity.
    /// </summary>
    public IReadOnlyCollection<IDomainEvent> DomainEvents => 
        _domainEvents.AsReadOnly();

    /// <summary>
    /// Initializes a new instance with the specified ID.
    /// </summary>
    protected Entity(TId id)
    {
        Id = id;
    }

    /// <summary>
    /// Parameterless constructor for EF Core.
    /// </summary>
    protected Entity() { }

    /// <summary>
    /// Adds a domain event to be dispatched when changes are saved.
    /// </summary>
    protected void AddDomainEvent(IDomainEvent domainEvent)
    {
        _domainEvents.Add(domainEvent);
    }

    /// <summary>
    /// Removes a specific domain event.
    /// </summary>
    protected void RemoveDomainEvent(IDomainEvent domainEvent)
    {
        _domainEvents.Remove(domainEvent);
    }

    /// <summary>
    /// Clears all domain events.
    /// </summary>
    public void ClearDomainEvents()
    {
        _domainEvents.Clear();
    }

    // Equality based on Id
    public bool Equals(Entity<TId>? other)
    {
        if (other is null) return false;
        if (ReferenceEquals(this, other)) return true;
        if (GetType() != other.GetType()) return false;
        
        return EqualityComparer<TId>.Default.Equals(Id, other.Id);
    }

    public override bool Equals(object? obj)
    {
        return obj is Entity<TId> entity && Equals(entity);
    }

    public override int GetHashCode()
    {
        return HashCode.Combine(GetType(), Id);
    }

    public static bool operator ==(Entity<TId>? left, Entity<TId>? right)
    {
        return Equals(left, right);
    }

    public static bool operator !=(Entity<TId>? left, Entity<TId>? right)
    {
        return !Equals(left, right);
    }
}
```

### 2. Value Object Base Class

```csharp
// Domain/ValueObject.cs
using System;
using System.Collections.Generic;
using System.Linq;

namespace BahyWay.SharedKernel.Domain;

/// <summary>
/// Base class for all value objects.
/// Value objects are immutable and defined by their attributes, not by an identity.
/// </summary>
public abstract class ValueObject : IEquatable<ValueObject>
{
    /// <summary>
    /// Gets the components that define the value object's equality.
    /// </summary>
    protected abstract IEnumerable<object?> GetEqualityComponents();

    public bool Equals(ValueObject? other)
    {
        if (other is null || other.GetType() != GetType())
        {
            return false;
        }

        return GetEqualityComponents()
            .SequenceEqual(other.GetEqualityComponents());
    }

    public override bool Equals(object? obj)
    {
        return obj is ValueObject other && Equals(other);
    }

    public override int GetHashCode()
    {
        return GetEqualityComponents()
            .Where(x => x != null)
            .Aggregate(1, (current, obj) =>
            {
                unchecked
                {
                    return current * 23 + obj!.GetHashCode();
                }
            });
    }

    public static bool operator ==(ValueObject? left, ValueObject? right)
    {
        return Equals(left, right);
    }

    public static bool operator !=(ValueObject? left, ValueObject? right)
    {
        return !Equals(left, right);
    }

    /// <summary>
    /// Creates a copy of this value object.
    /// Override this if you have complex copy logic.
    /// </summary>
    public virtual ValueObject Copy()
    {
        return (ValueObject)MemberwiseClone();
    }
}
```

### 3. Aggregate Root

```csharp
// Domain/AggregateRoot.cs
namespace BahyWay.SharedKernel.Domain;

/// <summary>
/// Base class for aggregate roots.
/// Aggregate roots are entities that act as the root of an aggregate - 
/// a cluster of domain objects that are treated as a single unit.
/// 
/// Rules:
/// 1. External objects can only reference the aggregate root
/// 2. Aggregates enforce invariants across all entities within
/// 3. Transactions should not span multiple aggregate roots
/// </summary>
/// <typeparam name="TId">The type of the aggregate root's identifier</typeparam>
public abstract class AggregateRoot<TId> : Entity<TId>
    where TId : notnull
{
    protected AggregateRoot(TId id) : base(id) { }
    
    protected AggregateRoot() : base() { }

    /// <summary>
    /// Version for optimistic concurrency control.
    /// </summary>
    public int Version { get; protected set; }

    /// <summary>
    /// Increments the version number (called by infrastructure).
    /// </summary>
    public void IncrementVersion()
    {
        Version++;
    }
}
```

### 4. Enumeration Pattern

```csharp
// Domain/Enumeration.cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace BahyWay.SharedKernel.Domain;

/// <summary>
/// Base class for implementing type-safe enumerations.
/// Better than C# enums because they can have behavior and are strongly typed.
/// 
/// Example:
/// public class AlarmSeverity : Enumeration
/// {
///     public static readonly AlarmSeverity Low = new(1, nameof(Low));
///     public static readonly AlarmSeverity High = new(2, nameof(High));
///     
///     private AlarmSeverity(int value, string name) : base(value, name) { }
/// }
/// </summary>
public abstract class Enumeration : IComparable
{
    public int Value { get; private init; }
    public string Name { get; private init; }

    protected Enumeration(int value, string name)
    {
        Value = value;
        Name = name;
    }

    public override string ToString() => Name;

    public static IEnumerable<T> GetAll<T>() where T : Enumeration
    {
        var fields = typeof(T).GetFields(
            BindingFlags.Public | 
            BindingFlags.Static | 
            BindingFlags.DeclaredOnly);

        return fields
            .Select(f => f.GetValue(null))
            .Cast<T>();
    }

    public static T FromValue<T>(int value) where T : Enumeration
    {
        var matchingItem = Parse<T, int>(value, "value", item => item.Value == value);
        return matchingItem;
    }

    public static T FromName<T>(string name) where T : Enumeration
    {
        var matchingItem = Parse<T, string>(name, "name", item => item.Name == name);
        return matchingItem;
    }

    private static T Parse<T, TValue>(TValue value, string description, Func<T, bool> predicate) 
        where T : Enumeration
    {
        var matchingItem = GetAll<T>().FirstOrDefault(predicate);

        if (matchingItem == null)
        {
            throw new InvalidOperationException(
                $"'{value}' is not a valid {description} in {typeof(T)}");
        }

        return matchingItem;
    }

    public override bool Equals(object? obj)
    {
        if (obj is not Enumeration otherValue)
        {
            return false;
        }

        var typeMatches = GetType() == obj.GetType();
        var valueMatches = Value.Equals(otherValue.Value);

        return typeMatches && valueMatches;
    }

    public override int GetHashCode()
    {
        return Value.GetHashCode();
    }

    public int CompareTo(object? other)
    {
        if (other is not Enumeration otherEnumeration)
        {
            throw new ArgumentException("Object is not an Enumeration");
        }

        return Value.CompareTo(otherEnumeration.Value);
    }
}
```

### 5. Domain Events

```csharp
// Domain/IDomainEvent.cs
using System;

namespace BahyWay.SharedKernel.Domain;

/// <summary>
/// Marker interface for domain events.
/// Domain events represent something that happened in the domain that domain experts care about.
/// </summary>
public interface IDomainEvent
{
    Guid EventId { get; }
    DateTime OccurredOn { get; }
}

// Domain/DomainEvent.cs
namespace BahyWay.SharedKernel.Domain;

/// <summary>
/// Base record for domain events.
/// Use record type to ensure immutability.
/// </summary>
public abstract record DomainEvent : IDomainEvent
{
    public Guid EventId { get; init; } = Guid.NewGuid();
    public DateTime OccurredOn { get; init; } = DateTime.UtcNow;
}
```

### 6. Repository Interface

```csharp
// Domain/IRepository.cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

namespace BahyWay.SharedKernel.Domain;

/// <summary>
/// Base repository interface for aggregate roots.
/// Repositories provide collection-like access to aggregates.
/// 
/// Rules:
/// 1. One repository per aggregate root
/// 2. Repositories work with complete aggregates
/// 3. Don't expose IQueryable (use specifications instead)
/// </summary>
public interface IRepository<TAggregate, TId>
    where TAggregate : AggregateRoot<TId>
    where TId : notnull
{
    /// <summary>
    /// Gets an aggregate by its identifier.
    /// </summary>
    Task<TAggregate?> GetByIdAsync(TId id, CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets all aggregates (use with caution - prefer specifications).
    /// </summary>
    Task<List<TAggregate>> GetAllAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Adds a new aggregate.
    /// </summary>
    Task AddAsync(TAggregate aggregate, CancellationToken cancellationToken = default);

    /// <summary>
    /// Updates an existing aggregate.
    /// </summary>
    void Update(TAggregate aggregate);

    /// <summary>
    /// Removes an aggregate.
    /// </summary>
    void Remove(TAggregate aggregate);

    /// <summary>
    /// Checks if an aggregate exists.
    /// </summary>
    Task<bool> ExistsAsync(TId id, CancellationToken cancellationToken = default);

    /// <summary>
    /// Finds aggregates matching a specification.
    /// </summary>
    Task<List<TAggregate>> FindAsync(
        ISpecification<TAggregate> specification,
        CancellationToken cancellationToken = default);
}
```

### 7. Specification Pattern

```csharp
// Domain/ISpecification.cs
using System;
using System.Linq.Expressions;

namespace BahyWay.SharedKernel.Domain;

/// <summary>
/// Specification pattern for querying aggregates.
/// Encapsulates query logic in reusable, testable objects.
/// </summary>
public interface ISpecification<T>
{
    Expression<Func<T, bool>> Criteria { get; }
    List<Expression<Func<T, object>>> Includes { get; }
    Expression<Func<T, object>>? OrderBy { get; }
    Expression<Func<T, object>>? OrderByDescending { get; }
    int Take { get; }
    int Skip { get; }
    bool IsPagingEnabled { get; }
}

// Domain/Specification.cs
public abstract class Specification<T> : ISpecification<T>
{
    protected Specification(Expression<Func<T, bool>> criteria)
    {
        Criteria = criteria;
    }

    public Expression<Func<T, bool>> Criteria { get; }
    public List<Expression<Func<T, object>>> Includes { get; } = new();
    public Expression<Func<T, object>>? OrderBy { get; private set; }
    public Expression<Func<T, object>>? OrderByDescending { get; private set; }
    public int Take { get; private set; }
    public int Skip { get; private set; }
    public bool IsPagingEnabled { get; private set; }

    protected virtual void AddInclude(Expression<Func<T, object>> includeExpression)
    {
        Includes.Add(includeExpression);
    }

    protected virtual void ApplyPaging(int skip, int take)
    {
        Skip = skip;
        Take = take;
        IsPagingEnabled = true;
    }

    protected virtual void ApplyOrderBy(Expression<Func<T, object>> orderByExpression)
    {
        OrderBy = orderByExpression;
    }

    protected virtual void ApplyOrderByDescending(Expression<Func<T, object>> orderByDescExpression)
    {
        OrderByDescending = orderByDescExpression;
    }
}
```

### 8. Result Pattern

```csharp
// Results/Error.cs
namespace BahyWay.SharedKernel.Results;

/// <summary>
/// Represents an error that occurred during an operation.
/// </summary>
public sealed record Error
{
    public string Code { get; init; }
    public string Message { get; init; }
    public ErrorType Type { get; init; }

    public Error(string code, string message, ErrorType type = ErrorType.Failure)
    {
        Code = code;
        Message = message;
        Type = type;
    }

    public static Error None => new(string.Empty, string.Empty, ErrorType.None);
    public static Error NullValue => new("Error.NullValue", "Null value was provided", ErrorType.Failure);
}

public enum ErrorType
{
    None = 0,
    Failure = 1,
    Validation = 2,
    NotFound = 3,
    Conflict = 4
}

// Results/Result.cs
namespace BahyWay.SharedKernel.Results;

/// <summary>
/// Result pattern implementation for operation outcomes.
/// Use instead of throwing exceptions for expected failures.
/// </summary>
public class Result
{
    protected Result(bool isSuccess, Error error)
    {
        if (isSuccess && error != Error.None)
        {
            throw new InvalidOperationException();
        }

        if (!isSuccess && error == Error.None)
        {
            throw new InvalidOperationException();
        }

        IsSuccess = isSuccess;
        Error = error;
    }

    public bool IsSuccess { get; }
    public bool IsFailure => !IsSuccess;
    public Error Error { get; }

    public static Result Success() => new(true, Error.None);
    
    public static Result Failure(Error error) => new(false, error);
    
    public static Result Failure(string code, string message) => 
        new(false, new Error(code, message));

    public static Result<TValue> Success<TValue>(TValue value) => 
        new(value, true, Error.None);
    
    public static Result<TValue> Failure<TValue>(Error error) => 
        new(default!, false, error);
    
    public static Result<TValue> Create<TValue>(TValue? value) =>
        value is not null ? Success(value) : Failure<TValue>(Error.NullValue);
}

// Results/Result{T}.cs
public class Result<TValue> : Result
{
    private readonly TValue? _value;

    protected internal Result(TValue? value, bool isSuccess, Error error)
        : base(isSuccess, error)
    {
        _value = value;
    }

    public TValue Value => IsSuccess
        ? _value!
        : throw new InvalidOperationException("Cannot access value of a failed result");

    public static implicit operator Result<TValue>(TValue? value) => 
        Create(value);
}
```

### 9. Guard Clauses

```csharp
// Guards/Guard.cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using BahyWay.SharedKernel.Exceptions;

namespace BahyWay.SharedKernel.Guards;

/// <summary>
/// Guard clauses for validating method arguments.
/// Throws appropriate exceptions when validation fails.
/// </summary>
public static class Guard
{
    /// <summary>
    /// Guards against null values.
    /// </summary>
    public static class Against
    {
        public static void Null<T>(
            T value,
            [CallerArgumentExpression(nameof(value))] string? paramName = null)
            where T : class
        {
            if (value is null)
            {
                throw new ArgumentNullException(paramName);
            }
        }

        public static void NullOrEmpty(
            string value,
            [CallerArgumentExpression(nameof(value))] string? paramName = null)
        {
            if (string.IsNullOrEmpty(value))
            {
                throw new ArgumentException("Value cannot be null or empty", paramName);
            }
        }

        public static void NullOrWhiteSpace(
            string value,
            [CallerArgumentExpression(nameof(value))] string? paramName = null)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentException("Value cannot be null or whitespace", paramName);
            }
        }

        public static void NegativeOrZero(
            int value,
            [CallerArgumentExpression(nameof(value))] string? paramName = null)
        {
            if (value <= 0)
            {
                throw new ArgumentException("Value must be positive", paramName);
            }
        }

        public static void Negative(
            int value,
            [CallerArgumentExpression(nameof(value))] string? paramName = null)
        {
            if (value < 0)
            {
                throw new ArgumentException("Value cannot be negative", paramName);
            }
        }

        public static void NullOrEmpty<T>(
            IEnumerable<T> value,
            [CallerArgumentExpression(nameof(value))] string? paramName = null)
        {
            Null(value, paramName);
            if (!value.Any())
            {
                throw new ArgumentException("Collection cannot be empty", paramName);
            }
        }

        public static void OutOfRange<T>(
            T value,
            T min,
            T max,
            [CallerArgumentExpression(nameof(value))] string? paramName = null)
            where T : IComparable<T>
        {
            if (value.CompareTo(min) < 0 || value.CompareTo(max) > 0)
            {
                throw new ArgumentOutOfRangeException(
                    paramName,
                    $"Value must be between {min} and {max}");
            }
        }

        public static void InvalidEmail(
            string email,
            [CallerArgumentExpression(nameof(email))] string? paramName = null)
        {
            NullOrWhiteSpace(email, paramName);
            
            if (!email.Contains('@') || !email.Contains('.'))
            {
                throw new ArgumentException("Invalid email format", paramName);
            }
        }
    }
}
```

### 10. Domain Exceptions

```csharp
// Exceptions/DomainException.cs
using System;

namespace BahyWay.SharedKernel.Exceptions;

/// <summary>
/// Base exception for all domain-specific exceptions.
/// </summary>
public abstract class DomainException : Exception
{
    protected DomainException(string message) : base(message) { }
    
    protected DomainException(string message, Exception innerException) 
        : base(message, innerException) { }
}

// Exceptions/BusinessRuleException.cs
public class BusinessRuleException : DomainException
{
    public string RuleName { get; }

    public BusinessRuleException(string ruleName, string message) 
        : base(message)
    {
        RuleName = ruleName;
    }
}

// Exceptions/NotFoundException.cs
public class NotFoundException : DomainException
{
    public string EntityName { get; }
    public object EntityId { get; }

    public NotFoundException(string entityName, object entityId)
        : base($"{entityName} with id '{entityId}' was not found")
    {
        EntityName = entityName;
        EntityId = entityId;
    }
}

// Exceptions/ValidationException.cs
public class ValidationException : DomainException
{
    public IReadOnlyDictionary<string, string[]> Errors { get; }

    public ValidationException(IReadOnlyDictionary<string, string[]> errors)
        : base("One or more validation errors occurred")
    {
        Errors = errors;
    }
}
```

### 11. Unit of Work

```csharp
// Interfaces/IUnitOfWork.cs
using System;
using System.Threading;
using System.Threading.Tasks;

namespace BahyWay.SharedKernel.Interfaces;

/// <summary>
/// Unit of Work pattern implementation.
/// Maintains a list of objects affected by a business transaction
/// and coordinates the writing out of changes.
/// </summary>
public interface IUnitOfWork : IDisposable
{
    /// <summary>
    /// Saves all changes made in this unit of work.
    /// </summary>
    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Begins a database transaction.
    /// </summary>
    Task BeginTransactionAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Commits the current transaction.
    /// </summary>
    Task CommitTransactionAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Rolls back the current transaction.
    /// </summary>
    Task RollbackTransactionAsync(CancellationToken cancellationToken = default);
}
```

### 12. Domain Event Dispatcher

```csharp
// Interfaces/IDomainEventDispatcher.cs
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using BahyWay.SharedKernel.Domain;

namespace BahyWay.SharedKernel.Interfaces;

/// <summary>
/// Dispatches domain events to their handlers.
/// </summary>
public interface IDomainEventDispatcher
{
    Task DispatchAsync(
        IEnumerable<IDomainEvent> domainEvents,
        CancellationToken cancellationToken = default);
}

// Interfaces/IDomainEventHandler.cs
public interface IDomainEventHandler<in TDomainEvent>
    where TDomainEvent : IDomainEvent
{
    Task Handle(TDomainEvent domainEvent, CancellationToken cancellationToken = default);
}
```

### 13. Auditable Interface

```csharp
// Interfaces/IAuditable.cs
using System;

namespace BahyWay.SharedKernel.Interfaces;

/// <summary>
/// Interface for entities that track creation and modification.
/// </summary>
public interface IAuditable
{
    DateTime CreatedAt { get; set; }
    string? CreatedBy { get; set; }
    DateTime? ModifiedAt { get; set; }
    string? ModifiedBy { get; set; }
}
```

---

## 📦 NuGet Packages Required

```xml
<ItemGroup>
    <!-- No dependencies! SharedKernel is pure domain logic -->
    <!-- Only .NET 8 base class library -->
</ItemGroup>
```

---

## ✅ This SharedKernel is:

✅ **Dependency-Free:** No external packages  
✅ **Cross-Platform:** Works everywhere .NET 8 runs  
✅ **Battle-Tested:** Based on proven DDD patterns  
✅ **Testable:** Every class can be unit tested  
✅ **Immutable:** Value objects and events are immutable  
✅ **Type-Safe:** Strong typing throughout  
✅ **Well-Documented:** XML comments for IntelliSense  

---

**Next:** I'll show you how to use this in a concrete bounded context (AlarmManagement).
