# SimulateWay - Part 3: Complete Integration & Examples

## 🎮 Timeline ViewModel

### TimelineViewModel.cs

```csharp
// Desktop/ViewModels/TimelineViewModel.cs
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive;
using System.Threading.Tasks;
using System.Timers;
using ReactiveUI;
using BahyWay.SimulateWay.Domain.Aggregates.Animation;

namespace BahyWay.SimulateWay.Desktop.ViewModels;

public class TimelineViewModel : ViewModelBase, IDisposable
{
    private readonly Animation _animation;
    private readonly IAnimationRenderer _renderer;
    private readonly Timer _playbackTimer;
    
    private Duration _currentTime;
    private bool _isPlaying;
    private string _playButtonText = "▶";
    private double _playheadPosition;
    private double _timelineWidth = 2000;
    private double _timelineHeight = 400;
    private string _playbackSpeed = "1x";
    
    public Duration CurrentTime
    {
        get => _currentTime;
        set
        {
            this.RaiseAndSetIfChanged(ref _currentTime, value);
            UpdatePlayheadPosition();
        }
    }
    
    public bool IsPlaying
    {
        get => _isPlaying;
        set
        {
            this.RaiseAndSetIfChanged(ref _isPlaying, value);
            PlayButtonText = value ? "⏸" : "▶";
        }
    }
    
    public string PlayButtonText
    {
        get => _playButtonText;
        set => this.RaiseAndSetIfChanged(ref _playButtonText, value);
    }
    
    public double PlayheadPosition
    {
        get => _playheadPosition;
        set => this.RaiseAndSetIfChanged(ref _playheadPosition, value);
    }
    
    public double TimelineWidth
    {
        get => _timelineWidth;
        set => this.RaiseAndSetIfChanged(ref _timelineWidth, value);
    }
    
    public double TimelineHeight
    {
        get => _timelineHeight;
        set => this.RaiseAndSetIfChanged(ref _timelineHeight, value);
    }
    
    public string PlaybackSpeed
    {
        get => _playbackSpeed;
        set => this.RaiseAndSetIfChanged(ref _playbackSpeed, value);
    }
    
    public string TotalDuration => _animation.TotalDuration.ToString();
    
    public ObservableCollection<TimeMarkerViewModel> TimeMarkers { get; } = new();
    public ObservableCollection<SceneTrackViewModel> SceneTracks { get; } = new();
    
    // Commands
    public ReactiveCommand<Unit, Unit> PlayPauseCommand { get; }
    public ReactiveCommand<Unit, Unit> StepForwardCommand { get; }
    public ReactiveCommand<Unit, Unit> StepBackCommand { get; }
    public ReactiveCommand<Unit, Unit> SkipToStartCommand { get; }
    public ReactiveCommand<Unit, Unit> SkipToEndCommand { get; }
    
    public TimelineViewModel(
        Animation animation,
        IAnimationRenderer renderer)
    {
        _animation = animation;
        _renderer = renderer;
        _currentTime = Duration.FromSeconds(0);
        
        // Setup playback timer
        _playbackTimer = new Timer(1000.0 / animation.Settings.FrameRate);
        _playbackTimer.Elapsed += OnPlaybackTick;
        
        // Initialize commands
        PlayPauseCommand = ReactiveCommand.Create(PlayPause);
        StepForwardCommand = ReactiveCommand.Create(StepForward);
        StepBackCommand = ReactiveCommand.Create(StepBack);
        SkipToStartCommand = ReactiveCommand.Create(SkipToStart);
        SkipToEndCommand = ReactiveCommand.Create(SkipToEnd);
        
        // Initialize timeline
        InitializeTimeline();
    }
    
    private void InitializeTimeline()
    {
        // Calculate timeline width based on duration
        var pixelsPerSecond = 100.0;
        TimelineWidth = _animation.TotalDuration.TotalSeconds * pixelsPerSecond + 200;
        
        // Generate time markers
        var markerInterval = 1.0; // 1 second intervals
        for (double t = 0; t <= _animation.TotalDuration.TotalSeconds; t += markerInterval)
        {
            TimeMarkers.Add(new TimeMarkerViewModel
            {
                TimeText = $"{t:F1}s",
                Position = t * pixelsPerSecond + 160,
                TextPosition = t * pixelsPerSecond + 155
            });
        }
        
        // Create scene tracks
        var trackViewModel = new SceneTrackViewModel
        {
            SceneName = "Scenes"
        };
        
        foreach (var scene in _animation.Scenes)
        {
            var keyframe = _animation.Timeline.Keyframes
                .FirstOrDefault(k => k.Scene.Id == scene.Id);
            
            if (keyframe != null)
            {
                trackViewModel.Keyframes.Add(new KeyframeViewModel
                {
                    SceneName = scene.Name,
                    Position = keyframe.Time.TotalSeconds * pixelsPerSecond + 160,
                    Width = scene.Duration.TotalSeconds * pixelsPerSecond,
                    Color = "#2196F3"
                });
            }
        }
        
        SceneTracks.Add(trackViewModel);
    }
    
    private void PlayPause()
    {
        if (IsPlaying)
        {
            _playbackTimer.Stop();
            IsPlaying = false;
        }
        else
        {
            _playbackTimer.Start();
            IsPlaying = true;
        }
    }
    
    private void StepForward()
    {
        var frameTime = 1.0 / _animation.Settings.FrameRate;
        CurrentTime = CurrentTime.Add(Duration.FromSeconds(frameTime));
        
        if (CurrentTime > _animation.TotalDuration)
        {
            CurrentTime = _animation.TotalDuration;
        }
    }
    
    private void StepBack()
    {
        var frameTime = 1.0 / _animation.Settings.FrameRate;
        CurrentTime = CurrentTime.Subtract(Duration.FromSeconds(frameTime));
        
        if (CurrentTime < Duration.FromSeconds(0))
        {
            CurrentTime = Duration.FromSeconds(0);
        }
    }
    
    private void SkipToStart()
    {
        CurrentTime = Duration.FromSeconds(0);
    }
    
    private void SkipToEnd()
    {
        CurrentTime = _animation.TotalDuration;
    }
    
    private void OnPlaybackTick(object? sender, ElapsedEventArgs e)
    {
        if (!IsPlaying)
            return;
        
        var speed = ParsePlaybackSpeed();
        var frameTime = (1.0 / _animation.Settings.FrameRate) * speed;
        
        CurrentTime = CurrentTime.Add(Duration.FromSeconds(frameTime));
        
        if (CurrentTime >= _animation.TotalDuration)
        {
            CurrentTime = _animation.TotalDuration;
            PlayPause(); // Stop at end
        }
    }
    
    private double ParsePlaybackSpeed()
    {
        return PlaybackSpeed switch
        {
            "0.25x" => 0.25,
            "0.5x" => 0.5,
            "1x" => 1.0,
            "1.5x" => 1.5,
            "2x" => 2.0,
            _ => 1.0
        };
    }
    
    private void UpdatePlayheadPosition()
    {
        var pixelsPerSecond = 100.0;
        PlayheadPosition = CurrentTime.TotalSeconds * pixelsPerSecond + 160;
    }
    
    public void Dispose()
    {
        _playbackTimer?.Dispose();
    }
}

public class TimeMarkerViewModel : ViewModelBase
{
    public string TimeText { get; set; } = "";
    public double Position { get; set; }
    public double TextPosition { get; set; }
}

public class SceneTrackViewModel : ViewModelBase
{
    public string SceneName { get; set; } = "";
    public ObservableCollection<KeyframeViewModel> Keyframes { get; } = new();
}

public class KeyframeViewModel : ViewModelBase
{
    public string SceneName { get; set; } = "";
    public double Position { get; set; }
    public double Width { get; set; }
    public string Color { get; set; } = "#2196F3";
}
```

---

## 🏗️ Animation Builder

### AnimationBuilderService.cs

```csharp
// Application/Services/AnimationBuilderService.cs
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BahyWay.SharedKernel.Results;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;
using BahyWay.SimulateWay.Domain.Aggregates.Animation;

namespace BahyWay.SimulateWay.Application.Services;

/// <summary>
/// High-level service for building animations from graphs.
/// </summary>
public interface IAnimationBuilderService
{
    Task<Result<Animation>> CreateFromGraphAsync(
        Graph graph,
        AnimationTemplate template);
    
    Task<Result<Animation>> CreateCustomAnimationAsync(
        Graph graph,
        AnimationSettings settings);
}

public class AnimationBuilderService : IAnimationBuilderService
{
    public async Task<Result<Animation>> CreateFromGraphAsync(
        Graph graph,
        AnimationTemplate template)
    {
        var settings = new AnimationSettings
        {
            Width = 1920,
            Height = 1080,
            FrameRate = 30,
            BackgroundColor = Color.FromRgb(30, 30, 30)
        };
        
        var animation = Animation.Create(
            $"{graph.Name} Animation",
            graph.Id,
            settings);
        
        // Build animation based on template
        switch (template)
        {
            case AnimationTemplate.SequentialFlow:
                return await BuildSequentialFlowAsync(animation, graph);
            
            case AnimationTemplate.ParallelExecution:
                return await BuildParallelExecutionAsync(animation, graph);
            
            case AnimationTemplate.DataFlow:
                return await BuildDataFlowAsync(animation, graph);
            
            case AnimationTemplate.Highlight:
                return await BuildHighlightAnimationAsync(animation, graph);
            
            default:
                return await BuildSequentialFlowAsync(animation, graph);
        }
    }
    
    private async Task<Result<Animation>> BuildSequentialFlowAsync(
        Animation animation,
        Graph graph)
    {
        // Get execution order (topological sort)
        var executionOrder = GetExecutionOrder(graph);
        
        var sceneDuration = Duration.FromSeconds(2.0);
        
        foreach (var node in executionOrder)
        {
            // Create scene for this node
            var elements = new List<SceneElement>();
            
            // Add all graph elements to scene
            foreach (var n in graph.Nodes)
            {
                elements.Add(new SceneElement
                {
                    ElementId = n.Id.Value.ToString(),
                    Type = ElementType.Node,
                    IsHighlighted = n.Id == node.Id, // Highlight current node
                    IsVisible = true,
                    Opacity = n.Id == node.Id ? 1.0 : 0.5
                });
            }
            
            foreach (var edge in graph.Edges)
            {
                elements.Add(new SceneElement
                {
                    ElementId = edge.Id.Value.ToString(),
                    Type = ElementType.Edge,
                    IsVisible = true,
                    Opacity = 0.5
                });
            }
            
            // Create scene
            var sceneResult = animation.AddScene(
                $"Step: {node.Name}",
                sceneDuration,
                elements);
            
            if (sceneResult.IsFailure)
                return Result.Failure<Animation>(sceneResult.Error);
            
            // Add highlight effect
            var scene = sceneResult.Value;
            var highlightEffect = HighlightEffect.Create(
                Duration.FromSeconds(0),
                sceneDuration,
                node.Id.Value.ToString(),
                Color.FromRgb(255, 193, 7), // Amber
                borderWidth: 4,
                animated: true);
            
            scene.AddEffect(highlightEffect);
            
            // Add narration
            scene.SetNarration($"Executing: {node.Name}");
        }
        
        return await Task.FromResult(Result.Success(animation));
    }
    
    private async Task<Result<Animation>> BuildDataFlowAsync(
        Animation animation,
        Graph graph)
    {
        var executionOrder = GetExecutionOrder(graph);
        var sceneDuration = Duration.FromSeconds(3.0);
        
        for (int i = 0; i < executionOrder.Count - 1; i++)
        {
            var currentNode = executionOrder[i];
            var nextNode = executionOrder[i + 1];
            
            // Find edge between nodes
            var edge = graph.Edges.FirstOrDefault(e =>
                e.SourceNodeId == currentNode.Id &&
                e.TargetNodeId == nextNode.Id);
            
            if (edge == null)
                continue;
            
            // Create scene
            var elements = CreateSceneElements(graph);
            
            var sceneResult = animation.AddScene(
                $"Data flow: {currentNode.Name} → {nextNode.Name}",
                sceneDuration,
                elements);
            
            if (sceneResult.IsFailure)
                continue;
            
            var scene = sceneResult.Value;
            
            // Add data flow effect
            var dataFlowEffect = DataFlowEffect.Create(
                Duration.FromSeconds(0),
                sceneDuration,
                edge.Id.Value.ToString(),
                currentNode.Id.Value.ToString(),
                nextNode.Id.Value.ToString(),
                Color.FromRgb(76, 175, 80), // Green
                particleSpeed: 1.0,
                particleCount: 8);
            
            scene.AddEffect(dataFlowEffect);
            
            // Highlight source and target nodes
            var sourceHighlight = HighlightEffect.Create(
                Duration.FromSeconds(0),
                Duration.FromSeconds(1.0),
                currentNode.Id.Value.ToString(),
                Color.FromRgb(33, 150, 243)); // Blue
            
            var targetHighlight = HighlightEffect.Create(
                Duration.FromSeconds(2.0),
                Duration.FromSeconds(1.0),
                nextNode.Id.Value.ToString(),
                Color.FromRgb(76, 175, 80)); // Green
            
            scene.AddEffect(sourceHighlight);
            scene.AddEffect(targetHighlight);
            
            scene.SetNarration($"Processing data from {currentNode.Name} to {nextNode.Name}");
        }
        
        return await Task.FromResult(Result.Success(animation));
    }
    
    private async Task<Result<Animation>> BuildHighlightAnimationAsync(
        Animation animation,
        Graph graph)
    {
        // Simple animation that highlights each node briefly
        var sceneDuration = Duration.FromSeconds(1.5);
        
        foreach (var node in graph.Nodes)
        {
            var elements = CreateSceneElements(graph);
            
            var sceneResult = animation.AddScene(
                node.Name,
                sceneDuration,
                elements);
            
            if (sceneResult.IsFailure)
                continue;
            
            var scene = sceneResult.Value;
            
            // Pulse highlight effect
            var highlight = HighlightEffect.Create(
                Duration.FromSeconds(0),
                sceneDuration,
                node.Id.Value.ToString(),
                Color.FromRgb(255, 87, 34), // Deep Orange
                borderWidth: 5,
                animated: true);
            
            scene.AddEffect(highlight);
            scene.SetNarration(node.Name);
        }
        
        return await Task.FromResult(Result.Success(animation));
    }
    
    private List<SceneElement> CreateSceneElements(Graph graph)
    {
        var elements = new List<SceneElement>();
        
        foreach (var node in graph.Nodes)
        {
            elements.Add(new SceneElement
            {
                ElementId = node.Id.Value.ToString(),
                Type = ElementType.Node,
                IsVisible = true,
                Opacity = 1.0
            });
        }
        
        foreach (var edge in graph.Edges)
        {
            elements.Add(new SceneElement
            {
                ElementId = edge.Id.Value.ToString(),
                Type = ElementType.Edge,
                IsVisible = true,
                Opacity = 0.7
            });
        }
        
        return elements;
    }
    
    private List<Node> GetExecutionOrder(Graph graph)
    {
        // Simple topological sort
        // In production, use the execution engine's sorting
        return graph.Nodes.ToList();
    }
    
    public async Task<Result<Animation>> CreateCustomAnimationAsync(
        Graph graph,
        AnimationSettings settings)
    {
        var animation = Animation.Create(
            $"{graph.Name} Custom Animation",
            graph.Id,
            settings);
        
        // Start with empty animation - user will add scenes manually
        
        return await Task.FromResult(Result.Success(animation));
    }
}

public enum AnimationTemplate
{
    SequentialFlow,      // Highlight each node in sequence
    ParallelExecution,   // Show parallel branches
    DataFlow,           // Animate data packets flowing
    Highlight,          // Quick highlight of all nodes
    Custom             // Manual scene creation
}
```

---

## 🎬 Complete Integration with KGEditorWay

### Integration in MainViewModel

```csharp
// KGEditorWay.Desktop/ViewModels/MainViewModel.cs (Enhanced)
public class MainViewModel : ViewModelBase
{
    // ... existing properties ...
    
    private readonly IAnimationBuilderService _animationBuilder;
    private readonly IGifExporter _gifExporter;
    
    public ReactiveCommand<Unit, Unit> CreateAnimationCommand { get; }
    public ReactiveCommand<Unit, Unit> ExportToGifCommand { get; }
    
    public MainViewModel(
        // ... existing dependencies ...
        IAnimationBuilderService animationBuilder,
        IGifExporter gifExporter)
    {
        // ... existing initialization ...
        
        _animationBuilder = animationBuilder;
        _gifExporter = gifExporter;
        
        CreateAnimationCommand = ReactiveCommand.CreateFromTask(CreateAnimation);
        ExportToGifCommand = ReactiveCommand.CreateFromTask(ExportToGif);
    }
    
    private async Task CreateAnimation()
    {
        if (CurrentGraph == null)
        {
            await _dialogService.ShowMessageAsync(
                "No Graph",
                "Please create or load a graph first.");
            return;
        }
        
        // Show template selection dialog
        var template = await ShowTemplateSelectionAsync();
        
        if (template == null)
            return;
        
        // Create animation
        var result = await _animationBuilder.CreateFromGraphAsync(
            CurrentGraph,
            template.Value);
        
        if (result.IsFailure)
        {
            await _dialogService.ShowMessageAsync(
                "Error",
                $"Failed to create animation: {result.Error.Description}");
            return;
        }
        
        // Open animation editor
        var animationEditor = new AnimationEditorViewModel(
            result.Value,
            _animationRenderer,
            _gifExporter);
        
        await _dialogService.ShowDialogAsync(animationEditor);
    }
    
    private async Task ExportToGif()
    {
        if (CurrentGraph == null)
            return;
        
        var outputPath = await _dialogService.ShowSaveFileDialogAsync(
            "Export Animation",
            new[] { "gif" },
            "animation.gif");
        
        if (string.IsNullOrEmpty(outputPath))
            return;
        
        // Create quick animation
        var animationResult = await _animationBuilder.CreateFromGraphAsync(
            CurrentGraph,
            AnimationTemplate.SequentialFlow);
        
        if (animationResult.IsFailure)
        {
            await _dialogService.ShowMessageAsync(
                "Error",
                $"Failed to create animation: {animationResult.Error.Description}");
            return;
        }
        
        // Show progress
        var progress = new Progress<double>(p =>
        {
            // Update progress bar
        });
        
        // Export
        var exportResult = await _gifExporter.ExportAsync(
            animationResult.Value,
            outputPath,
            progress);
        
        if (exportResult.IsFailure)
        {
            await _dialogService.ShowMessageAsync(
                "Error",
                $"Failed to export: {exportResult.Error.Description}");
            return;
        }
        
        await _dialogService.ShowMessageAsync(
            "Success",
            $"Animation exported to: {outputPath}");
    }
    
    private async Task<AnimationTemplate?> ShowTemplateSelectionAsync()
    {
        // Show dialog with template options
        // For now, return default
        return AnimationTemplate.SequentialFlow;
    }
}
```

---

## 🎯 Real-World Example: PostgreSQL Replication Animation

### PostgreSQLReplicationAnimationExample.cs

```csharp
// Example: Creating animation like the uploaded GIF
public class PostgreSQLReplicationAnimationExample
{
    public async Task<Animation> CreateReplicationAnimationAsync()
    {
        // Create graph representing PostgreSQL replication
        var graph = Graph.Create("PostgreSQL Streaming Replication", GraphType.Process);
        
        // Primary server
        var primary = graph.AddNode("Primary Server", 
            new NodeType(1, "Database", "🗄️", "#336791"),
            Position.Create(100, 200));
        primary.Value.SetProperty("role", "Primary");
        primary.Value.SetProperty("host", "primary.db.local");
        
        // WAL Writer
        var walWriter = graph.AddNode("WAL Writer", 
            new NodeType(2, "Process", "📝", "#4CAF50"),
            Position.Create(300, 150));
        
        // WAL Sender
        var walSender = graph.AddNode("WAL Sender", 
            new NodeType(3, "Process", "📤", "#2196F3"),
            Position.Create(500, 150));
        
        // Standby server
        var standby = graph.AddNode("Standby Server", 
            new NodeType(4, "Database", "🗄️", "#607D8B"),
            Position.Create(900, 200));
        standby.Value.SetProperty("role", "Standby");
        standby.Value.SetProperty("host", "standby.db.local");
        
        // WAL Receiver
        var walReceiver = graph.AddNode("WAL Receiver", 
            new NodeType(5, "Process", "📥", "#2196F3"),
            Position.Create(700, 150));
        
        // Startup Process
        var startupProc = graph.AddNode("Startup Process", 
            new NodeType(6, "Process", "🚀", "#4CAF50"),
            Position.Create(900, 100));
        
        // Create connections
        graph.CreateEdge(primary.Value.Id, null, walWriter.Value.Id, null, EdgeType.DataFlow);
        graph.CreateEdge(walWriter.Value.Id, null, walSender.Value.Id, null, EdgeType.DataFlow);
        graph.CreateEdge(walSender.Value.Id, null, walReceiver.Value.Id, null, EdgeType.DataFlow);
        graph.CreateEdge(walReceiver.Value.Id, null, standby.Value.Id, null, EdgeType.DataFlow);
        graph.CreateEdge(standby.Value.Id, null, startupProc.Value.Id, null, EdgeType.DataFlow);
        
        // Create animation
        var settings = new AnimationSettings
        {
            Width = 1920,
            Height = 1080,
            FrameRate = 30,
            BackgroundColor = Color.FromRgb(245, 245, 245)
        };
        
        var animation = Animation.Create(
            "PostgreSQL Streaming Replication",
            graph.Id,
            settings);
        
        // Scene 1: Transaction on Primary
        await AddScene(animation, graph, Duration.FromSeconds(3),
            "1. Transaction occurs on Primary Server",
            new[] { primary.Value.Id.ToString() },
            Color.FromRgb(76, 175, 80));
        
        // Scene 2: WAL Writer
        await AddScene(animation, graph, Duration.FromSeconds(3),
            "2. WAL Writer writes transaction to Write-Ahead Log",
            new[] { primary.Value.Id.ToString(), walWriter.Value.Id.ToString() },
            Color.FromRgb(255, 193, 7));
        
        // Scene 3: WAL Sender
        await AddDataFlowScene(animation, graph, Duration.FromSeconds(3),
            "3. WAL Sender streams WAL records to Standby",
            walWriter.Value.Id.ToString(),
            walSender.Value.Id.ToString(),
            Color.FromRgb(33, 150, 243));
        
        // Scene 4: Network Transfer
        await AddDataFlowScene(animation, graph, Duration.FromSeconds(3),
            "4. WAL records transmitted over network",
            walSender.Value.Id.ToString(),
            walReceiver.Value.Id.ToString(),
            Color.FromRgb(156, 39, 176));
        
        // Scene 5: WAL Receiver
        await AddScene(animation, graph, Duration.FromSeconds(3),
            "5. WAL Receiver writes to Standby's WAL files",
            new[] { walReceiver.Value.Id.ToString(), standby.Value.Id.ToString() },
            Color.FromRgb(255, 152, 0));
        
        // Scene 6: Startup Process applies changes
        await AddScene(animation, graph, Duration.FromSeconds(3),
            "6. Startup Process applies WAL records to Standby database",
            new[] { standby.Value.Id.ToString(), startupProc.Value.Id.ToString() },
            Color.FromRgb(76, 175, 80));
        
        // Scene 7: Complete - both databases in sync
        await AddScene(animation, graph, Duration.FromSeconds(2),
            "7. Replication complete - databases synchronized",
            new[] { primary.Value.Id.ToString(), standby.Value.Id.ToString() },
            Color.FromRgb(76, 175, 80));
        
        return animation;
    }
    
    private async Task AddScene(
        Animation animation,
        Graph graph,
        Duration duration,
        string narration,
        string[] highlightNodeIds,
        Color highlightColor)
    {
        var elements = CreateAllElements(graph);
        
        var sceneResult = animation.AddScene(narration, duration, elements);
        if (sceneResult.IsFailure)
            return;
        
        var scene = sceneResult.Value;
        
        foreach (var nodeId in highlightNodeIds)
        {
            var highlight = HighlightEffect.Create(
                Duration.FromSeconds(0),
                duration,
                nodeId,
                highlightColor,
                borderWidth: 4,
                animated: true);
            
            scene.AddEffect(highlight);
        }
        
        scene.SetNarration(narration);
        
        await Task.CompletedTask;
    }
    
    private async Task AddDataFlowScene(
        Animation animation,
        Graph graph,
        Duration duration,
        string narration,
        string sourceNodeId,
        string targetNodeId,
        Color flowColor)
    {
        var elements = CreateAllElements(graph);
        
        var sceneResult = animation.AddScene(narration, duration, elements);
        if (sceneResult.IsFailure)
            return;
        
        var scene = sceneResult.Value;
        
        // Find edge
        var edge = graph.Edges.FirstOrDefault(e =>
            e.SourceNodeId.Value.ToString() == sourceNodeId &&
            e.TargetNodeId.Value.ToString() == targetNodeId);
        
        if (edge != null)
        {
            var dataFlow = DataFlowEffect.Create(
                Duration.FromSeconds(0),
                duration,
                edge.Id.Value.ToString(),
                sourceNodeId,
                targetNodeId,
                flowColor,
                particleSpeed: 1.0,
                particleCount: 10);
            
            scene.AddEffect(dataFlow);
        }
        
        scene.SetNarration(narration);
        
        await Task.CompletedTask;
    }
    
    private List<SceneElement> CreateAllElements(Graph graph)
    {
        var elements = new List<SceneElement>();
        
        foreach (var node in graph.Nodes)
        {
            elements.Add(new SceneElement
            {
                ElementId = node.Id.Value.ToString(),
                Type = ElementType.Node,
                IsVisible = true,
                Opacity = 1.0
            });
        }
        
        foreach (var edge in graph.Edges)
        {
            elements.Add(new SceneElement
            {
                ElementId = edge.Id.Value.ToString(),
                Type = ElementType.Edge,
                IsVisible = true,
                Opacity = 0.7
            });
        }
        
        return elements;
    }
}
```

---

## 📋 Complete Usage Guide

### Step 1: Create Graph in KGEditorWay

```csharp
// Create your workflow/process graph
var graph = Graph.Create("My Process", GraphType.Process);

var step1 = graph.AddNode("Start", NodeType.Source, Position.Create(100, 100));
var step2 = graph.AddNode("Process", NodeType.Transform, Position.Create(300, 100));
var step3 = graph.AddNode("End", NodeType.Sink, Position.Create(500, 100));

graph.CreateEdge(step1.Value.Id, null, step2.Value.Id, null, EdgeType.DataFlow);
graph.CreateEdge(step2.Value.Id, null, step3.Value.Id, null, EdgeType.DataFlow);
```

### Step 2: Create Animation

```csharp
// Create animation from graph
var animationResult = await animationBuilder.CreateFromGraphAsync(
    graph,
    AnimationTemplate.SequentialFlow);

var animation = animationResult.Value;
```

### Step 3: Export to GIF

```csharp
// Export to GIF
await gifExporter.ExportAsync(
    animation,
    "output/my_process.gif",
    progress: new Progress<double>(p => Console.WriteLine($"Progress: {p * 100}%")));
```

---

**Continue to Part 4: Advanced Features, Deployment, and Complete SimulateWay Summary?**
