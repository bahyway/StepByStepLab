# BahyWay Platform - Architectural Blueprint

## 🎯 Core Principles

This architecture follows **SOLID**, **Clean Architecture**, and **Domain-Driven Design (DDD)** principles to ensure:
- ✅ Long-term maintainability
- ✅ Scalability across all projects
- ✅ Testability at every layer
- ✅ Technology independence
- ✅ Business logic isolation
- ✅ Cross-platform compatibility

**This is your foundation. Build upon it, never replace it.**

---

## 🏛️ Clean Architecture Layers

```
┌─────────────────────────────────────────────────────────────┐
│                    PRESENTATION LAYER                        │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  Avalonia Desktop Apps                                │  │
│  │  Blazor Web Apps                                      │  │
│  │  REST APIs (Controllers)                              │  │
│  │  gRPC Services                                        │  │
│  └──────────────────────────────────────────────────────┘  │
│  Dependencies: → Application Layer                          │
└─────────────────────────────────────────────────────────────┘
                         ↓ (calls)
┌─────────────────────────────────────────────────────────────┐
│                    APPLICATION LAYER                         │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  Use Cases / Application Services                     │  │
│  │  DTOs (Data Transfer Objects)                        │  │
│  │  Interfaces for Infrastructure                       │  │
│  │  Command/Query Handlers (CQRS)                       │  │
│  │  Validation Logic                                     │  │
│  └──────────────────────────────────────────────────────┘  │
│  Dependencies: → Domain Layer                               │
└─────────────────────────────────────────────────────────────┘
                         ↓ (orchestrates)
┌─────────────────────────────────────────────────────────────┐
│                      DOMAIN LAYER                            │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  Entities (Business Objects)                          │  │
│  │  Value Objects (Immutable)                           │  │
│  │  Domain Events                                        │  │
│  │  Aggregates & Aggregate Roots                        │  │
│  │  Domain Services (Business Logic)                    │  │
│  │  Repository Interfaces                               │  │
│  │  Domain Exceptions                                    │  │
│  └──────────────────────────────────────────────────────┘  │
│  Dependencies: NONE (Pure business logic)                   │
└─────────────────────────────────────────────────────────────┘
                         ↑ (implements)
┌─────────────────────────────────────────────────────────────┐
│                  INFRASTRUCTURE LAYER                        │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  PostgreSQL Repositories                              │  │
│  │  Apache AGE Graph Repositories                        │  │
│  │  Rust Rules Engine Client                            │  │
│  │  Python ML Service Client                            │  │
│  │  External API Clients                                │  │
│  │  File System Access                                   │  │
│  │  Email/SMS Services                                   │  │
│  │  Authentication/Authorization                         │  │
│  └──────────────────────────────────────────────────────┘  │
│  Dependencies: → Domain Layer (implements interfaces)       │
└─────────────────────────────────────────────────────────────┘
```

---

## 📦 Solution Structure (All Projects Follow This)

```
BahyWay.Platform/
│
├── src/
│   │
│   ├── 1. Shared Kernel (Used by ALL projects)
│   │   ├── BahyWay.SharedKernel/
│   │   │   ├── Domain/
│   │   │   │   ├── Entity.cs                    # Base entity
│   │   │   │   ├── ValueObject.cs               # Base value object
│   │   │   │   ├── AggregateRoot.cs             # Base aggregate
│   │   │   │   ├── DomainEvent.cs               # Base event
│   │   │   │   └── IRepository.cs               # Repository interface
│   │   │   ├── Exceptions/
│   │   │   │   ├── DomainException.cs
│   │   │   │   ├── BusinessRuleException.cs
│   │   │   │   └── NotFoundException.cs
│   │   │   ├── Guards/
│   │   │   │   └── Guard.cs                     # Validation helpers
│   │   │   ├── Results/
│   │   │   │   ├── Result.cs                    # Result pattern
│   │   │   │   └── ResultExtensions.cs
│   │   │   └── Interfaces/
│   │   │       ├── IUnitOfWork.cs
│   │   │       ├── IDomainEventDispatcher.cs
│   │   │       └── IAuditable.cs
│   │   │
│   │   └── BahyWay.SharedKernel.Tests/
│   │
│   ├── 2. Building Blocks (Reusable across projects)
│   │   ├── BahyWay.BuildingBlocks.Domain/
│   │   │   ├── CommonValueObjects/
│   │   │   │   ├── Email.cs
│   │   │   │   ├── PhoneNumber.cs
│   │   │   │   ├── Address.cs
│   │   │   │   ├── Money.cs
│   │   │   │   ├── DateRange.cs
│   │   │   │   └── GeoCoordinate.cs
│   │   │   ├── CommonEntities/
│   │   │   │   ├── User.cs
│   │   │   │   ├── Organization.cs
│   │   │   │   ├── AuditLog.cs
│   │   │   │   └── Notification.cs
│   │   │   └── CommonEvents/
│   │   │       ├── UserCreatedEvent.cs
│   │   │       └── EntityDeletedEvent.cs
│   │   │
│   │   ├── BahyWay.BuildingBlocks.Application/
│   │   │   ├── CQRS/
│   │   │   │   ├── ICommand.cs
│   │   │   │   ├── IQuery.cs
│   │   │   │   ├── ICommandHandler.cs
│   │   │   │   └── IQueryHandler.cs
│   │   │   ├── DTOs/
│   │   │   │   ├── PagedResult.cs
│   │   │   │   ├── UserDto.cs
│   │   │   │   └── OrganizationDto.cs
│   │   │   ├── Behaviors/
│   │   │   │   ├── ValidationBehavior.cs
│   │   │   │   ├── LoggingBehavior.cs
│   │   │   │   └── TransactionBehavior.cs
│   │   │   └── Interfaces/
│   │   │       ├── IEventBus.cs
│   │   │       └── IIntegrationEventHandler.cs
│   │   │
│   │   └── BahyWay.BuildingBlocks.Infrastructure/
│   │       ├── Persistence/
│   │       │   ├── PostgreSQL/
│   │       │   │   ├── BaseRepository.cs
│   │       │   │   ├── UnitOfWork.cs
│   │       │   │   └── DbContextBase.cs
│   │       │   └── AGE/
│   │       │       ├── GraphRepository.cs
│   │       │       └── GraphQueryBuilder.cs
│   │       ├── Rules/
│   │       │   └── RustRulesEngineClient.cs
│   │       ├── ML/
│   │       │   └── PythonMLServiceClient.cs
│   │       ├── Messaging/
│   │       │   ├── EventBus.cs
│   │       │   └── RabbitMQEventBus.cs
│   │       ├── Caching/
│   │       │   └── RedisCacheService.cs
│   │       └── Identity/
│   │           ├── JwtTokenService.cs
│   │           └── PasswordHasher.cs
│   │
│   ├── 3. Bounded Contexts (Each major project)
│   │   │
│   │   ├── AlarmManagement/                     # AlarmInsight
│   │   │   ├── BahyWay.AlarmManagement.Domain/
│   │   │   │   ├── Aggregates/
│   │   │   │   │   ├── Alarm/
│   │   │   │   │   │   ├── Alarm.cs             # Aggregate root
│   │   │   │   │   │   ├── AlarmId.cs           # Value object
│   │   │   │   │   │   ├── AlarmSeverity.cs     # Enumeration
│   │   │   │   │   │   └── AlarmStatus.cs
│   │   │   │   │   └── Asset/
│   │   │   │   │       ├── Asset.cs
│   │   │   │   │       └── AssetId.cs
│   │   │   │   ├── ValueObjects/
│   │   │   │   │   ├── AlarmValue.cs
│   │   │   │   │   ├── ThresholdRange.cs
│   │   │   │   │   └── Location.cs
│   │   │   │   ├── DomainServices/
│   │   │   │   │   ├── AlarmClassificationService.cs
│   │   │   │   │   └── AlarmCorrelationService.cs
│   │   │   │   ├── Events/
│   │   │   │   │   ├── AlarmCreatedEvent.cs
│   │   │   │   │   ├── AlarmAcknowledgedEvent.cs
│   │   │   │   │   └── AlarmEscalatedEvent.cs
│   │   │   │   ├── Repositories/
│   │   │   │   │   ├── IAlarmRepository.cs
│   │   │   │   │   └── IAssetRepository.cs
│   │   │   │   └── Specifications/
│   │   │   │       ├── CriticalAlarmsSpec.cs
│   │   │   │       └── UnacknowledgedAlarmsSpec.cs
│   │   │   │
│   │   │   ├── BahyWay.AlarmManagement.Application/
│   │   │   │   ├── Commands/
│   │   │   │   │   ├── CreateAlarm/
│   │   │   │   │   │   ├── CreateAlarmCommand.cs
│   │   │   │   │   │   ├── CreateAlarmCommandHandler.cs
│   │   │   │   │   │   └── CreateAlarmCommandValidator.cs
│   │   │   │   │   └── AcknowledgeAlarm/
│   │   │   │   ├── Queries/
│   │   │   │   │   ├── GetAlarm/
│   │   │   │   │   │   ├── GetAlarmQuery.cs
│   │   │   │   │   │   └── GetAlarmQueryHandler.cs
│   │   │   │   │   └── GetActiveAlarms/
│   │   │   │   ├── DTOs/
│   │   │   │   │   ├── AlarmDto.cs
│   │   │   │   │   └── AssetDto.cs
│   │   │   │   ├── Services/
│   │   │   │   │   └── AlarmApplicationService.cs
│   │   │   │   └── Interfaces/
│   │   │   │       ├── IRulesEngineService.cs
│   │   │   │       └── INotificationService.cs
│   │   │   │
│   │   │   ├── BahyWay.AlarmManagement.Infrastructure/
│   │   │   │   ├── Persistence/
│   │   │   │   │   ├── AlarmManagementDbContext.cs
│   │   │   │   │   ├── Repositories/
│   │   │   │   │   │   ├── AlarmRepository.cs
│   │   │   │   │   │   └── AssetRepository.cs
│   │   │   │   │   └── Configurations/
│   │   │   │   │       ├── AlarmConfiguration.cs
│   │   │   │   │       └── AssetConfiguration.cs
│   │   │   │   ├── ExternalServices/
│   │   │   │   │   ├── RulesEngineService.cs
│   │   │   │   │   └── NotificationService.cs
│   │   │   │   └── Integration/
│   │   │   │       └── AlarmIntegrationEventHandler.cs
│   │   │   │
│   │   │   ├── BahyWay.AlarmManagement.API/
│   │   │   │   ├── Controllers/
│   │   │   │   │   └── AlarmsController.cs
│   │   │   │   ├── Program.cs
│   │   │   │   └── appsettings.json
│   │   │   │
│   │   │   └── BahyWay.AlarmManagement.Desktop/    # Avalonia
│   │   │       ├── ViewModels/
│   │   │       ├── Views/
│   │   │       └── App.axaml
│   │   │
│   │   ├── SSISAnalysis/                         # SSISight
│   │   │   ├── BahyWay.SSISAnalysis.Domain/
│   │   │   ├── BahyWay.SSISAnalysis.Application/
│   │   │   ├── BahyWay.SSISAnalysis.Infrastructure/
│   │   │   ├── BahyWay.SSISAnalysis.API/
│   │   │   └── BahyWay.SSISAnalysis.Desktop/
│   │   │
│   │   ├── GeospatialManagement/                # SteerView
│   │   │   ├── BahyWay.GeospatialManagement.Domain/
│   │   │   ├── BahyWay.GeospatialManagement.Application/
│   │   │   ├── BahyWay.GeospatialManagement.Infrastructure/
│   │   │   ├── BahyWay.GeospatialManagement.API/
│   │   │   └── BahyWay.GeospatialManagement.Desktop/
│   │   │
│   │   ├── Forecasting/                         # SmartForesight
│   │   │   ├── BahyWay.Forecasting.Domain/
│   │   │   ├── BahyWay.Forecasting.Application/
│   │   │   ├── BahyWay.Forecasting.Infrastructure/
│   │   │   ├── BahyWay.Forecasting.API/
│   │   │   └── BahyWay.Forecasting.Desktop/
│   │   │
│   │   ├── Recruitment/                         # HireWay
│   │   │   ├── BahyWay.Recruitment.Domain/
│   │   │   ├── BahyWay.Recruitment.Application/
│   │   │   ├── BahyWay.Recruitment.Infrastructure/
│   │   │   ├── BahyWay.Recruitment.API/
│   │   │   └── BahyWay.Recruitment.Web/         # Blazor
│   │   │
│   │   └── CemeteryManagement/                  # NajafCemetery
│   │       ├── BahyWay.CemeteryManagement.Domain/
│   │       ├── BahyWay.CemeteryManagement.Application/
│   │       ├── BahyWay.CemeteryManagement.Infrastructure/
│   │       ├── BahyWay.CemeteryManagement.API/
│   │       └── BahyWay.CemeteryManagement.Web/
│   │
│   └── 4. Cross-Cutting Concerns
│       ├── BahyWay.Logging/
│       ├── BahyWay.Monitoring/
│       └── BahyWay.Configuration/
│
├── tests/
│   ├── UnitTests/
│   │   ├── BahyWay.SharedKernel.Tests/
│   │   ├── BahyWay.AlarmManagement.Domain.Tests/
│   │   └── BahyWay.AlarmManagement.Application.Tests/
│   ├── IntegrationTests/
│   │   └── BahyWay.AlarmManagement.IntegrationTests/
│   └── ArchitectureTests/
│       └── BahyWay.ArchitectureTests/            # NetArchTest
│
├── docker/
│   ├── docker-compose.yml
│   ├── docker-compose.override.yml
│   └── Dockerfile (per service)
│
├── docs/
│   ├── architecture/
│   ├── domain-models/
│   └── api-specs/
│
└── BahyWay.Platform.sln
```

---

## 🎯 DDD Strategic Design

### Bounded Contexts Map

```
┌────────────────────────────────────────────────────────────┐
│                   BAHYWAY PLATFORM                          │
├────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────┐      ┌──────────────────┐            │
│  │ Alarm           │      │ SSIS Analysis    │            │
│  │ Management      │◄────►│                  │            │
│  │ (AlarmInsight)  │      │ (SSISight)       │            │
│  └────────┬────────┘      └──────────────────┘            │
│           │                                                 │
│           │ Shared Kernel                                   │
│           │ - User                                          │
│           │ - Organization                                  │
│           │ - Common Value Objects                          │
│           ↓                                                 │
│  ┌─────────────────┐      ┌──────────────────┐            │
│  │ Geospatial      │      │ Forecasting      │            │
│  │ Management      │◄────►│                  │            │
│  │ (SteerView)     │      │ (SmartForesight) │            │
│  └─────────────────┘      └──────────────────┘            │
│           ↓                        ↓                        │
│  ┌─────────────────┐      ┌──────────────────┐            │
│  │ Recruitment     │      │ Cemetery         │            │
│  │                 │      │ Management       │            │
│  │ (HireWay)       │      │ (NajafCemetery)  │            │
│  └─────────────────┘      └──────────────────┘            │
│                                                             │
│  Context Relationships:                                    │
│  ────►  Shared Kernel (U, D)                              │
│  ◄───►  Customer/Supplier (U, D)                          │
│  ═════  Partnership (P)                                    │
└────────────────────────────────────────────────────────────┘

Legend:
U = Upstream (provides)
D = Downstream (consumes)
P = Partnership (collaborate)
```

### Context Integration Patterns

```
Pattern 1: Shared Kernel
├─ What: Common domain models used by all contexts
├─ Examples: User, Organization, Email, Address
└─ Rule: Changes must be coordinated across all teams

Pattern 2: Customer/Supplier
├─ What: One context provides service to another
├─ Example: AlarmManagement → Forecasting (alarm data)
└─ Rule: Supplier defines the contract

Pattern 3: Published Language
├─ What: Well-documented integration events
├─ Example: AlarmCreatedEvent, UserRegisteredEvent
└─ Rule: Events are immutable, versioned

Pattern 4: Anti-Corruption Layer (ACL)
├─ What: Translate between contexts
├─ Example: Rust Rules Engine → .NET Domain
└─ Rule: Protect domain from external models
```

---

## 🏗️ Domain Layer - Deep Dive

### 1. Entity Base Class

```csharp
// BahyWay.SharedKernel/Domain/Entity.cs
namespace BahyWay.SharedKernel.Domain;

public abstract class Entity<TId> : IEquatable<Entity<TId>>
    where TId : notnull
{
    public TId Id { get; protected set; }
    
    private readonly List<IDomainEvent> _domainEvents = new();
    
    public IReadOnlyCollection<IDomainEvent> DomainEvents => 
        _domainEvents.AsReadOnly();
    
    protected Entity(TId id)
    {
        Id = id;
    }
    
    protected Entity() { } // EF Core
    
    protected void AddDomainEvent(IDomainEvent domainEvent)
    {
        _domainEvents.Add(domainEvent);
    }
    
    public void ClearDomainEvents()
    {
        _domainEvents.Clear();
    }
    
    public bool Equals(Entity<TId>? other)
    {
        if (other is null) return false;
        if (ReferenceEquals(this, other)) return true;
        return EqualityComparer<TId>.Default.Equals(Id, other.Id);
    }
    
    public override bool Equals(object? obj)
    {
        return obj is Entity<TId> entity && Equals(entity);
    }
    
    public override int GetHashCode()
    {
        return Id.GetHashCode();
    }
    
    public static bool operator ==(Entity<TId>? left, Entity<TId>? right)
    {
        return Equals(left, right);
    }
    
    public static bool operator !=(Entity<TId>? left, Entity<TId>? right)
    {
        return !Equals(left, right);
    }
}
```

### 2. Value Object Base Class

```csharp
// BahyWay.SharedKernel/Domain/ValueObject.cs
namespace BahyWay.SharedKernel.Domain;

public abstract class ValueObject : IEquatable<ValueObject>
{
    protected abstract IEnumerable<object?> GetEqualityComponents();
    
    public bool Equals(ValueObject? other)
    {
        if (other is null || other.GetType() != GetType())
        {
            return false;
        }
        
        return GetEqualityComponents()
            .SequenceEqual(other.GetEqualityComponents());
    }
    
    public override bool Equals(object? obj)
    {
        return obj is ValueObject other && Equals(other);
    }
    
    public override int GetHashCode()
    {
        return GetEqualityComponents()
            .Where(x => x != null)
            .Aggregate(1, (current, obj) =>
            {
                unchecked
                {
                    return current * 23 + obj!.GetHashCode();
                }
            });
    }
    
    public static bool operator ==(ValueObject? left, ValueObject? right)
    {
        return Equals(left, right);
    }
    
    public static bool operator !=(ValueObject? left, ValueObject? right)
    {
        return !Equals(left, right);
    }
}
```

### 3. Aggregate Root

```csharp
// BahyWay.SharedKernel/Domain/AggregateRoot.cs
namespace BahyWay.SharedKernel.Domain;

public abstract class AggregateRoot<TId> : Entity<TId>
    where TId : notnull
{
    protected AggregateRoot(TId id) : base(id) { }
    protected AggregateRoot() { }
}
```

### 4. Domain Event

```csharp
// BahyWay.SharedKernel/Domain/IDomainEvent.cs
namespace BahyWay.SharedKernel.Domain;

public interface IDomainEvent
{
    Guid EventId { get; }
    DateTime OccurredOn { get; }
}

public abstract record DomainEvent : IDomainEvent
{
    public Guid EventId { get; init; } = Guid.NewGuid();
    public DateTime OccurredOn { get; init; } = DateTime.UtcNow;
}
```

---

## 📋 Concrete Example: Alarm Aggregate

```csharp
// BahyWay.AlarmManagement.Domain/Aggregates/Alarm/AlarmId.cs
namespace BahyWay.AlarmManagement.Domain.Aggregates.Alarm;

public record AlarmId(Guid Value)
{
    public static AlarmId New() => new(Guid.NewGuid());
    public static AlarmId From(Guid value) => new(value);
    
    public override string ToString() => Value.ToString();
}

// BahyWay.AlarmManagement.Domain/Aggregates/Alarm/AlarmSeverity.cs
public class AlarmSeverity : Enumeration
{
    public static readonly AlarmSeverity Info = new(1, nameof(Info));
    public static readonly AlarmSeverity Low = new(2, nameof(Low));
    public static readonly AlarmSeverity Medium = new(3, nameof(Medium));
    public static readonly AlarmSeverity High = new(4, nameof(High));
    public static readonly AlarmSeverity Critical = new(5, nameof(Critical));
    
    private AlarmSeverity(int value, string name) : base(value, name) { }
}

// BahyWay.AlarmManagement.Domain/Aggregates/Alarm/Alarm.cs
public class Alarm : AggregateRoot<AlarmId>
{
    public AssetId AssetId { get; private set; }
    public AlarmSeverity Severity { get; private set; }
    public AlarmValue Value { get; private set; }
    public AlarmStatus Status { get; private set; }
    public DateTime OccurredAt { get; private set; }
    public DateTime? AcknowledgedAt { get; private set; }
    public string? AcknowledgedBy { get; private set; }
    public string Message { get; private set; }
    
    // EF Core
    private Alarm() { }
    
    // Factory method (encapsulates creation logic)
    public static Alarm Create(
        AssetId assetId,
        AlarmSeverity severity,
        AlarmValue value,
        string message)
    {
        Guard.Against.Null(assetId, nameof(assetId));
        Guard.Against.Null(severity, nameof(severity));
        Guard.Against.Null(value, nameof(value));
        Guard.Against.NullOrWhiteSpace(message, nameof(message));
        
        var alarm = new Alarm
        {
            Id = AlarmId.New(),
            AssetId = assetId,
            Severity = severity,
            Value = value,
            Status = AlarmStatus.Active,
            OccurredAt = DateTime.UtcNow,
            Message = message
        };
        
        alarm.AddDomainEvent(new AlarmCreatedEvent(alarm.Id, alarm.AssetId, alarm.Severity));
        
        return alarm;
    }
    
    // Business logic methods
    public Result Acknowledge(string acknowledgedBy)
    {
        if (Status != AlarmStatus.Active)
        {
            return Result.Failure("Only active alarms can be acknowledged");
        }
        
        Status = AlarmStatus.Acknowledged;
        AcknowledgedAt = DateTime.UtcNow;
        AcknowledgedBy = acknowledgedBy;
        
        AddDomainEvent(new AlarmAcknowledgedEvent(Id, acknowledgedBy));
        
        return Result.Success();
    }
    
    public Result Escalate()
    {
        if (Severity == AlarmSeverity.Critical)
        {
            return Result.Failure("Already at maximum severity");
        }
        
        // Business logic: escalate severity
        var newSeverity = Severity.Value switch
        {
            1 => AlarmSeverity.Low,
            2 => AlarmSeverity.Medium,
            3 => AlarmSeverity.High,
            4 => AlarmSeverity.Critical,
            _ => AlarmSeverity.Critical
        };
        
        Severity = newSeverity;
        
        AddDomainEvent(new AlarmEscalatedEvent(Id, newSeverity));
        
        return Result.Success();
    }
    
    public bool IsOverdue(TimeSpan threshold)
    {
        return Status == AlarmStatus.Active && 
               DateTime.UtcNow - OccurredAt > threshold;
    }
}
```

---

## ✅ Architecture Tests (Enforced!)

```csharp
// tests/ArchitectureTests/BahyWay.ArchitectureTests/ArchitectureTests.cs
using NetArchTest.Rules;

namespace BahyWay.ArchitectureTests;

public class ArchitectureTests
{
    private const string DomainNamespace = "BahyWay.*.Domain";
    private const string ApplicationNamespace = "BahyWay.*.Application";
    private const string InfrastructureNamespace = "BahyWay.*.Infrastructure";
    private const string PresentationNamespace = "BahyWay.*.API";
    
    [Fact]
    public void Domain_Should_Not_Have_Dependency_On_Application()
    {
        var result = Types.InAssembly(typeof(Alarm).Assembly)
            .That().ResideInNamespace(DomainNamespace)
            .ShouldNot().HaveDependencyOn(ApplicationNamespace)
            .GetResult();
        
        Assert.True(result.IsSuccessful);
    }
    
    [Fact]
    public void Domain_Should_Not_Have_Dependency_On_Infrastructure()
    {
        var result = Types.InAssembly(typeof(Alarm).Assembly)
            .That().ResideInNamespace(DomainNamespace)
            .ShouldNot().HaveDependencyOn(InfrastructureNamespace)
            .GetResult();
        
        Assert.True(result.IsSuccessful);
    }
    
    [Fact]
    public void Application_Should_Not_Have_Dependency_On_Infrastructure()
    {
        var result = Types.InAssembly(typeof(CreateAlarmCommand).Assembly)
            .That().ResideInNamespace(ApplicationNamespace)
            .ShouldNot().HaveDependencyOn(InfrastructureNamespace)
            .GetResult();
        
        Assert.True(result.IsSuccessful);
    }
    
    [Fact]
    public void Entities_Should_Be_Sealed_Or_Abstract()
    {
        var result = Types.InAssembly(typeof(Alarm).Assembly)
            .That().Inherit(typeof(Entity<>))
            .Should().BeSealed().Or().BeAbstract()
            .GetResult();
        
        Assert.True(result.IsSuccessful);
    }
    
    [Fact]
    public void ValueObjects_Should_Be_Immutable()
    {
        var result = Types.InAssembly(typeof(AlarmValue).Assembly)
            .That().Inherit(typeof(ValueObject))
            .Should().HaveProperty("init")
            .GetResult();
        
        Assert.True(result.IsSuccessful);
    }
}
```

---

## 🎯 Key Architectural Decisions

### Decision 1: CQRS (Command Query Responsibility Segregation)
**Why:** Separate read and write models for performance and scalability
```
Commands (Write): Create, Update, Delete
Queries (Read): Get, List, Search (optimized for reading)
```

### Decision 2: Event Sourcing (Where Appropriate)
**Use for:** Audit trails, alarm history, user actions
**Don't use for:** Simple CRUD operations

### Decision 3: Microservices vs Modular Monolith
**Start with:** Modular Monolith (easier to develop)
**Migrate to:** Microservices when needed (already structured for it)

### Decision 4: Database per Bounded Context
**Why:** Each context has its own database/schema
**Benefit:** Independent deployment, scaling, and evolution

---

## 📚 This Architecture Guarantees:

✅ **Testability:** Every layer can be tested independently  
✅ **Maintainability:** Business logic isolated from infrastructure  
✅ **Scalability:** Can scale individual contexts  
✅ **Flexibility:** Can swap implementations without touching domain  
✅ **Cross-Platform:** .NET 8, Avalonia, Rust all supported  
✅ **Long-Term Stability:** Based on proven patterns used by industry leaders  

---

**This is your foundation. Every BahyWay project follows this. Never rebuild, only extend.**

Next: I'll create the concrete implementation code for each layer.
