# KGEditorWay - Knowledge Graph Editor & Visual Process Designer

## 🎯 Vision

**KGEditorWay** is a cross-platform visual editor for:
1. **Process Design** - ETL pipelines, workflows, automation (like n8n, Apache NiFi)
2. **Knowledge Graph Visualization** - Apache AGE graph database editing and visualization

**One tool, dual purpose, shared across all BahyWay projects.**

---

## 📦 Complete Project Structure

```
BahyWay.KGEditorWay/
│
├── src/
│   ├── 1. Core/
│   │   ├── BahyWay.KGEditorWay.SharedKernel/
│   │   │   └── (Uses BahyWay.SharedKernel)
│   │
│   ├── 2. Graph Domain/
│   │   ├── BahyWay.KGEditorWay.Domain/
│   │   │   ├── Aggregates/
│   │   │   │   ├── Graph/
│   │   │   │   │   ├── Graph.cs                    # The graph aggregate
│   │   │   │   │   ├── GraphId.cs
│   │   │   │   │   └── GraphType.cs                # Process vs Knowledge
│   │   │   │   ├── Node/
│   │   │   │   │   ├── Node.cs                     # Node entity
│   │   │   │   │   ├── NodeId.cs
│   │   │   │   │   ├── NodeType.cs                 # Source, Transform, etc.
│   │   │   │   │   └── NodeTemplate.cs             # Reusable node templates
│   │   │   │   ├── Edge/
│   │   │   │   │   ├── Edge.cs                     # Connection/relationship
│   │   │   │   │   ├── EdgeId.cs
│   │   │   │   │   └── EdgeType.cs                 # Data flow vs relationship
│   │   │   │   └── Port/
│   │   │   │       ├── Port.cs
│   │   │   │       └── PortDataType.cs
│   │   │   ├── ValueObjects/
│   │   │   │   ├── Position.cs                     # X, Y coordinates
│   │   │   │   ├── Size.cs                         # Width, height
│   │   │   │   ├── Color.cs                        # Node colors
│   │   │   │   ├── BezierPath.cs                   # Connection curves
│   │   │   │   └── ViewportBounds.cs               # Visible area
│   │   │   ├── DomainServices/
│   │   │   │   ├── IGraphLayoutService.cs          # Auto-layout algorithms
│   │   │   │   ├── IGraphValidationService.cs      # Cycle detection, etc.
│   │   │   │   └── IGraphExecutionService.cs       # Process execution
│   │   │   ├── Events/
│   │   │   │   ├── GraphCreatedEvent.cs
│   │   │   │   ├── NodeAddedEvent.cs
│   │   │   │   ├── EdgeCreatedEvent.cs
│   │   │   │   ├── NodeMovedEvent.cs
│   │   │   │   └── GraphExecutedEvent.cs
│   │   │   ├── Repositories/
│   │   │   │   ├── IGraphRepository.cs
│   │   │   │   ├── INodeTemplateRepository.cs
│   │   │   │   └── IKnowledgeGraphRepository.cs    # AGE integration
│   │   │   └── Specifications/
│   │   │       ├── GraphsByTypeSpecification.cs
│   │   │       └── NodesInViewportSpecification.cs
│   │   │
│   │   ├── BahyWay.KGEditorWay.Application/
│   │   │   ├── Commands/
│   │   │   │   ├── CreateGraph/
│   │   │   │   │   ├── CreateGraphCommand.cs
│   │   │   │   │   ├── CreateGraphCommandHandler.cs
│   │   │   │   │   └── CreateGraphCommandValidator.cs
│   │   │   │   ├── AddNode/
│   │   │   │   │   ├── AddNodeCommand.cs
│   │   │   │   │   └── AddNodeCommandHandler.cs
│   │   │   │   ├── CreateEdge/
│   │   │   │   │   ├── CreateEdgeCommand.cs
│   │   │   │   │   └── CreateEdgeCommandHandler.cs
│   │   │   │   ├── MoveNode/
│   │   │   │   │   ├── MoveNodeCommand.cs
│   │   │   │   │   └── MoveNodeCommandHandler.cs
│   │   │   │   ├── DeleteNode/
│   │   │   │   ├── UpdateNodeProperties/
│   │   │   │   ├── ExecuteGraph/
│   │   │   │   │   ├── ExecuteGraphCommand.cs
│   │   │   │   │   └── ExecuteGraphCommandHandler.cs
│   │   │   │   └── ExportGraph/
│   │   │   ├── Queries/
│   │   │   │   ├── GetGraph/
│   │   │   │   │   ├── GetGraphQuery.cs
│   │   │   │   │   ├── GetGraphQueryHandler.cs
│   │   │   │   │   └── GraphDto.cs
│   │   │   │   ├── GetAllGraphs/
│   │   │   │   ├── GetNodeTemplates/
│   │   │   │   ├── QueryKnowledgeGraph/
│   │   │   │   │   ├── QueryKnowledgeGraphQuery.cs  # Cypher queries
│   │   │   │   │   └── QueryKnowledgeGraphHandler.cs
│   │   │   │   └── GetGraphExecutionHistory/
│   │   │   ├── DTOs/
│   │   │   │   ├── GraphDto.cs
│   │   │   │   ├── NodeDto.cs
│   │   │   │   ├── EdgeDto.cs
│   │   │   │   ├── PortDto.cs
│   │   │   │   └── KnowledgeGraphResultDto.cs
│   │   │   ├── Services/
│   │   │   │   ├── IGraphExportService.cs          # Export to JSON, PNG, etc.
│   │   │   │   ├── IGraphImportService.cs          # Import from various formats
│   │   │   │   └── IGraphExecutionEngine.cs        # Execute process graphs
│   │   │   └── Mappings/
│   │   │       └── GraphMappingProfile.cs
│   │   │
│   │   ├── BahyWay.KGEditorWay.Infrastructure/
│   │   │   ├── Persistence/
│   │   │   │   ├── KGEditorDbContext.cs
│   │   │   │   ├── Configurations/
│   │   │   │   │   ├── GraphConfiguration.cs
│   │   │   │   │   ├── NodeConfiguration.cs
│   │   │   │   │   └── EdgeConfiguration.cs
│   │   │   │   ├── Repositories/
│   │   │   │   │   ├── GraphRepository.cs
│   │   │   │   │   ├── NodeTemplateRepository.cs
│   │   │   │   │   └── KnowledgeGraphRepository.cs  # Apache AGE
│   │   │   │   └── Migrations/
│   │   │   ├── AGE/
│   │   │   │   ├── AgeGraphClient.cs                # Apache AGE client
│   │   │   │   ├── CypherQueryBuilder.cs            # Build Cypher queries
│   │   │   │   └── GraphToAgeConverter.cs           # Convert domain to AGE
│   │   │   ├── Execution/
│   │   │   │   ├── GraphExecutionEngine.cs          # Execute process graphs
│   │   │   │   ├── NodeExecutors/
│   │   │   │   │   ├── INodeExecutor.cs
│   │   │   │   │   ├── SourceNodeExecutor.cs
│   │   │   │   │   ├── TransformNodeExecutor.cs
│   │   │   │   │   └── SinkNodeExecutor.cs
│   │   │   │   └── ExecutionContext.cs
│   │   │   ├── Export/
│   │   │   │   ├── JsonGraphExporter.cs
│   │   │   │   ├── PngGraphExporter.cs              # Render to image
│   │   │   │   └── CypherExporter.cs                # Export as Cypher
│   │   │   ├── Import/
│   │   │   │   ├── JsonGraphImporter.cs
│   │   │   │   ├── DtsxImporter.cs                  # SSIS packages
│   │   │   │   └── NiFiTemplateImporter.cs
│   │   │   └── Layout/
│   │   │       ├── GraphLayoutService.cs
│   │   │       ├── ForceDirectedLayout.cs           # Physics-based
│   │   │       ├── HierarchicalLayout.cs            # Top-down
│   │   │       └── CircularLayout.cs
│   │   │
│   │   ├── BahyWay.KGEditorWay.API/
│   │   │   ├── Controllers/
│   │   │   │   ├── GraphsController.cs
│   │   │   │   ├── NodesController.cs
│   │   │   │   ├── EdgesController.cs
│   │   │   │   ├── TemplatesController.cs
│   │   │   │   ├── ExecutionController.cs
│   │   │   │   └── KnowledgeGraphController.cs
│   │   │   ├── Hubs/                                # SignalR for real-time
│   │   │   │   └── GraphCollaborationHub.cs
│   │   │   ├── Program.cs
│   │   │   └── appsettings.json
│   │   │
│   │   └── BahyWay.KGEditorWay.Desktop/             # Avalonia App
│   │       ├── ViewModels/
│   │       │   ├── MainViewModel.cs
│   │       │   ├── GraphCanvasViewModel.cs
│   │       │   ├── NodeViewModel.cs
│   │       │   ├── EdgeViewModel.cs
│   │       │   ├── PortViewModel.cs
│   │       │   ├── ToolboxViewModel.cs
│   │       │   ├── PropertiesPanelViewModel.cs
│   │       │   └── MinimapViewModel.cs
│   │       ├── Views/
│   │       │   ├── MainWindow.axaml
│   │       │   ├── GraphCanvasView.axaml
│   │       │   ├── Controls/
│   │       │   │   ├── NodeView.axaml
│   │       │   │   ├── EdgeView.axaml
│   │       │   │   ├── PortView.axaml
│   │       │   │   ├── ToolboxView.axaml
│   │       │   │   ├── PropertiesPanelView.axaml
│   │       │   │   └── MinimapView.axaml
│   │       │   └── Dialogs/
│   │       │       ├── NewGraphDialog.axaml
│   │       │       └── ExecutionResultDialog.axaml
│   │       ├── Behaviors/
│   │       │   ├── CanvasPanBehavior.cs
│   │       │   ├── CanvasZoomBehavior.cs
│   │       │   ├── NodeDragBehavior.cs
│   │       │   └── EdgeDrawingBehavior.cs
│   │       ├── Converters/
│   │       │   ├── NodeTypeToColorConverter.cs
│   │       │   ├── PositionToCenterConverter.cs
│   │       │   └── BezierPathConverter.cs
│   │       ├── Services/
│   │       │   ├── IGraphApiClient.cs
│   │       │   ├── GraphApiClient.cs
│   │       │   └── ClipboardService.cs
│   │       ├── Assets/
│   │       │   ├── Icons/
│   │       │   └── NodeTemplates/
│   │       ├── App.axaml
│   │       └── Program.cs
│   │
│   └── 3. Integration Modules/
│       ├── BahyWay.KGEditorWay.ETLway/               # ETLway integration
│       │   ├── ETLNodeTemplates.cs
│       │   ├── ETLGraphExecutor.cs
│       │   └── DtsxImporter.cs
│       ├── BahyWay.KGEditorWay.AlarmInsight/         # AlarmInsight integration
│       │   ├── AlarmRuleNodeTemplates.cs
│       │   └── AlarmRuleExecutor.cs
│       ├── BahyWay.KGEditorWay.SteerView/            # SteerView integration
│       │   ├── GeoNodeTemplates.cs
│       │   └── GeoProcessingExecutor.cs
│       └── BahyWay.KGEditorWay.SSISight/             # SSISight integration
│           ├── SSISVisualizationService.cs
│           └── SSISPackageToGraphConverter.cs
│
└── tests/
    ├── BahyWay.KGEditorWay.Domain.Tests/
    ├── BahyWay.KGEditorWay.Application.Tests/
    ├── BahyWay.KGEditorWay.Infrastructure.Tests/
    └── BahyWay.KGEditorWay.Desktop.Tests/
```

---

## 🎯 **Two Primary Use Cases**

### Use Case 1: Visual Process Designer (ETLway)

```csharp
// Create an ETL process graph
var etlGraph = Graph.Create("Sales Data Pipeline", GraphType.Process);

// Add nodes
var csvSource = etlGraph.AddNode("Load Sales CSV", NodeType.Source, Position.Create(100, 100));
csvSource.Value.SetProperty("file_path", "/data/sales.csv");
csvSource.Value.SetProperty("delimiter", ",");

var cleanTransform = etlGraph.AddNode("Clean Data", NodeType.Transform, Position.Create(350, 100));
cleanTransform.Value.SetProperty("operation", "remove_duplicates");
cleanTransform.Value.SetProperty("trim_whitespace", true);

var dbSink = etlGraph.AddNode("Save to PostgreSQL", NodeType.Sink, Position.Create(600, 100));
dbSink.Value.SetProperty("connection_string", "Host=localhost;Database=sales");
dbSink.Value.SetProperty("table_name", "sales_clean");

// Connect nodes
etlGraph.CreateEdge(csvSource.Value.Id, "output", cleanTransform.Value.Id, "input", EdgeType.DataFlow);
etlGraph.CreateEdge(cleanTransform.Value.Id, "output", dbSink.Value.Id, "input", EdgeType.DataFlow);

// Validate graph
var validation = etlGraph.Validate();

// Execute
var executionResult = await _executionEngine.ExecuteAsync(etlGraph);
```

### Use Case 2: Knowledge Graph Visualization (Apache AGE)

```csharp
// Create a knowledge graph
var knowledgeGraph = Graph.Create("Company Org Chart", GraphType.Knowledge);

// Add entity nodes
var ceo = knowledgeGraph.AddNode("John Doe", NodeType.Entity, Position.Create(400, 50));
ceo.Value.SetProperty("entity_type", "Person");
ceo.Value.SetProperty("title", "CEO");

var cto = knowledgeGraph.AddNode("Jane Smith", NodeType.Entity, Position.Create(200, 200));
cto.Value.SetProperty("entity_type", "Person");
cto.Value.SetProperty("title", "CTO");

var cfo = knowledgeGraph.AddNode("Bob Johnson", NodeType.Entity, Position.Create(600, 200));
cfo.Value.SetProperty("entity_type", "Person");
cfo.Value.SetProperty("title", "CFO");

// Add relationships
knowledgeGraph.CreateEdge(ceo.Id, null, cto.Id, null, EdgeType.Relationship);
knowledgeGraph.GetEdge(edgeId).SetProperty("relationship_type", "manages");

knowledgeGraph.CreateEdge(ceo.Id, null, cfo.Id, null, EdgeType.Relationship);
knowledgeGraph.GetEdge(edgeId).SetProperty("relationship_type", "manages");

// Sync to Apache AGE
await _ageRepository.SyncGraphAsync(knowledgeGraph);

// Query using Cypher
var cypherQuery = "MATCH (p:Person)-[:manages]->(subordinate) WHERE p.title = 'CEO' RETURN subordinate";
var results = await _ageRepository.QueryAsync(cypherQuery);
```

---

## 🏗️ **Domain Model**

### Graph Aggregate Root

```csharp
// Domain/Aggregates/Graph/Graph.cs
using BahyWay.SharedKernel.Domain;
using BahyWay.SharedKernel.Guards;
using BahyWay.SharedKernel.Results;

namespace BahyWay.KGEditorWay.Domain.Aggregates.Graph;

public sealed class Graph : AggregateRoot<GraphId>
{
    public string Name { get; private set; }
    public string? Description { get; private set; }
    public GraphType Type { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public DateTime? LastModifiedAt { get; private set; }
    
    private readonly List<Node> _nodes = new();
    private readonly List<Edge> _edges = new();
    
    public IReadOnlyCollection<Node> Nodes => _nodes.AsReadOnly();
    public IReadOnlyCollection<Edge> Edges => _edges.AsReadOnly();
    
    // Metadata for display
    public ViewportBounds? ViewportBounds { get; private set; }
    public double ZoomLevel { get; private set; } = 1.0;
    
    private Graph() { }
    
    public static Graph Create(string name, GraphType type, string? description = null)
    {
        Guard.Against.NullOrWhiteSpace(name, nameof(name));
        Guard.Against.Null(type, nameof(type));
        
        var graph = new Graph
        {
            Id = GraphId.New(),
            Name = name,
            Type = type,
            Description = description,
            CreatedAt = DateTime.UtcNow,
            ZoomLevel = 1.0
        };
        
        graph.AddDomainEvent(new GraphCreatedEvent(graph.Id, graph.Name, graph.Type));
        
        return graph;
    }
    
    public Result<Node> AddNode(string name, NodeType nodeType, Position position)
    {
        Guard.Against.NullOrWhiteSpace(name, nameof(name));
        Guard.Against.Null(nodeType, nameof(nodeType));
        Guard.Against.Null(position, nameof(position));
        
        var node = Node.Create(name, nodeType, position);
        _nodes.Add(node);
        
        LastModifiedAt = DateTime.UtcNow;
        
        AddDomainEvent(new NodeAddedEvent(Id, node.Id, nodeType));
        
        return Result.Success(node);
    }
    
    public Result RemoveNode(NodeId nodeId)
    {
        var node = _nodes.FirstOrDefault(n => n.Id == nodeId);
        if (node == null)
        {
            return Result.Failure(new Error("Node.NotFound", "Node not found"));
        }
        
        // Remove all edges connected to this node
        var connectedEdges = _edges
            .Where(e => e.SourceNodeId == nodeId || e.TargetNodeId == nodeId)
            .ToList();
        
        foreach (var edge in connectedEdges)
        {
            _edges.Remove(edge);
        }
        
        _nodes.Remove(node);
        LastModifiedAt = DateTime.UtcNow;
        
        AddDomainEvent(new NodeRemovedEvent(Id, nodeId));
        
        return Result.Success();
    }
    
    public Result<Edge> CreateEdge(
        NodeId sourceNodeId,
        string? sourcePortName,
        NodeId targetNodeId,
        string? targetPortName,
        EdgeType edgeType)
    {
        var sourceNode = _nodes.FirstOrDefault(n => n.Id == sourceNodeId);
        var targetNode = _nodes.FirstOrDefault(n => n.Id == targetNodeId);
        
        if (sourceNode == null || targetNode == null)
        {
            return Result.Failure<Edge>(new Error("Node.NotFound", "Source or target node not found"));
        }
        
        // Validate connection based on graph type
        if (Type == GraphType.Process)
        {
            // Process graphs require port names
            if (string.IsNullOrWhiteSpace(sourcePortName) || string.IsNullOrWhiteSpace(targetPortName))
            {
                return Result.Failure<Edge>(new Error("Edge.InvalidPorts", "Port names required for process graphs"));
            }
            
            // Check port compatibility
            if (!sourceNode.CanConnectTo(targetNode, sourcePortName, targetPortName))
            {
                return Result.Failure<Edge>(new Error("Edge.IncompatiblePorts", "Ports are not compatible"));
            }
            
            // Check for existing connection to input port (only one allowed)
            var existingEdge = _edges.FirstOrDefault(e =>
                e.TargetNodeId == targetNodeId &&
                e.TargetPortName == targetPortName);
            
            if (existingEdge != null)
            {
                _edges.Remove(existingEdge);
            }
        }
        
        // Prevent self-loops
        if (sourceNodeId == targetNodeId)
        {
            return Result.Failure<Edge>(new Error("Edge.SelfLoop", "Cannot create edge to same node"));
        }
        
        // Check for cycles (if needed)
        if (Type == GraphType.Process && WouldCreateCycle(sourceNodeId, targetNodeId))
        {
            return Result.Failure<Edge>(new Error("Edge.CreatesCycle", "This connection would create a cycle"));
        }
        
        var edge = Edge.Create(sourceNodeId, sourcePortName, targetNodeId, targetPortName, edgeType);
        _edges.Add(edge);
        
        LastModifiedAt = DateTime.UtcNow;
        
        AddDomainEvent(new EdgeCreatedEvent(Id, edge.Id, sourceNodeId, targetNodeId, edgeType));
        
        return Result.Success(edge);
    }
    
    public Result RemoveEdge(EdgeId edgeId)
    {
        var edge = _edges.FirstOrDefault(e => e.Id == edgeId);
        if (edge == null)
        {
            return Result.Failure(new Error("Edge.NotFound", "Edge not found"));
        }
        
        _edges.Remove(edge);
        LastModifiedAt = DateTime.UtcNow;
        
        AddDomainEvent(new EdgeRemovedEvent(Id, edgeId));
        
        return Result.Success();
    }
    
    public Node? GetNode(NodeId nodeId)
    {
        return _nodes.FirstOrDefault(n => n.Id == nodeId);
    }
    
    public Edge? GetEdge(EdgeId edgeId)
    {
        return _edges.FirstOrDefault(e => e.Id == edgeId);
    }
    
    public Result Validate()
    {
        if (Type == GraphType.Process)
        {
            return ValidateProcessGraph();
        }
        else
        {
            return ValidateKnowledgeGraph();
        }
    }
    
    private Result ValidateProcessGraph()
    {
        // Check for cycles
        if (HasCycles())
        {
            return Result.Failure(new Error("Graph.HasCycles", "Process graph contains cycles"));
        }
        
        // Check for disconnected nodes (warning only)
        var disconnectedNodes = _nodes
            .Where(n => !_edges.Any(e => e.SourceNodeId == n.Id || e.TargetNodeId == n.Id))
            .ToList();
        
        // Check that source nodes have no inputs
        var sourceNodes = _nodes.Where(n => n.Type == NodeType.Source);
        foreach (var source in sourceNodes)
        {
            if (_edges.Any(e => e.TargetNodeId == source.Id))
            {
                return Result.Failure(new Error("Graph.InvalidSource", "Source nodes cannot have inputs"));
            }
        }
        
        // Check that sink nodes have no outputs
        var sinkNodes = _nodes.Where(n => n.Type == NodeType.Sink);
        foreach (var sink in sinkNodes)
        {
            if (_edges.Any(e => e.SourceNodeId == sink.Id))
            {
                return Result.Failure(new Error("Graph.InvalidSink", "Sink nodes cannot have outputs"));
            }
        }
        
        return Result.Success();
    }
    
    private Result ValidateKnowledgeGraph()
    {
        // Knowledge graphs can have cycles
        // Validate entity types and relationship types if needed
        
        return Result.Success();
    }
    
    public List<Node> GetTopologicalOrder()
    {
        if (Type != GraphType.Process)
        {
            throw new InvalidOperationException("Topological sort only applies to process graphs");
        }
        
        var result = new List<Node>();
        var visited = new HashSet<NodeId>();
        var stack = new Stack<Node>();
        
        foreach (var node in _nodes)
        {
            if (!visited.Contains(node.Id))
            {
                TopologicalSortUtil(node, visited, stack);
            }
        }
        
        while (stack.Count > 0)
        {
            result.Add(stack.Pop());
        }
        
        return result;
    }
    
    private void TopologicalSortUtil(Node node, HashSet<NodeId> visited, Stack<Node> stack)
    {
        visited.Add(node.Id);
        
        var outgoingEdges = _edges.Where(e => e.SourceNodeId == node.Id);
        foreach (var edge in outgoingEdges)
        {
            var targetNode = _nodes.First(n => n.Id == edge.TargetNodeId);
            if (!visited.Contains(targetNode.Id))
            {
                TopologicalSortUtil(targetNode, visited, stack);
            }
        }
        
        stack.Push(node);
    }
    
    private bool HasCycles()
    {
        var visited = new HashSet<NodeId>();
        var recursionStack = new HashSet<NodeId>();
        
        foreach (var node in _nodes)
        {
            if (HasCyclesUtil(node.Id, visited, recursionStack))
            {
                return true;
            }
        }
        
        return false;
    }
    
    private bool HasCyclesUtil(NodeId nodeId, HashSet<NodeId> visited, HashSet<NodeId> recursionStack)
    {
        if (recursionStack.Contains(nodeId))
            return true;
        
        if (visited.Contains(nodeId))
            return false;
        
        visited.Add(nodeId);
        recursionStack.Add(nodeId);
        
        var outgoingEdges = _edges.Where(e => e.SourceNodeId == nodeId);
        foreach (var edge in outgoingEdges)
        {
            if (HasCyclesUtil(edge.TargetNodeId, visited, recursionStack))
                return true;
        }
        
        recursionStack.Remove(nodeId);
        return false;
    }
    
    private bool WouldCreateCycle(NodeId sourceNodeId, NodeId targetNodeId)
    {
        // Check if there's already a path from target to source
        return CanReach(targetNodeId, sourceNodeId);
    }
    
    private bool CanReach(NodeId fromId, NodeId toId)
    {
        if (fromId == toId)
            return true;
        
        var visited = new HashSet<NodeId>();
        var queue = new Queue<NodeId>();
        queue.Enqueue(fromId);
        visited.Add(fromId);
        
        while (queue.Count > 0)
        {
            var current = queue.Dequeue();
            
            var outgoingEdges = _edges.Where(e => e.SourceNodeId == current);
            foreach (var edge in outgoingEdges)
            {
                if (edge.TargetNodeId == toId)
                    return true;
                
                if (!visited.Contains(edge.TargetNodeId))
                {
                    visited.Add(edge.TargetNodeId);
                    queue.Enqueue(edge.TargetNodeId);
                }
            }
        }
        
        return false;
    }
    
    public void UpdateViewport(ViewportBounds bounds)
    {
        ViewportBounds = bounds;
    }
    
    public void UpdateZoom(double zoomLevel)
    {
        Guard.Against.OutOfRange(zoomLevel, 0.1, 5.0, nameof(zoomLevel));
        ZoomLevel = zoomLevel;
    }
    
    public List<Node> GetNodesInViewport(ViewportBounds viewport)
    {
        return _nodes.Where(n => viewport.Contains(n.Position)).ToList();
    }
}
```

---

## 🎯 **Graph Types**

```csharp
// Domain/Aggregates/Graph/GraphType.cs
public sealed class GraphType : Enumeration
{
    public static readonly GraphType Process = new(1, nameof(Process), "🔄", "Process/Workflow");
    public static readonly GraphType Knowledge = new(2, nameof(Knowledge), "🧠", "Knowledge Graph");
    public static readonly GraphType Hybrid = new(3, nameof(Hybrid), "🔀", "Hybrid (Process + Knowledge)");
    
    public string Icon { get; }
    public string DisplayName { get; }
    
    private GraphType(int value, string name, string icon, string displayName) 
        : base(value, name)
    {
        Icon = icon;
        DisplayName = displayName;
    }
}
```

---

## 🚀 **Integration with BahyWay Projects**

### ETLway Integration

```csharp
// BahyWay.KGEditorWay.ETLway/ETLNodeTemplates.cs
public static class ETLNodeTemplates
{
    public static NodeTemplate CsvSourceTemplate => new()
    {
        Name = "CSV Source",
        Type = NodeType.Source,
        Icon = "📄",
        Color = "#4CAF50",
        OutputPorts = new[] { "output" },
        Properties = new[]
        {
            new NodePropertyDefinition("file_path", PropertyType.FilePath, required: true),
            new NodePropertyDefinition("delimiter", PropertyType.String, defaultValue: ","),
            new NodePropertyDefinition("has_header", PropertyType.Boolean, defaultValue: true),
            new NodePropertyDefinition("encoding", PropertyType.String, defaultValue: "UTF-8")
        }
    };
    
    public static NodeTemplate PostgreSqlSinkTemplate => new()
    {
        Name = "PostgreSQL Sink",
        Type = NodeType.Sink,
        Icon = "🐘",
        Color = "#336791",
        InputPorts = new[] { "input" },
        Properties = new[]
        {
            new NodePropertyDefinition("connection_string", PropertyType.ConnectionString, required: true),
            new NodePropertyDefinition("table_name", PropertyType.String, required: true),
            new NodePropertyDefinition("insert_mode", PropertyType.Choice, 
                choices: new[] { "Insert", "Upsert", "Truncate+Insert" })
        }
    };
    
    public static NodeTemplate TransformTemplate => new()
    {
        Name = "Transform",
        Type = NodeType.Transform,
        Icon = "⚙️",
        Color = "#2196F3",
        InputPorts = new[] { "input" },
        OutputPorts = new[] { "output" },
        Properties = new[]
        {
            new NodePropertyDefinition("operation", PropertyType.Choice,
                choices: new[] { "Filter", "Map", "Aggregate", "Join", "Sort" }),
            new NodePropertyDefinition("expression", PropertyType.Code, language: "javascript")
        }
    };
}
```

---

**This is the foundation! Want me to continue with:**
1. **Avalonia UI implementation** (canvas, drag-drop, drawing)
2. **Apache AGE integration** (knowledge graph sync)
3. **Graph execution engine** (run processes)
4. **Node template system** (reusable components)

Just say the word! 🚀
