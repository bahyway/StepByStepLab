# 🎮 SimulateWay.Unity - 3D Interactive Workflow Simulator

## 🎯 YES! Unity is PERFECT for Workflow Simulation!

Unity offers **major advantages** over 2D GIF animations:

### **Why Unity?**

#### **2D Animation (SimulateWay Classic)** 📹
- ✅ Great for: Documentation, presentations, social media
- ✅ Output: Static GIF/MP4 videos
- ❌ Limitation: Non-interactive, fixed viewpoint
- ❌ Limitation: 2D only

#### **Unity 3D Simulator (SimulateWay.Unity)** 🎮
- ✅ **Interactive**: Click, drag, rotate, zoom
- ✅ **Real-time**: See live data flow
- ✅ **3D Visualization**: See workflows from any angle
- ✅ **Physics-based**: Realistic particle systems
- ✅ **VR/AR Ready**: Immersive experiences
- ✅ **Multiplayer**: Collaborative exploration
- ✅ **Training Mode**: Interactive tutorials

---

## 🏗️ Architecture: Unity Integration

```
┌────────────────────────────────────────────────────┐
│              BahyWay Platform                       │
└────────────┬──────────────────────────────────────┘
             │
       ┌─────┴─────┬──────────────┬──────────────┐
       │           │              │              │
   KGEditorWay  SimulateWay   SimulateWay    Apache
   (Designer)   (2D Export)   (Unity 3D)      AGE
       │           │              │              │
       │           │              │              │
   Edit Graph  Export GIF    Interactive     Knowledge
   Visually    Animation     3D Simulator     Graphs
       │           │              │              │
       └───────────┴──────────────┴──────────────┘
                        │
              ┌─────────┴──────────┐
              │                    │
          Desktop App          WebGL Build
          (Standalone)         (Browser)
```

---

## 📦 Project Structure

```
BahyWay.SimulateWay.Unity/
├── Assets/
│   ├── Scripts/
│   │   ├── Core/
│   │   │   ├── GraphLoader.cs              # Load from KGEditorWay
│   │   │   ├── SimulationEngine.cs         # Main simulation logic
│   │   │   ├── TimelineController.cs       # Control playback
│   │   │   └── EventSystem.cs              # Unity event handling
│   │   ├── Visualization/
│   │   │   ├── NodeRenderer.cs             # 3D node visualization
│   │   │   ├── EdgeRenderer.cs             # 3D edge/connection
│   │   │   ├── DataFlowParticles.cs        # Particle systems
│   │   │   ├── HighlightEffect.cs          # Glow/outline effects
│   │   │   └── CameraController.cs         # Orbit, zoom, pan
│   │   ├── Interaction/
│   │   │   ├── NodeClickHandler.cs         # Click detection
│   │   │   ├── TooltipManager.cs           # Hover tooltips
│   │   │   ├── DetailsPanel.cs             # Selected node info
│   │   │   └── PlaybackControls.cs         # UI controls
│   │   ├── Effects/
│   │   │   ├── HighlightController.cs      # Node highlighting
│   │   │   ├── ParticleFlowController.cs   # Data flow particles
│   │   │   ├── AnimationController.cs      # Smooth transitions
│   │   │   └── AudioController.cs          # Sound effects
│   │   ├── Integration/
│   │   │   ├── BahyWayClient.cs            # REST API client
│   │   │   ├── GraphImporter.cs            # JSON graph import
│   │   │   ├── AnimationImporter.cs        # Import animation data
│   │   │   └── LiveDataConnector.cs        # Real-time data
│   │   └── UI/
│   │       ├── MainMenuUI.cs               # Main menu
│   │       ├── TimelineUI.cs               # Timeline controls
│   │       ├── SettingsUI.cs               # Settings panel
│   │       └── HelpUI.cs                   # Help overlay
│   ├── Prefabs/
│   │   ├── Node_Database.prefab            # Database node 3D model
│   │   ├── Node_Process.prefab             # Process node 3D model
│   │   ├── Node_Service.prefab             # Service node 3D model
│   │   ├── Edge_DataFlow.prefab            # Data flow connection
│   │   ├── Particle_Data.prefab            # Data packet particle
│   │   └── UI_Canvas.prefab                # Main UI canvas
│   ├── Materials/
│   │   ├── Node_Default.mat                # Default node material
│   │   ├── Node_Highlight.mat              # Highlighted state
│   │   ├── Edge_Default.mat                # Edge material
│   │   └── Particle_Data.mat               # Particle material
│   ├── Scenes/
│   │   ├── MainMenu.unity                  # Entry point
│   │   ├── WorkflowSimulator.unity         # Main simulation
│   │   └── VRWorkflowSimulator.unity       # VR version
│   └── Resources/
│       ├── Graphs/                         # Sample graphs
│       ├── Audio/                          # Sound effects
│       └── Textures/                       # UI textures
├── Packages/
│   ├── manifest.json                       # Unity package manager
│   └── packages-lock.json
└── ProjectSettings/
    └── (Unity project settings)
```

---

## 🎮 Core Unity Components

### 1. Graph Loader

```csharp
// Assets/Scripts/Core/GraphLoader.cs
using UnityEngine;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace BahyWay.SimulateWay.Unity.Core
{
    public class GraphLoader : MonoBehaviour
    {
        [Header("Import Settings")]
        public string graphFilePath = "Assets/Resources/Graphs/workflow.json";
        
        public async Task<GraphData> LoadGraphAsync(string path)
        {
            // Load JSON from file or API
            string json = await LoadJsonAsync(path);
            
            // Deserialize to graph data
            var graphData = JsonConvert.DeserializeObject<GraphData>(json);
            
            Debug.Log($"Loaded graph: {graphData.Name} with {graphData.Nodes.Count} nodes");
            
            return graphData;
        }
        
        private async Task<string> LoadJsonAsync(string path)
        {
            // Load from Resources or web API
            if (path.StartsWith("http"))
            {
                using (UnityWebRequest www = UnityWebRequest.Get(path))
                {
                    await www.SendWebRequest();
                    
                    if (www.result != UnityWebRequest.Result.Success)
                    {
                        Debug.LogError($"Failed to load graph: {www.error}");
                        return null;
                    }
                    
                    return www.downloadHandler.text;
                }
            }
            else
            {
                // Load from Resources folder
                TextAsset textAsset = Resources.Load<TextAsset>(path);
                return textAsset.text;
            }
        }
    }
    
    [System.Serializable]
    public class GraphData
    {
        public string Id;
        public string Name;
        public string Type;
        public List<NodeData> Nodes = new();
        public List<EdgeData> Edges = new();
    }
    
    [System.Serializable]
    public class NodeData
    {
        public string Id;
        public string Name;
        public string Type;
        public Vector2 Position;
        public Dictionary<string, object> Properties = new();
    }
    
    [System.Serializable]
    public class EdgeData
    {
        public string Id;
        public string SourceNodeId;
        public string TargetNodeId;
        public string Type;
    }
}
```

### 2. Node Renderer (3D)

```csharp
// Assets/Scripts/Visualization/NodeRenderer.cs
using UnityEngine;
using TMPro;

namespace BahyWay.SimulateWay.Unity.Visualization
{
    public class NodeRenderer : MonoBehaviour
    {
        [Header("Node Data")]
        public string nodeId;
        public string nodeName;
        public string nodeType;
        
        [Header("Visual Components")]
        public MeshRenderer meshRenderer;
        public TextMeshPro labelText;
        public TextMeshPro iconText;
        public ParticleSystem highlightParticles;
        
        [Header("Materials")]
        public Material defaultMaterial;
        public Material highlightMaterial;
        public Material processingMaterial;
        
        [Header("Colors by Type")]
        public Color databaseColor = new Color(0.2f, 0.4f, 0.6f);
        public Color processColor = new Color(0.1f, 0.6f, 0.3f);
        public Color serviceColor = new Color(0.6f, 0.3f, 0.1f);
        
        private bool isHighlighted = false;
        private bool isProcessing = false;
        
        void Start()
        {
            SetupNode();
        }
        
        void SetupNode()
        {
            // Set label
            if (labelText != null)
            {
                labelText.text = nodeName;
            }
            
            // Set icon based on type
            if (iconText != null)
            {
                iconText.text = GetIconForType(nodeType);
            }
            
            // Set color based on type
            SetNodeColor(GetColorForType(nodeType));
        }
        
        public void SetHighlight(bool highlighted)
        {
            isHighlighted = highlighted;
            
            if (highlighted)
            {
                meshRenderer.material = highlightMaterial;
                
                if (highlightParticles != null)
                {
                    highlightParticles.Play();
                }
                
                // Animate scale
                LeanTween.scale(gameObject, Vector3.one * 1.2f, 0.3f)
                    .setEase(LeanTweenType.easeOutBack);
            }
            else
            {
                meshRenderer.material = defaultMaterial;
                
                if (highlightParticles != null)
                {
                    highlightParticles.Stop();
                }
                
                // Return to normal scale
                LeanTween.scale(gameObject, Vector3.one, 0.3f)
                    .setEase(LeanTweenType.easeInBack);
            }
        }
        
        public void SetProcessing(bool processing)
        {
            isProcessing = processing;
            
            if (processing)
            {
                meshRenderer.material = processingMaterial;
                
                // Pulse animation
                LeanTween.value(gameObject, 1f, 1.3f, 0.5f)
                    .setEase(LeanTweenType.easeInOutSine)
                    .setLoopPingPong()
                    .setOnUpdate((float val) =>
                    {
                        transform.localScale = Vector3.one * val;
                    });
            }
            else
            {
                LeanTween.cancel(gameObject);
                transform.localScale = Vector3.one;
                meshRenderer.material = defaultMaterial;
            }
        }
        
        private void SetNodeColor(Color color)
        {
            if (meshRenderer != null)
            {
                meshRenderer.material.color = color;
            }
        }
        
        private Color GetColorForType(string type)
        {
            return type?.ToLower() switch
            {
                "database" => databaseColor,
                "process" => processColor,
                "service" => serviceColor,
                _ => Color.gray
            };
        }
        
        private string GetIconForType(string type)
        {
            return type?.ToLower() switch
            {
                "database" => "🗄️",
                "process" => "⚙️",
                "service" => "🔧",
                "source" => "📄",
                "sink" => "📁",
                _ => "📦"
            };
        }
        
        void OnMouseDown()
        {
            // Handle click
            var detailsPanel = FindObjectOfType<DetailsPanel>();
            if (detailsPanel != null)
            {
                detailsPanel.ShowNodeDetails(this);
            }
        }
        
        void OnMouseEnter()
        {
            // Show tooltip
            var tooltipManager = FindObjectOfType<TooltipManager>();
            if (tooltipManager != null)
            {
                tooltipManager.ShowTooltip(nodeName, transform.position);
            }
        }
        
        void OnMouseExit()
        {
            // Hide tooltip
            var tooltipManager = FindObjectOfType<TooltipManager>();
            if (tooltipManager != null)
            {
                tooltipManager.HideTooltip();
            }
        }
    }
}
```

### 3. Data Flow Particles

```csharp
// Assets/Scripts/Visualization/DataFlowParticles.cs
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace BahyWay.SimulateWay.Unity.Visualization
{
    public class DataFlowParticles : MonoBehaviour
    {
        [Header("Flow Settings")]
        public Transform sourceNode;
        public Transform targetNode;
        public float particleSpeed = 2f;
        public int particleCount = 10;
        public float spawnInterval = 0.2f;
        
        [Header("Particle Prefab")]
        public GameObject particlePrefab;
        
        [Header("Visual Settings")]
        public Color particleColor = Color.cyan;
        public float particleSize = 0.1f;
        public bool useTrail = true;
        
        private List<GameObject> activeParticles = new();
        private bool isFlowing = false;
        
        public void StartFlow()
        {
            if (isFlowing) return;
            
            isFlowing = true;
            StartCoroutine(SpawnParticles());
        }
        
        public void StopFlow()
        {
            isFlowing = false;
            StopAllCoroutines();
            
            // Clear existing particles
            foreach (var particle in activeParticles)
            {
                if (particle != null)
                {
                    Destroy(particle);
                }
            }
            activeParticles.Clear();
        }
        
        private IEnumerator SpawnParticles()
        {
            while (isFlowing)
            {
                SpawnParticle();
                yield return new WaitForSeconds(spawnInterval);
            }
        }
        
        private void SpawnParticle()
        {
            if (sourceNode == null || targetNode == null)
                return;
            
            // Create particle
            GameObject particle = Instantiate(particlePrefab, sourceNode.position, Quaternion.identity);
            particle.transform.localScale = Vector3.one * particleSize;
            
            // Set color
            var renderer = particle.GetComponent<Renderer>();
            if (renderer != null)
            {
                renderer.material.color = particleColor;
            }
            
            // Add trail if enabled
            if (useTrail)
            {
                var trail = particle.AddComponent<TrailRenderer>();
                trail.time = 0.5f;
                trail.startWidth = particleSize;
                trail.endWidth = 0f;
                trail.material = renderer.material;
            }
            
            activeParticles.Add(particle);
            
            // Animate to target
            StartCoroutine(AnimateParticle(particle));
        }
        
        private IEnumerator AnimateParticle(GameObject particle)
        {
            float elapsed = 0f;
            Vector3 startPos = sourceNode.position;
            Vector3 endPos = targetNode.position;
            
            // Calculate curve (arc)
            Vector3 midPoint = (startPos + endPos) / 2f;
            midPoint.y += 1f; // Arc height
            
            float duration = Vector3.Distance(startPos, endPos) / particleSpeed;
            
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                
                // Bezier curve for smooth arc
                Vector3 position = CalculateBezierPoint(t, startPos, midPoint, endPos);
                particle.transform.position = position;
                
                yield return null;
            }
            
            // Arrived at target
            activeParticles.Remove(particle);
            Destroy(particle);
        }
        
        private Vector3 CalculateBezierPoint(float t, Vector3 p0, Vector3 p1, Vector3 p2)
        {
            float u = 1 - t;
            float tt = t * t;
            float uu = u * u;
            
            Vector3 p = uu * p0; // (1-t)^2 * P0
            p += 2 * u * t * p1; // 2(1-t)t * P1
            p += tt * p2;        // t^2 * P2
            
            return p;
        }
    }
}
```

### 4. Simulation Engine

```csharp
// Assets/Scripts/Core/SimulationEngine.cs
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace BahyWay.SimulateWay.Unity.Core
{
    public class SimulationEngine : MonoBehaviour
    {
        [Header("Components")]
        public GraphLoader graphLoader;
        public Transform nodesContainer;
        public Transform edgesContainer;
        
        [Header("Prefabs")]
        public GameObject nodePrefab;
        public GameObject edgePrefab;
        
        [Header("Layout Settings")]
        public float nodeSpacing = 3f;
        public float verticalSpacing = 2f;
        
        [Header("Simulation Settings")]
        public float stepDuration = 2f;
        public bool autoPlay = true;
        
        private GraphData currentGraph;
        private Dictionary<string, NodeRenderer> nodeRenderers = new();
        private Dictionary<string, DataFlowParticles> edgeRenderers = new();
        private List<string> executionOrder = new();
        private int currentStep = 0;
        private bool isPlaying = false;
        
        async void Start()
        {
            await LoadAndVisualizeGraph();
            
            if (autoPlay)
            {
                Play();
            }
        }
        
        public async System.Threading.Tasks.Task LoadAndVisualizeGraph()
        {
            // Load graph data
            currentGraph = await graphLoader.LoadGraphAsync(graphLoader.graphFilePath);
            
            if (currentGraph == null)
            {
                Debug.LogError("Failed to load graph");
                return;
            }
            
            // Create 3D visualization
            CreateNodes();
            CreateEdges();
            CalculateExecutionOrder();
            
            Debug.Log($"Visualization created with {nodeRenderers.Count} nodes");
        }
        
        private void CreateNodes()
        {
            int index = 0;
            foreach (var nodeData in currentGraph.Nodes)
            {
                // Calculate position (simple grid layout)
                Vector3 position = new Vector3(
                    nodeData.Position.x / 100f * nodeSpacing,
                    0f,
                    nodeData.Position.y / 100f * verticalSpacing);
                
                // Instantiate node
                GameObject nodeObj = Instantiate(nodePrefab, position, Quaternion.identity, nodesContainer);
                nodeObj.name = nodeData.Name;
                
                // Setup node renderer
                var renderer = nodeObj.GetComponent<NodeRenderer>();
                if (renderer != null)
                {
                    renderer.nodeId = nodeData.Id;
                    renderer.nodeName = nodeData.Name;
                    renderer.nodeType = nodeData.Type;
                }
                
                nodeRenderers[nodeData.Id] = renderer;
                index++;
            }
        }
        
        private void CreateEdges()
        {
            foreach (var edgeData in currentGraph.Edges)
            {
                if (!nodeRenderers.ContainsKey(edgeData.SourceNodeId) ||
                    !nodeRenderers.ContainsKey(edgeData.TargetNodeId))
                {
                    Debug.LogWarning($"Edge {edgeData.Id} has invalid nodes");
                    continue;
                }
                
                var sourceNode = nodeRenderers[edgeData.SourceNodeId].transform;
                var targetNode = nodeRenderers[edgeData.TargetNodeId].transform;
                
                // Create edge object
                GameObject edgeObj = Instantiate(edgePrefab, edgesContainer);
                edgeObj.name = $"Edge_{edgeData.SourceNodeId}_to_{edgeData.TargetNodeId}";
                
                // Setup data flow
                var dataFlow = edgeObj.GetComponent<DataFlowParticles>();
                if (dataFlow != null)
                {
                    dataFlow.sourceNode = sourceNode;
                    dataFlow.targetNode = targetNode;
                }
                
                // Draw line
                var lineRenderer = edgeObj.GetComponent<LineRenderer>();
                if (lineRenderer != null)
                {
                    lineRenderer.SetPosition(0, sourceNode.position);
                    lineRenderer.SetPosition(1, targetNode.position);
                }
                
                edgeRenderers[edgeData.Id] = dataFlow;
            }
        }
        
        private void CalculateExecutionOrder()
        {
            // Simple topological sort
            executionOrder = currentGraph.Nodes.Select(n => n.Id).ToList();
            Debug.Log($"Execution order: {string.Join(" → ", executionOrder)}");
        }
        
        public void Play()
        {
            if (isPlaying) return;
            
            isPlaying = true;
            StartCoroutine(ExecuteSimulation());
        }
        
        public void Pause()
        {
            isPlaying = false;
            StopAllCoroutines();
        }
        
        public void Reset()
        {
            Pause();
            currentStep = 0;
            
            // Reset all node states
            foreach (var renderer in nodeRenderers.Values)
            {
                renderer.SetHighlight(false);
                renderer.SetProcessing(false);
            }
            
            // Stop all data flows
            foreach (var flow in edgeRenderers.Values)
            {
                flow.StopFlow();
            }
        }
        
        private IEnumerator ExecuteSimulation()
        {
            while (isPlaying && currentStep < executionOrder.Count)
            {
                yield return ExecuteStep(currentStep);
                currentStep++;
                
                yield return new WaitForSeconds(stepDuration);
            }
            
            // Loop or stop
            if (currentStep >= executionOrder.Count)
            {
                currentStep = 0;
                // Optionally loop: yield return ExecuteSimulation();
            }
        }
        
        private IEnumerator ExecuteStep(int step)
        {
            string nodeId = executionOrder[step];
            
            if (!nodeRenderers.ContainsKey(nodeId))
                yield break;
            
            var node = nodeRenderers[nodeId];
            
            // Highlight current node
            node.SetHighlight(true);
            node.SetProcessing(true);
            
            Debug.Log($"Executing: {node.nodeName}");
            
            // Find outgoing edges and start data flow
            var outgoingEdges = currentGraph.Edges
                .Where(e => e.SourceNodeId == nodeId)
                .ToList();
            
            foreach (var edge in outgoingEdges)
            {
                if (edgeRenderers.ContainsKey(edge.Id))
                {
                    edgeRenderers[edge.Id].StartFlow();
                }
            }
            
            yield return new WaitForSeconds(stepDuration * 0.5f);
            
            // Stop processing, keep highlighted
            node.SetProcessing(false);
            
            yield return new WaitForSeconds(stepDuration * 0.5f);
            
            // Unhighlight
            node.SetHighlight(false);
            
            // Stop data flows
            foreach (var edge in outgoingEdges)
            {
                if (edgeRenderers.ContainsKey(edge.Id))
                {
                    edgeRenderers[edge.Id].StopFlow();
                }
            }
        }
    }
}
```

---

**Continue to Part 2: UI, VR Support, and WebGL Export?**
