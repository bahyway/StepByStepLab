# BahyWay AlarmManagement - Complete Bounded Context Implementation

This is a **complete, production-ready** example of a bounded context following Clean Architecture + DDD.

Use this as your **template** for all other BahyWay projects.

---

## 📦 Project Structure

```
BahyWay.AlarmManagement/
│
├── src/
│   ├── BahyWay.AlarmManagement.Domain/
│   │   ├── Aggregates/
│   │   │   ├── Alarm/
│   │   │   │   ├── Alarm.cs                    # Aggregate Root
│   │   │   │   ├── AlarmId.cs                  # Strongly-typed ID
│   │   │   │   ├── AlarmSeverity.cs            # Enumeration
│   │   │   │   ├── AlarmStatus.cs              # Enumeration
│   │   │   │   └── AlarmConfiguration.cs       # Entity
│   │   │   └── Asset/
│   │   │       ├── Asset.cs                    # Aggregate Root
│   │   │       ├── AssetId.cs
│   │   │       └── AssetType.cs                # Enumeration
│   │   ├── ValueObjects/
│   │   │   ├── AlarmValue.cs
│   │   │   ├── ThresholdRange.cs
│   │   │   ├── GeoLocation.cs
│   │   │   └── ContactInfo.cs
│   │   ├── DomainServices/
│   │   │   ├── IAlarmClassificationService.cs
│   │   │   └── AlarmCorrelationService.cs
│   │   ├── Events/
│   │   │   ├── AlarmCreatedEvent.cs
│   │   │   ├── AlarmAcknowledgedEvent.cs
│   │   │   ├── AlarmEscalatedEvent.cs
│   │   │   └── AlarmResolvedEvent.cs
│   │   ├── Repositories/
│   │   │   ├── IAlarmRepository.cs
│   │   │   └── IAssetRepository.cs
│   │   ├── Specifications/
│   │   │   ├── ActiveAlarmsSpecification.cs
│   │   │   ├── CriticalAlarmsSpecification.cs
│   │   │   └── UnacknowledgedAlarmsSpecification.cs
│   │   └── Exceptions/
│   │       ├── AlarmCannotBeAcknowledgedException.cs
│   │       └── InvalidAlarmStateException.cs
│   │
│   ├── BahyWay.AlarmManagement.Application/
│   │   ├── Commands/
│   │   │   ├── CreateAlarm/
│   │   │   │   ├── CreateAlarmCommand.cs
│   │   │   │   ├── CreateAlarmCommandHandler.cs
│   │   │   │   └── CreateAlarmCommandValidator.cs
│   │   │   ├── AcknowledgeAlarm/
│   │   │   │   ├── AcknowledgeAlarmCommand.cs
│   │   │   │   ├── AcknowledgeAlarmCommandHandler.cs
│   │   │   │   └── AcknowledgeAlarmCommandValidator.cs
│   │   │   └── EscalateAlarm/
│   │   ├── Queries/
│   │   │   ├── GetAlarm/
│   │   │   │   ├── GetAlarmQuery.cs
│   │   │   │   ├── GetAlarmQueryHandler.cs
│   │   │   │   └── AlarmDto.cs
│   │   │   ├── GetActiveAlarms/
│   │   │   │   ├── GetActiveAlarmsQuery.cs
│   │   │   │   └── GetActiveAlarmsQueryHandler.cs
│   │   │   └── GetAlarmStatistics/
│   │   ├── DTOs/
│   │   │   ├── AlarmDto.cs
│   │   │   ├── AssetDto.cs
│   │   │   └── AlarmStatisticsDto.cs
│   │   ├── Services/
│   │   │   └── INotificationService.cs
│   │   ├── Behaviors/
│   │   │   ├── ValidationBehavior.cs
│   │   │   └── LoggingBehavior.cs
│   │   └── Mappings/
│   │       └── AlarmMappingProfile.cs
│   │
│   ├── BahyWay.AlarmManagement.Infrastructure/
│   │   ├── Persistence/
│   │   │   ├── AlarmManagementDbContext.cs
│   │   │   ├── Configurations/
│   │   │   │   ├── AlarmConfiguration.cs
│   │   │   │   └── AssetConfiguration.cs
│   │   │   ├── Repositories/
│   │   │   │   ├── AlarmRepository.cs
│   │   │   │   └── AssetRepository.cs
│   │   │   └── Migrations/
│   │   ├── ExternalServices/
│   │   │   ├── RulesEngineService.cs
│   │   │   ├── NotificationService.cs
│   │   │   └── MLPredictionService.cs
│   │   ├── EventHandlers/
│   │   │   ├── AlarmCreatedEventHandler.cs
│   │   │   └── AlarmEscalatedEventHandler.cs
│   │   └── DependencyInjection.cs
│   │
│   ├── BahyWay.AlarmManagement.API/
│   │   ├── Controllers/
│   │   │   ├── AlarmsController.cs
│   │   │   └── AssetsController.cs
│   │   ├── Middleware/
│   │   │   ├── ExceptionHandlingMiddleware.cs
│   │   │   └── RequestLoggingMiddleware.cs
│   │   ├── Program.cs
│   │   ├── appsettings.json
│   │   └── Dockerfile
│   │
│   └── BahyWay.AlarmManagement.Desktop/
│       ├── ViewModels/
│       │   ├── MainViewModel.cs
│       │   ├── AlarmListViewModel.cs
│       │   └── AlarmDetailViewModel.cs
│       ├── Views/
│       │   ├── MainWindow.axaml
│       │   ├── AlarmListView.axaml
│       │   └── AlarmDetailView.axaml
│       ├── Services/
│       │   └── AlarmApiClient.cs
│       ├── App.axaml
│       └── Program.cs
│
└── tests/
    ├── BahyWay.AlarmManagement.Domain.Tests/
    ├── BahyWay.AlarmManagement.Application.Tests/
    ├── BahyWay.AlarmManagement.Infrastructure.Tests/
    └── BahyWay.AlarmManagement.IntegrationTests/
```

---

## 🏗️ DOMAIN LAYER - Complete Implementation

### 1. Strongly-Typed ID

```csharp
// Domain/Aggregates/Alarm/AlarmId.cs
namespace BahyWay.AlarmManagement.Domain.Aggregates.Alarm;

/// <summary>
/// Strongly-typed identifier for Alarm aggregate.
/// Prevents mixing up IDs between different aggregates.
/// </summary>
public sealed record AlarmId
{
    public Guid Value { get; }

    private AlarmId(Guid value)
    {
        if (value == Guid.Empty)
        {
            throw new ArgumentException("Alarm ID cannot be empty", nameof(value));
        }
        Value = value;
    }

    public static AlarmId New() => new(Guid.NewGuid());
    public static AlarmId From(Guid value) => new(value);
    public static AlarmId From(string value) => new(Guid.Parse(value));

    public override string ToString() => Value.ToString();

    // Implicit conversion for convenience
    public static implicit operator Guid(AlarmId alarmId) => alarmId.Value;
}
```

### 2. Enumerations

```csharp
// Domain/Aggregates/Alarm/AlarmSeverity.cs
using BahyWay.SharedKernel.Domain;

namespace BahyWay.AlarmManagement.Domain.Aggregates.Alarm;

/// <summary>
/// Represents the severity level of an alarm.
/// Type-safe enumeration with behavior.
/// </summary>
public sealed class AlarmSeverity : Enumeration
{
    public static readonly AlarmSeverity Info = new(1, nameof(Info), "Informational");
    public static readonly AlarmSeverity Low = new(2, nameof(Low), "Low Priority");
    public static readonly AlarmSeverity Medium = new(3, nameof(Medium), "Medium Priority");
    public static readonly AlarmSeverity High = new(4, nameof(High), "High Priority");
    public static readonly AlarmSeverity Critical = new(5, nameof(Critical), "Critical - Immediate Action Required");

    public string Description { get; }
    public int EscalationThresholdMinutes { get; }

    private AlarmSeverity(int value, string name, string description) 
        : base(value, name)
    {
        Description = description;
        EscalationThresholdMinutes = value switch
        {
            1 => 1440, // 24 hours
            2 => 480,  // 8 hours
            3 => 120,  // 2 hours
            4 => 30,   // 30 minutes
            5 => 5,    // 5 minutes
            _ => 60
        };
    }

    public bool RequiresImmediateAction() => Value >= High.Value;
    
    public AlarmSeverity? GetNextSeverity()
    {
        return Value switch
        {
            1 => Low,
            2 => Medium,
            3 => High,
            4 => Critical,
            _ => null
        };
    }

    public TimeSpan GetEscalationThreshold() => 
        TimeSpan.FromMinutes(EscalationThresholdMinutes);
}

// Domain/Aggregates/Alarm/AlarmStatus.cs
public sealed class AlarmStatus : Enumeration
{
    public static readonly AlarmStatus Active = new(1, nameof(Active));
    public static readonly AlarmStatus Acknowledged = new(2, nameof(Acknowledged));
    public static readonly AlarmStatus InProgress = new(3, nameof(InProgress));
    public static readonly AlarmStatus Resolved = new(4, nameof(Resolved));
    public static readonly AlarmStatus Closed = new(5, nameof(Closed));
    public static readonly AlarmStatus Suppressed = new(6, nameof(Suppressed));

    private AlarmStatus(int value, string name) : base(value, name) { }

    public bool CanBeAcknowledged() => this == Active;
    public bool CanBeResolved() => this == Active || this == Acknowledged || this == InProgress;
    public bool IsFinal() => this == Resolved || this == Closed;
}
```

### 3. Value Objects

```csharp
// Domain/ValueObjects/AlarmValue.cs
using BahyWay.SharedKernel.Domain;
using BahyWay.SharedKernel.Guards;

namespace BahyWay.AlarmManagement.Domain.ValueObjects;

/// <summary>
/// Represents a measured value that triggered an alarm.
/// Immutable value object.
/// </summary>
public sealed class AlarmValue : ValueObject
{
    public double Value { get; }
    public string Unit { get; }
    public DateTime MeasuredAt { get; }

    private AlarmValue(double value, string unit, DateTime measuredAt)
    {
        Value = value;
        Unit = unit;
        MeasuredAt = measuredAt;
    }

    public static AlarmValue Create(double value, string unit, DateTime? measuredAt = null)
    {
        Guard.Against.NullOrWhiteSpace(unit, nameof(unit));
        
        return new AlarmValue(value, unit, measuredAt ?? DateTime.UtcNow);
    }

    public bool ExceedsThreshold(ThresholdRange threshold)
    {
        return Value < threshold.MinValue || Value > threshold.MaxValue;
    }

    public override string ToString() => $"{Value:F2} {Unit}";

    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return Value;
        yield return Unit;
        yield return MeasuredAt;
    }
}

// Domain/ValueObjects/ThresholdRange.cs
public sealed class ThresholdRange : ValueObject
{
    public double MinValue { get; }
    public double MaxValue { get; }
    public string Unit { get; }

    private ThresholdRange(double minValue, double maxValue, string unit)
    {
        if (minValue > maxValue)
        {
            throw new ArgumentException("Min value cannot exceed max value");
        }

        MinValue = minValue;
        MaxValue = maxValue;
        Unit = unit;
    }

    public static ThresholdRange Create(double minValue, double maxValue, string unit)
    {
        Guard.Against.NullOrWhiteSpace(unit, nameof(unit));
        return new ThresholdRange(minValue, maxValue, unit);
    }

    public bool IsWithinRange(double value)
    {
        return value >= MinValue && value <= MaxValue;
    }

    public double GetDistanceFromThreshold(double value)
    {
        if (value < MinValue) return MinValue - value;
        if (value > MaxValue) return value - MaxValue;
        return 0;
    }

    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return MinValue;
        yield return MaxValue;
        yield return Unit;
    }
}

// Domain/ValueObjects/GeoLocation.cs
public sealed class GeoLocation : ValueObject
{
    public double Latitude { get; }
    public double Longitude { get; }
    public double? Altitude { get; }

    private GeoLocation(double latitude, double longitude, double? altitude)
    {
        Guard.Against.OutOfRange(latitude, -90.0, 90.0, nameof(latitude));
        Guard.Against.OutOfRange(longitude, -180.0, 180.0, nameof(longitude));

        Latitude = latitude;
        Longitude = longitude;
        Altitude = altitude;
    }

    public static GeoLocation Create(double latitude, double longitude, double? altitude = null)
    {
        return new GeoLocation(latitude, longitude, altitude);
    }

    public double DistanceTo(GeoLocation other)
    {
        // Haversine formula
        const double R = 6371; // Earth's radius in km

        var lat1Rad = Latitude * Math.PI / 180;
        var lat2Rad = other.Latitude * Math.PI / 180;
        var dLat = (other.Latitude - Latitude) * Math.PI / 180;
        var dLon = (other.Longitude - Longitude) * Math.PI / 180;

        var a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                Math.Cos(lat1Rad) * Math.Cos(lat2Rad) *
                Math.Sin(dLon / 2) * Math.Sin(dLon / 2);

        var c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));

        return R * c; // Distance in kilometers
    }

    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return Latitude;
        yield return Longitude;
        yield return Altitude;
    }
}
```

### 4. Domain Events

```csharp
// Domain/Events/AlarmCreatedEvent.cs
using BahyWay.SharedKernel.Domain;

namespace BahyWay.AlarmManagement.Domain.Events;

public sealed record AlarmCreatedEvent : DomainEvent
{
    public AlarmId AlarmId { get; init; }
    public AssetId AssetId { get; init; }
    public AlarmSeverity Severity { get; init; }
    public AlarmValue Value { get; init; }
    public string Message { get; init; }

    public AlarmCreatedEvent(
        AlarmId alarmId,
        AssetId assetId,
        AlarmSeverity severity,
        AlarmValue value,
        string message)
    {
        AlarmId = alarmId;
        AssetId = assetId;
        Severity = severity;
        Value = value;
        Message = message;
    }
}

// Domain/Events/AlarmAcknowledgedEvent.cs
public sealed record AlarmAcknowledgedEvent : DomainEvent
{
    public AlarmId AlarmId { get; init; }
    public string AcknowledgedBy { get; init; }
    public DateTime AcknowledgedAt { get; init; }

    public AlarmAcknowledgedEvent(AlarmId alarmId, string acknowledgedBy)
    {
        AlarmId = alarmId;
        AcknowledgedBy = acknowledgedBy;
        AcknowledgedAt = DateTime.UtcNow;
    }
}

// Domain/Events/AlarmEscalatedEvent.cs
public sealed record AlarmEscalatedEvent : DomainEvent
{
    public AlarmId AlarmId { get; init; }
    public AlarmSeverity OldSeverity { get; init; }
    public AlarmSeverity NewSeverity { get; init; }
    public string Reason { get; init; }

    public AlarmEscalatedEvent(
        AlarmId alarmId,
        AlarmSeverity oldSeverity,
        AlarmSeverity newSeverity,
        string reason)
    {
        AlarmId = alarmId;
        OldSeverity = oldSeverity;
        NewSeverity = newSeverity;
        Reason = reason;
    }
}

// Domain/Events/AlarmResolvedEvent.cs
public sealed record AlarmResolvedEvent : DomainEvent
{
    public AlarmId AlarmId { get; init; }
    public string ResolvedBy { get; init; }
    public string Resolution { get; init; }
    public TimeSpan ResolutionTime { get; init; }

    public AlarmResolvedEvent(
        AlarmId alarmId,
        string resolvedBy,
        string resolution,
        TimeSpan resolutionTime)
    {
        AlarmId = alarmId;
        ResolvedBy = resolvedBy;
        Resolution = resolution;
        ResolutionTime = resolutionTime;
    }
}
```

### 5. Alarm Aggregate Root

```csharp
// Domain/Aggregates/Alarm/Alarm.cs
using BahyWay.SharedKernel.Domain;
using BahyWay.SharedKernel.Guards;
using BahyWay.SharedKernel.Results;

namespace BahyWay.AlarmManagement.Domain.Aggregates.Alarm;

/// <summary>
/// Alarm aggregate root.
/// Represents an alarm condition detected on an asset.
/// 
/// Business Rules:
/// 1. Only active alarms can be acknowledged
/// 2. Alarms escalate automatically after threshold time
/// 3. Critical alarms require immediate action
/// 4. Alarms maintain complete audit trail
/// </summary>
public sealed class Alarm : AggregateRoot<AlarmId>
{
    // Properties
    public AssetId AssetId { get; private set; }
    public AlarmSeverity Severity { get; private set; }
    public AlarmStatus Status { get; private set; }
    public AlarmValue Value { get; private set; }
    public string Message { get; private set; }
    public string? Description { get; private set; }
    public GeoLocation? Location { get; private set; }
    
    // Timestamps
    public DateTime OccurredAt { get; private set; }
    public DateTime? AcknowledgedAt { get; private set; }
    public DateTime? ResolvedAt { get; private set; }
    
    // Tracking
    public string? AcknowledgedBy { get; private set; }
    public string? ResolvedBy { get; private set; }
    public string? Resolution { get; private set; }
    public int EscalationCount { get; private set; }

    // EF Core constructor
    private Alarm() { }

    // Factory method
    public static Alarm Create(
        AssetId assetId,
        AlarmSeverity severity,
        AlarmValue value,
        string message,
        string? description = null,
        GeoLocation? location = null)
    {
        // Validation
        Guard.Against.Null(assetId, nameof(assetId));
        Guard.Against.Null(severity, nameof(severity));
        Guard.Against.Null(value, nameof(value));
        Guard.Against.NullOrWhiteSpace(message, nameof(message));

        var alarm = new Alarm
        {
            Id = AlarmId.New(),
            AssetId = assetId,
            Severity = severity,
            Status = AlarmStatus.Active,
            Value = value,
            Message = message,
            Description = description,
            Location = location,
            OccurredAt = DateTime.UtcNow,
            EscalationCount = 0
        };

        // Raise domain event
        alarm.AddDomainEvent(new AlarmCreatedEvent(
            alarm.Id,
            alarm.AssetId,
            alarm.Severity,
            alarm.Value,
            alarm.Message));

        return alarm;
    }

    // Business methods
    public Result Acknowledge(string acknowledgedBy)
    {
        Guard.Against.NullOrWhiteSpace(acknowledgedBy, nameof(acknowledgedBy));

        if (!Status.CanBeAcknowledged())
        {
            return Result.Failure(
                "AlarmCannotBeAcknowledged",
                $"Alarm in status '{Status.Name}' cannot be acknowledged");
        }

        Status = AlarmStatus.Acknowledged;
        AcknowledgedAt = DateTime.UtcNow;
        AcknowledgedBy = acknowledgedBy;

        AddDomainEvent(new AlarmAcknowledgedEvent(Id, acknowledgedBy));

        return Result.Success();
    }

    public Result Escalate(string reason)
    {
        Guard.Against.NullOrWhiteSpace(reason, nameof(reason));

        var nextSeverity = Severity.GetNextSeverity();
        if (nextSeverity == null)
        {
            return Result.Failure(
                "AlarmAlreadyMaxSeverity",
                "Alarm is already at maximum severity");
        }

        var oldSeverity = Severity;
        Severity = nextSeverity;
        EscalationCount++;

        AddDomainEvent(new AlarmEscalatedEvent(Id, oldSeverity, Severity, reason));

        return Result.Success();
    }

    public Result Resolve(string resolvedBy, string resolution)
    {
        Guard.Against.NullOrWhiteSpace(resolvedBy, nameof(resolvedBy));
        Guard.Against.NullOrWhiteSpace(resolution, nameof(resolution));

        if (!Status.CanBeResolved())
        {
            return Result.Failure(
                "AlarmCannotBeResolved",
                $"Alarm in status '{Status.Name}' cannot be resolved");
        }

        Status = AlarmStatus.Resolved;
        ResolvedAt = DateTime.UtcNow;
        ResolvedBy = resolvedBy;
        Resolution = resolution;

        var resolutionTime = ResolvedAt.Value - OccurredAt;

        AddDomainEvent(new AlarmResolvedEvent(Id, resolvedBy, resolution, resolutionTime));

        return Result.Success();
    }

    public Result Suppress(string reason)
    {
        if (Status.IsFinal())
        {
            return Result.Failure(
                "AlarmAlreadyFinal",
                "Cannot suppress an alarm that is already resolved or closed");
        }

        Status = AlarmStatus.Suppressed;

        return Result.Success();
    }

    public bool IsOverdue()
    {
        if (Status != AlarmStatus.Active)
        {
            return false;
        }

        var threshold = Severity.GetEscalationThreshold();
        var elapsed = DateTime.UtcNow - OccurredAt;

        return elapsed > threshold;
    }

    public bool RequiresEscalation()
    {
        return IsOverdue() && Severity != AlarmSeverity.Critical;
    }

    public TimeSpan GetAge()
    {
        var endTime = ResolvedAt ?? DateTime.UtcNow;
        return endTime - OccurredAt;
    }

    public TimeSpan? GetTimeToAcknowledge()
    {
        return AcknowledgedAt.HasValue 
            ? AcknowledgedAt.Value - OccurredAt 
            : null;
    }

    public TimeSpan? GetTimeToResolve()
    {
        return ResolvedAt.HasValue 
            ? ResolvedAt.Value - OccurredAt 
            : null;
    }
}
```

### 6. Asset Aggregate Root

```csharp
// Domain/Aggregates/Asset/AssetId.cs
public sealed record AssetId
{
    public Guid Value { get; }

    private AssetId(Guid value)
    {
        if (value == Guid.Empty)
        {
            throw new ArgumentException("Asset ID cannot be empty", nameof(value));
        }
        Value = value;
    }

    public static AssetId New() => new(Guid.NewGuid());
    public static AssetId From(Guid value) => new(value);
    
    public override string ToString() => Value.ToString();
    
    public static implicit operator Guid(AssetId assetId) => assetId.Value;
}

// Domain/Aggregates/Asset/AssetType.cs
public sealed class AssetType : Enumeration
{
    public static readonly AssetType Sensor = new(1, nameof(Sensor));
    public static readonly AssetType Controller = new(2, nameof(Controller));
    public static readonly AssetType Gateway = new(3, nameof(Gateway));
    public static readonly AssetType Server = new(4, nameof(Server));
    public static readonly AssetType Device = new(5, nameof(Device));

    private AssetType(int value, string name) : base(value, name) { }
}

// Domain/Aggregates/Asset/Asset.cs
public sealed class Asset : AggregateRoot<AssetId>
{
    public string Name { get; private set; }
    public string? Description { get; private set; }
    public AssetType Type { get; private set; }
    public GeoLocation? Location { get; private set; }
    public bool IsActive { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public DateTime? LastMaintenanceDate { get; private set; }

    private readonly List<ThresholdRange> _thresholds = new();
    public IReadOnlyCollection<ThresholdRange> Thresholds => _thresholds.AsReadOnly();

    private Asset() { }

    public static Asset Create(
        string name,
        AssetType type,
        string? description = null,
        GeoLocation? location = null)
    {
        Guard.Against.NullOrWhiteSpace(name, nameof(name));
        Guard.Against.Null(type, nameof(type));

        var asset = new Asset
        {
            Id = AssetId.New(),
            Name = name,
            Type = type,
            Description = description,
            Location = location,
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };

        return asset;
    }

    public void AddThreshold(ThresholdRange threshold)
    {
        Guard.Against.Null(threshold, nameof(threshold));
        _thresholds.Add(threshold);
    }

    public void RemoveThreshold(ThresholdRange threshold)
    {
        _thresholds.Remove(threshold);
    }

    public void UpdateLocation(GeoLocation location)
    {
        Location = location;
    }

    public void Deactivate()
    {
        IsActive = false;
    }

    public void Activate()
    {
        IsActive = true;
    }

    public void RecordMaintenance()
    {
        LastMaintenanceDate = DateTime.UtcNow;
    }
}
```

### 7. Repository Interfaces

```csharp
// Domain/Repositories/IAlarmRepository.cs
using BahyWay.SharedKernel.Domain;

namespace BahyWay.AlarmManagement.Domain.Repositories;

public interface IAlarmRepository : IRepository<Alarm, AlarmId>
{
    Task<List<Alarm>> GetActiveAlarmsAsync(CancellationToken cancellationToken = default);
    
    Task<List<Alarm>> GetCriticalAlarmsAsync(CancellationToken cancellationToken = default);
    
    Task<List<Alarm>> GetOverdueAlarmsAsync(CancellationToken cancellationToken = default);
    
    Task<List<Alarm>> GetAlarmsByAssetAsync(
        AssetId assetId, 
        CancellationToken cancellationToken = default);
    
    Task<List<Alarm>> GetAlarmsInDateRangeAsync(
        DateTime startDate,
        DateTime endDate,
        CancellationToken cancellationToken = default);
    
    Task<int> GetActiveAlarmCountAsync(CancellationToken cancellationToken = default);
    
    Task<Dictionary<AlarmSeverity, int>> GetAlarmCountBySeverityAsync(
        CancellationToken cancellationToken = default);
}

// Domain/Repositories/IAssetRepository.cs
public interface IAssetRepository : IRepository<Asset, AssetId>
{
    Task<List<Asset>> GetActiveAssetsAsync(CancellationToken cancellationToken = default);
    
    Task<Asset?> GetByNameAsync(string name, CancellationToken cancellationToken = default);
    
    Task<List<Asset>> GetAssetsByTypeAsync(
        AssetType type,
        CancellationToken cancellationToken = default);
    
    Task<List<Asset>> GetAssetsNearLocationAsync(
        GeoLocation location,
        double radiusKm,
        CancellationToken cancellationToken = default);
}
```

### 8. Specifications

```csharp
// Domain/Specifications/ActiveAlarmsSpecification.cs
using BahyWay.SharedKernel.Domain;

namespace BahyWay.AlarmManagement.Domain.Specifications;

public sealed class ActiveAlarmsSpecification : Specification<Alarm>
{
    public ActiveAlarmsSpecification() 
        : base(alarm => alarm.Status == AlarmStatus.Active)
    {
        ApplyOrderByDescending(alarm => alarm.OccurredAt);
    }
}

// Domain/Specifications/CriticalAlarmsSpecification.cs
public sealed class CriticalAlarmsSpecification : Specification<Alarm>
{
    public CriticalAlarmsSpecification()
        : base(alarm => 
            alarm.Severity == AlarmSeverity.Critical &&
            alarm.Status == AlarmStatus.Active)
    {
        ApplyOrderBy(alarm => alarm.OccurredAt);
    }
}

// Domain/Specifications/UnacknowledgedAlarmsSpecification.cs
public sealed class UnacknowledgedAlarmsSpecification : Specification<Alarm>
{
    public UnacknowledgedAlarmsSpecification(TimeSpan? olderThan = null)
        : base(alarm =>
            alarm.Status == AlarmStatus.Active &&
            alarm.AcknowledgedAt == null &&
            (olderThan == null || alarm.OccurredAt < DateTime.UtcNow - olderThan))
    {
        ApplyOrderByDescending(alarm => alarm.Severity.Value);
    }
}
```

---

## 🎯 Key Takeaways from Domain Layer

✅ **Rich Domain Model:** Business logic in the domain, not in services  
✅ **Strongly-Typed IDs:** Cannot mix up AlarmId with AssetId  
✅ **Immutable Value Objects:** Thread-safe, no side effects  
✅ **Type-Safe Enumerations:** More powerful than C# enums  
✅ **Domain Events:** Decoupled communication between aggregates  
✅ **Factory Methods:** Encapsulate object creation logic  
✅ **Guard Clauses:** Fail fast with clear error messages  
✅ **Result Pattern:** No exceptions for expected failures  

---

**Next: I'll continue with the Application Layer (CQRS, Commands, Queries, Handlers).**
