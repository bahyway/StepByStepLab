# BahyWay Platform - Quick Reference Card

**Keep this open while coding!** 📌

---

## 🏗️ Layer Dependencies (The Golden Rule)

```
Presentation → Application → Domain ← Infrastructure
                              ↑
                        SharedKernel

✅ Domain has ZERO dependencies
✅ Application depends only on Domain
✅ Infrastructure implements Domain interfaces
✅ Presentation depends on Application
```

**Remember:** Dependencies flow inward toward Domain.

---

## 📁 Project Structure (Copy This)

```
BahyWay.{BoundedContext}/
├── Domain/
│   ├── Aggregates/{AggregateName}/
│   │   ├── {Aggregate}.cs
│   │   ├── {Aggregate}Id.cs
│   │   └── {Aggregate}Status.cs
│   ├── ValueObjects/
│   ├── Events/
│   ├── Repositories/
│   └── Specifications/
│
├── Application/
│   ├── Commands/{CommandName}/
│   │   ├── {Command}Command.cs
│   │   ├── {Command}CommandHandler.cs
│   │   └── {Command}CommandValidator.cs
│   ├── Queries/{QueryName}/
│   ├── DTOs/
│   └── Mappings/
│
├── Infrastructure/
│   ├── Persistence/
│   │   ├── {Context}DbContext.cs
│   │   ├── Configurations/
│   │   └── Repositories/
│   ├── ExternalServices/
│   └── EventHandlers/
│
└── API/ or Desktop/
```

---

## 🎯 Quick Patterns

### Strongly-Typed ID
```csharp
public sealed record AlarmId
{
    public Guid Value { get; }
    private AlarmId(Guid value) { Value = value; }
    public static AlarmId New() => new(Guid.NewGuid());
    public static AlarmId From(Guid value) => new(value);
}
```

### Type-Safe Enumeration
```csharp
public sealed class AlarmSeverity : Enumeration
{
    public static readonly AlarmSeverity Critical = new(5, nameof(Critical));
    private AlarmSeverity(int value, string name) : base(value, name) { }
}
```

### Value Object
```csharp
public sealed class AlarmValue : ValueObject
{
    public double Value { get; }
    public string Unit { get; }
    
    private AlarmValue(double value, string unit)
    {
        Value = value;
        Unit = unit;
    }
    
    public static AlarmValue Create(double value, string unit)
    {
        Guard.Against.NullOrWhiteSpace(unit, nameof(unit));
        return new AlarmValue(value, unit);
    }
    
    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return Value;
        yield return Unit;
    }
}
```

### Aggregate Root
```csharp
public sealed class Alarm : AggregateRoot<AlarmId>
{
    // Properties
    public AlarmSeverity Severity { get; private set; }
    public AlarmStatus Status { get; private set; }
    
    // Factory method
    public static Alarm Create(params...)
    {
        var alarm = new Alarm { /* init */ };
        alarm.AddDomainEvent(new AlarmCreatedEvent(...));
        return alarm;
    }
    
    // Business methods
    public Result Acknowledge(string user)
    {
        if (!Status.CanBeAcknowledged())
            return Result.Failure("Cannot acknowledge");
        
        Status = AlarmStatus.Acknowledged;
        AddDomainEvent(new AlarmAcknowledgedEvent(...));
        return Result.Success();
    }
}
```

### Domain Event
```csharp
public sealed record AlarmCreatedEvent : DomainEvent
{
    public AlarmId AlarmId { get; init; }
    public AlarmSeverity Severity { get; init; }
    
    public AlarmCreatedEvent(AlarmId alarmId, AlarmSeverity severity)
    {
        AlarmId = alarmId;
        Severity = severity;
    }
}
```

### Command & Handler
```csharp
// Command
public sealed record CreateAlarmCommand : IRequest<Result<AlarmDto>>
{
    public Guid AssetId { get; init; }
    public int SeverityValue { get; init; }
    public string Message { get; init; } = string.Empty;
}

// Validator
public sealed class CreateAlarmCommandValidator : AbstractValidator<CreateAlarmCommand>
{
    public CreateAlarmCommandValidator()
    {
        RuleFor(x => x.AssetId).NotEmpty();
        RuleFor(x => x.Message).NotEmpty().MaximumLength(500);
    }
}

// Handler
public sealed class CreateAlarmCommandHandler 
    : IRequestHandler<CreateAlarmCommand, Result<AlarmDto>>
{
    public async Task<Result<AlarmDto>> Handle(
        CreateAlarmCommand request,
        CancellationToken cancellationToken)
    {
        // 1. Validate
        // 2. Create aggregate
        // 3. Persist
        // 4. Return DTO
    }
}
```

### Query & Handler
```csharp
// Query
public sealed record GetAlarmQuery : IRequest<Result<AlarmDto>>
{
    public Guid AlarmId { get; init; }
}

// Handler
public sealed class GetAlarmQueryHandler 
    : IRequestHandler<GetAlarmQuery, Result<AlarmDto>>
{
    public async Task<Result<AlarmDto>> Handle(
        GetAlarmQuery request,
        CancellationToken cancellationToken)
    {
        var alarm = await _repository.GetByIdAsync(AlarmId.From(request.AlarmId));
        if (alarm == null) return Result.Failure<AlarmDto>(Error.NotFound);
        return Result.Success(_mapper.Map<AlarmDto>(alarm));
    }
}
```

### Repository Interface
```csharp
public interface IAlarmRepository : IRepository<Alarm, AlarmId>
{
    Task<List<Alarm>> GetActiveAlarmsAsync(CancellationToken ct = default);
    Task<List<Alarm>> GetCriticalAlarmsAsync(CancellationToken ct = default);
}
```

### Repository Implementation
```csharp
internal sealed class AlarmRepository : IAlarmRepository
{
    private readonly DbContext _context;
    
    public async Task<Alarm?> GetByIdAsync(AlarmId id, CancellationToken ct)
    {
        return await _context.Alarms.FirstOrDefaultAsync(a => a.Id == id, ct);
    }
    
    public async Task AddAsync(Alarm alarm, CancellationToken ct)
    {
        await _context.Alarms.AddAsync(alarm, ct);
    }
}
```

### EF Core Configuration
```csharp
internal sealed class AlarmConfiguration : IEntityTypeConfiguration<Alarm>
{
    public void Configure(EntityTypeBuilder<Alarm> builder)
    {
        builder.ToTable("alarms");
        
        builder.HasKey(a => a.Id);
        builder.Property(a => a.Id)
            .HasConversion(id => id.Value, value => AlarmId.From(value));
        
        builder.Property(a => a.Severity)
            .HasConversion(
                s => s.Value,
                v => AlarmSeverity.FromValue<AlarmSeverity>(v));
        
        builder.OwnsOne(a => a.Value);
    }
}
```

---

## ✅ Checklist for New Feature

```
☐ Define domain model (aggregate, value objects)
☐ Add business logic to aggregate
☐ Create domain events
☐ Write domain tests
☐ Create command/query
☐ Write validator
☐ Implement handler
☐ Write handler tests
☐ Update repository if needed
☐ Create/update DTO
☐ Add AutoMapper profile
☐ Create API endpoint
☐ Test end-to-end
```

---

## 🚫 Common Mistakes to Avoid

```
❌ Domain depends on Application/Infrastructure
❌ Putting business logic in services
❌ Using primitive types instead of value objects
❌ Mutable value objects
❌ Public setters on aggregates
❌ Transactions spanning multiple aggregates
❌ Exceptions for expected failures
❌ Missing domain events
❌ Anemic domain model (only getters/setters)
❌ Bypassing aggregate to modify children
```

---

## ✅ Best Practices

```
✅ Use factory methods for creation
✅ Keep aggregates small
✅ One repository per aggregate
✅ Value objects for domain concepts
✅ Domain events for side effects
✅ Result pattern for failures
✅ Guard clauses for validation
✅ Immutable value objects
✅ Strongly-typed IDs
✅ Meaningful names
```

---

## 🧪 Testing Quick Reference

### Unit Test (Domain)
```csharp
[Fact]
public void Create_ShouldRaiseDomainEvent()
{
    var alarm = Alarm.Create(assetId, severity, value, "message");
    alarm.DomainEvents.Should().HaveCount(1);
}
```

### Unit Test (Handler)
```csharp
[Fact]
public async Task Handle_ValidCommand_ShouldCreateAlarm()
{
    var command = new CreateAlarmCommand { /* ... */ };
    var result = await _handler.Handle(command, CancellationToken.None);
    result.IsSuccess.Should().BeTrue();
}
```

### Integration Test
```csharp
[Fact]
public async Task CreateAlarm_ShouldPersistToDatabase()
{
    var command = new CreateAlarmCommand { /* ... */ };
    await _mediator.Send(command);
    
    var alarm = await _context.Alarms.FirstOrDefaultAsync();
    alarm.Should().NotBeNull();
}
```

---

## 🎯 Naming Conventions

### Domain
```
{Aggregate}Id           - AlarmId, AssetId
{Aggregate}Status       - AlarmStatus, OrderStatus
{Aggregate}Type         - AssetType, UserType
{Concept}                - AlarmValue, ThresholdRange
{Action}Event           - AlarmCreatedEvent, OrderPlacedEvent
I{Aggregate}Repository  - IAlarmRepository
{Criteria}Specification - ActiveAlarmsSpecification
```

### Application
```
{Action}{Aggregate}Command         - CreateAlarmCommand
{Action}{Aggregate}CommandHandler  - CreateAlarmCommandHandler
{Action}{Aggregate}CommandValidator- CreateAlarmCommandValidator
Get{Aggregate}Query                - GetAlarmQuery
Get{Aggregate}QueryHandler         - GetAlarmQueryHandler
{Aggregate}Dto                     - AlarmDto
{Aggregate}MappingProfile          - AlarmMappingProfile
```

### Infrastructure
```
{Context}DbContext                 - AlarmManagementDbContext
{Aggregate}Configuration           - AlarmConfiguration
{Aggregate}Repository              - AlarmRepository
{External}Service                  - RulesEngineService
{Event}Handler                     - AlarmCreatedEventHandler
```

---

## 📦 NuGet Packages (Copy This)

### Domain
```xml
<!-- Zero dependencies! -->
```

### Application
```xml
<PackageReference Include="MediatR" Version="12.2.0" />
<PackageReference Include="FluentValidation" Version="11.9.0" />
<PackageReference Include="AutoMapper" Version="12.0.1" />
```

### Infrastructure
```xml
<PackageReference Include="Microsoft.EntityFrameworkCore" Version="8.0.0" />
<PackageReference Include="Npgsql.EntityFrameworkCore.PostgreSQL" Version="8.0.0" />
<PackageReference Include="Microsoft.Extensions.Http.Polly" Version="8.0.0" />
```

---

## 🔧 Useful Commands

### EF Core Migrations
```bash
# Add migration
dotnet ef migrations add InitialCreate --project Infrastructure

# Update database
dotnet ef database update --project Infrastructure

# Remove last migration
dotnet ef migrations remove --project Infrastructure

# Generate SQL script
dotnet ef migrations script --project Infrastructure
```

### Docker
```bash
# Build image
docker build -t bahyway/alarm-insight:latest .

# Run container
docker run -p 5001:80 bahyway/alarm-insight:latest

# Docker Compose
docker-compose up --build
docker-compose down -v
```

### Testing
```bash
# Run all tests
dotnet test

# Run specific project
dotnet test tests/Domain.Tests/

# With coverage
dotnet test /p:CollectCoverage=true /p:CoverletOutputFormat=opencover
```

---

## 💡 When in Doubt

1. **Check AlarmManagement example** - It has the pattern you need
2. **Follow the layer rules** - Don't break dependencies
3. **Ask: "Is this business logic?"** - If yes, it goes in Domain
4. **Use value objects** - If it's a concept, it deserves a type
5. **Raise domain events** - When something important happens
6. **Return Result<T>** - Not exceptions for business failures
7. **Write tests first** - They guide design
8. **Keep it simple** - Don't over-engineer

---

## 📚 Quick Links

- Architecture Blueprint: `BahyWay-Architecture-Blueprint.md`
- SharedKernel Reference: `BahyWay-SharedKernel-Complete-Implementation.md`
- Domain Example: `BahyWay-AlarmManagement-Domain-Complete.md`
- Application Example: `BahyWay-AlarmManagement-Application-Complete.md`
- Infrastructure Example: `BahyWay-AlarmManagement-Infrastructure-Complete.md`
- Implementation Guide: `BahyWay-Master-Implementation-Guide.md`

---

## 🎯 Today's Goal

**Build one complete feature following the pattern:**

1. Domain: Aggregate + Events + Tests (1 hour)
2. Application: Command + Handler + Validator (1 hour)
3. Infrastructure: Repository + Configuration (30 min)
4. API: Controller + DI (30 min)
5. Tests: Integration tests (30 min)

**Total: 3.5 hours for production-quality feature**

---

**Print this. Keep it visible. Reference it daily.** 📌

© 2025 BahyWay Platform
