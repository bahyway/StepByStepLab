# KGEditorWay - Avalonia UI Part 3: Styles, Behaviors & Services

## 🎨 Styles

### GraphCanvasStyles.axaml

```xml
<!-- Styles/GraphCanvasStyles.axaml -->
<Styles xmlns="https://github.com/avaloniaui"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml">
    
    <!-- Canvas Styles -->
    <Style Selector="Panel.graph-canvas">
        <Setter Property="Background" Value="#252525"/>
        <Setter Property="ClipToBounds" Value="True"/>
    </Style>
    
    <!-- Grid Lines -->
    <Style Selector="Line.grid-line">
        <Setter Property="Stroke" Value="#2A2A2A"/>
        <Setter Property="StrokeThickness" Value="1"/>
    </Style>
    
    <!-- Selection Rectangle -->
    <Style Selector="Rectangle.selection-rect">
        <Setter Property="Stroke" Value="#2196F3"/>
        <Setter Property="StrokeThickness" Value="2"/>
        <Setter Property="StrokeDashArray" Value="4,4"/>
        <Setter Property="Fill" Value="#2196F333"/>
    </Style>
    
</Styles>
```

### NodeStyles.axaml

```xml
<!-- Styles/NodeStyles.axaml -->
<Styles xmlns="https://github.com/avaloniaui"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml">
    
    <!-- Base Node Style -->
    <Style Selector="Border.node">
        <Setter Property="Background" Value="#1E1E1E"/>
        <Setter Property="BorderThickness" Value="2"/>
        <Setter Property="CornerRadius" Value="8"/>
        <Setter Property="Padding" Value="12"/>
        <Setter Property="Cursor" Value="Hand"/>
    </Style>
    
    <!-- Node Hover -->
    <Style Selector="Border.node:pointerover">
        <Setter Property="Background" Value="#252525"/>
    </Style>
    
    <!-- Node Selected -->
    <Style Selector="Border.node.selected">
        <Setter Property="BorderThickness" Value="3"/>
    </Style>
    
    <!-- Node Dragging -->
    <Style Selector="Border.node.dragging">
        <Setter Property="Opacity" Value="0.8"/>
    </Style>
    
    <!-- Port Styles -->
    <Style Selector="Ellipse.port">
        <Setter Property="Width" Value="12"/>
        <Setter Property="Height" Value="12"/>
        <Setter Property="Stroke" Value="White"/>
        <Setter Property="StrokeThickness" Value="1"/>
        <Setter Property="Cursor" Value="Hand"/>
    </Style>
    
    <Style Selector="Ellipse.port.input">
        <Setter Property="Fill" Value="#4CAF50"/>
    </Style>
    
    <Style Selector="Ellipse.port.output">
        <Setter Property="Fill" Value="#2196F3"/>
    </Style>
    
    <Style Selector="Ellipse.port:pointerover">
        <Setter Property="Width" Value="16"/>
        <Setter Property="Height" Value="16"/>
        <Setter Property="StrokeThickness" Value="2"/>
    </Style>
    
    <Style Selector="Ellipse.port.connecting">
        <Setter Property="Fill" Value="#FF9800"/>
        <Setter Property="Width" Value="16"/>
        <Setter Property="Height" Value="16"/>
    </Style>
    
</Styles>
```

### ToolbarStyles.axaml

```xml
<!-- Styles/ToolbarStyles.axaml -->
<Styles xmlns="https://github.com/avaloniaui"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml">
    
    <!-- Toolbar Button -->
    <Style Selector="Button.toolbar">
        <Setter Property="Background" Value="Transparent"/>
        <Setter Property="BorderThickness" Value="0"/>
        <Setter Property="Padding" Value="12,6"/>
        <Setter Property="Foreground" Value="White"/>
        <Setter Property="FontSize" Value="13"/>
        <Setter Property="Cursor" Value="Hand"/>
    </Style>
    
    <Style Selector="Button.toolbar:pointerover">
        <Setter Property="Background" Value="#3E3E42"/>
    </Style>
    
    <Style Selector="Button.toolbar:pressed">
        <Setter Property="Background" Value="#007ACC"/>
    </Style>
    
    <Style Selector="Button.toolbar:disabled">
        <Setter Property="Opacity" Value="0.5"/>
        <Setter Property="Cursor" Value="Default"/>
    </Style>
    
    <!-- Primary Toolbar Button -->
    <Style Selector="Button.toolbar.primary">
        <Setter Property="Background" Value="#007ACC"/>
        <Setter Property="FontWeight" Value="SemiBold"/>
    </Style>
    
    <Style Selector="Button.toolbar.primary:pointerover">
        <Setter Property="Background" Value="#1E8AD6"/>
    </Style>
    
    <!-- Toolbox Node Button -->
    <Style Selector="Button.toolbox-node">
        <Setter Property="Background" Value="Transparent"/>
        <Setter Property="BorderThickness" Value="1"/>
        <Setter Property="BorderBrush" Value="#3E3E42"/>
        <Setter Property="Padding" Value="8"/>
        <Setter Property="HorizontalContentAlignment" Value="Left"/>
        <Setter Property="Foreground" Value="White"/>
    </Style>
    
    <Style Selector="Button.toolbox-node:pointerover">
        <Setter Property="Background" Value="#2D2D30"/>
        <Setter Property="BorderBrush" Value="#007ACC"/>
    </Style>
    
</Styles>
```

---

## ⚡ Behaviors

### CanvasPanBehavior.cs

```csharp
// Behaviors/CanvasPanBehavior.cs
using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Xaml.Interactivity;
using BahyWay.KGEditorWay.Desktop.ViewModels;

namespace BahyWay.KGEditorWay.Desktop.Behaviors;

public class CanvasPanBehavior : Behavior<Panel>
{
    private Point _lastPanPoint;
    private bool _isPanning;
    
    protected override void OnAttached()
    {
        base.OnAttached();
        
        if (AssociatedObject != null)
        {
            AssociatedObject.PointerPressed += OnPointerPressed;
            AssociatedObject.PointerMoved += OnPointerMoved;
            AssociatedObject.PointerReleased += OnPointerReleased;
        }
    }
    
    protected override void OnDetaching()
    {
        base.OnDetaching();
        
        if (AssociatedObject != null)
        {
            AssociatedObject.PointerPressed -= OnPointerPressed;
            AssociatedObject.PointerMoved -= OnPointerMoved;
            AssociatedObject.PointerReleased -= OnPointerReleased;
        }
    }
    
    private void OnPointerPressed(object? sender, PointerPressedEventArgs e)
    {
        var props = e.GetCurrentPoint(AssociatedObject).Properties;
        
        if (props.IsMiddleButtonPressed || (props.IsLeftButtonPressed && e.KeyModifiers.HasFlag(KeyModifiers.Space)))
        {
            _isPanning = true;
            _lastPanPoint = e.GetPosition(AssociatedObject);
            e.Pointer.Capture(AssociatedObject);
            e.Handled = true;
        }
    }
    
    private void OnPointerMoved(object? sender, PointerEventArgs e)
    {
        if (_isPanning && AssociatedObject?.DataContext is GraphCanvasViewModel viewModel)
        {
            var currentPoint = e.GetPosition(AssociatedObject);
            var delta = currentPoint - _lastPanPoint;
            
            viewModel.PanX += delta.X;
            viewModel.PanY += delta.Y;
            
            _lastPanPoint = currentPoint;
        }
    }
    
    private void OnPointerReleased(object? sender, PointerReleasedEventArgs e)
    {
        if (_isPanning)
        {
            _isPanning = false;
            e.Pointer.Capture(null);
        }
    }
}
```

### CanvasZoomBehavior.cs

```csharp
// Behaviors/CanvasZoomBehavior.cs
using System;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Xaml.Interactivity;
using BahyWay.KGEditorWay.Desktop.ViewModels;

namespace BahyWay.KGEditorWay.Desktop.Behaviors;

public class CanvasZoomBehavior : Behavior<Panel>
{
    protected override void OnAttached()
    {
        base.OnAttached();
        
        if (AssociatedObject != null)
        {
            AssociatedObject.PointerWheelChanged += OnPointerWheelChanged;
        }
    }
    
    protected override void OnDetaching()
    {
        base.OnDetaching();
        
        if (AssociatedObject != null)
        {
            AssociatedObject.PointerWheelChanged -= OnPointerWheelChanged;
        }
    }
    
    private void OnPointerWheelChanged(object? sender, PointerWheelEventArgs e)
    {
        if (AssociatedObject?.DataContext is GraphCanvasViewModel viewModel)
        {
            var delta = e.Delta.Y;
            var mousePos = e.GetPosition(AssociatedObject);
            
            // Store old zoom and pan
            var oldZoom = viewModel.Zoom;
            var oldPanX = viewModel.PanX;
            var oldPanY = viewModel.PanY;
            
            // Calculate new zoom
            var zoomFactor = delta > 0 ? 1.1 : 0.9;
            var newZoom = Math.Clamp(oldZoom * zoomFactor, 0.1, 3.0);
            
            // Calculate zoom center point
            var worldX = (mousePos.X - oldPanX) / oldZoom;
            var worldY = (mousePos.Y - oldPanY) / oldZoom;
            
            // Update zoom
            viewModel.Zoom = newZoom;
            
            // Adjust pan to keep mouse position stable
            viewModel.PanX = mousePos.X - worldX * newZoom;
            viewModel.PanY = mousePos.Y - worldY * newZoom;
            
            e.Handled = true;
        }
    }
}
```

### NodeDragBehavior.cs

```csharp
// Behaviors/NodeDragBehavior.cs
using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Xaml.Interactivity;
using BahyWay.KGEditorWay.Desktop.ViewModels;

namespace BahyWay.KGEditorWay.Desktop.Behaviors;

public class NodeDragBehavior : Behavior<Control>
{
    private Point _dragStartPoint;
    private bool _isDragging;
    private NodeViewModel? _draggedNode;
    
    protected override void OnAttached()
    {
        base.OnAttached();
        
        if (AssociatedObject != null)
        {
            AssociatedObject.AddHandler(InputElement.PointerPressedEvent, OnPointerPressed, handledEventsToo: true);
            AssociatedObject.AddHandler(InputElement.PointerMovedEvent, OnPointerMoved, handledEventsToo: true);
            AssociatedObject.AddHandler(InputElement.PointerReleasedEvent, OnPointerReleased, handledEventsToo: true);
        }
    }
    
    protected override void OnDetaching()
    {
        base.OnDetaching();
        
        if (AssociatedObject != null)
        {
            AssociatedObject.RemoveHandler(InputElement.PointerPressedEvent, OnPointerPressed);
            AssociatedObject.RemoveHandler(InputElement.PointerMovedEvent, OnPointerMoved);
            AssociatedObject.RemoveHandler(InputElement.PointerReleasedEvent, OnPointerReleased);
        }
    }
    
    private void OnPointerPressed(object? sender, PointerPressedEventArgs e)
    {
        // Find if we clicked on a node
        var element = e.Source as Control;
        while (element != null && element.DataContext is not NodeViewModel)
        {
            element = element.Parent as Control;
        }
        
        if (element?.DataContext is NodeViewModel node)
        {
            var props = e.GetCurrentPoint(AssociatedObject).Properties;
            
            if (props.IsLeftButtonPressed)
            {
                _isDragging = true;
                _draggedNode = node;
                _dragStartPoint = e.GetPosition(AssociatedObject);
                node.IsDragging = true;
                
                // Select node
                if (!e.KeyModifiers.HasFlag(KeyModifiers.Control))
                {
                    // Deselect all others
                    if (AssociatedObject?.DataContext is GraphCanvasViewModel canvas)
                    {
                        foreach (var n in canvas.Nodes)
                        {
                            if (n != node)
                                n.IsSelected = false;
                        }
                    }
                }
                
                node.IsSelected = true;
            }
        }
    }
    
    private void OnPointerMoved(object? sender, PointerEventArgs e)
    {
        if (_isDragging && _draggedNode != null && AssociatedObject?.DataContext is GraphCanvasViewModel viewModel)
        {
            var currentPoint = e.GetPosition(AssociatedObject);
            var delta = currentPoint - _dragStartPoint;
            
            // Apply zoom factor
            var adjustedDelta = new Point(delta.X / viewModel.Zoom, delta.Y / viewModel.Zoom);
            
            // Move selected nodes
            foreach (var node in viewModel.Nodes)
            {
                if (node.IsSelected)
                {
                    node.Move(adjustedDelta.X, adjustedDelta.Y);
                }
            }
            
            _dragStartPoint = currentPoint;
        }
    }
    
    private void OnPointerReleased(object? sender, PointerReleasedEventArgs e)
    {
        if (_isDragging && _draggedNode != null)
        {
            _draggedNode.IsDragging = false;
            _draggedNode = null;
            _isDragging = false;
        }
    }
}
```

### SelectionBehavior.cs

```csharp
// Behaviors/SelectionBehavior.cs
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Shapes;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Xaml.Interactivity;
using BahyWay.KGEditorWay.Desktop.ViewModels;

namespace BahyWay.KGEditorWay.Desktop.Behaviors;

public class SelectionBehavior : Behavior<Panel>
{
    private Point _selectionStart;
    private bool _isSelecting;
    private Rectangle? _selectionRectangle;
    
    protected override void OnAttached()
    {
        base.OnAttached();
        
        if (AssociatedObject != null)
        {
            AssociatedObject.PointerPressed += OnPointerPressed;
            AssociatedObject.PointerMoved += OnPointerMoved;
            AssociatedObject.PointerReleased += OnPointerReleased;
        }
    }
    
    protected override void OnDetaching()
    {
        base.OnDetaching();
        
        if (AssociatedObject != null)
        {
            AssociatedObject.PointerPressed -= OnPointerPressed;
            AssociatedObject.PointerMoved -= OnPointerMoved;
            AssociatedObject.PointerReleased -= OnPointerReleased;
        }
    }
    
    private void OnPointerPressed(object? sender, PointerPressedEventArgs e)
    {
        var props = e.GetCurrentPoint(AssociatedObject).Properties;
        
        // Start selection on left click on empty space
        if (props.IsLeftButtonPressed && e.Source == AssociatedObject)
        {
            _isSelecting = true;
            _selectionStart = e.GetPosition(AssociatedObject);
            
            // Create selection rectangle
            _selectionRectangle = new Rectangle
            {
                Stroke = new SolidColorBrush(Color.Parse("#2196F3")),
                StrokeThickness = 2,
                StrokeDashArray = new AvaloniaList<double> { 4, 4 },
                Fill = new SolidColorBrush(Color.Parse("#2196F333")),
                IsHitTestVisible = false
            };
            
            Canvas.SetLeft(_selectionRectangle, _selectionStart.X);
            Canvas.SetTop(_selectionRectangle, _selectionStart.Y);
            
            AssociatedObject.Children.Add(_selectionRectangle);
        }
    }
    
    private void OnPointerMoved(object? sender, PointerEventArgs e)
    {
        if (_isSelecting && _selectionRectangle != null && AssociatedObject?.DataContext is GraphCanvasViewModel viewModel)
        {
            var currentPoint = e.GetPosition(AssociatedObject);
            
            var x = Math.Min(_selectionStart.X, currentPoint.X);
            var y = Math.Min(_selectionStart.Y, currentPoint.Y);
            var width = Math.Abs(currentPoint.X - _selectionStart.X);
            var height = Math.Abs(currentPoint.Y - _selectionStart.Y);
            
            Canvas.SetLeft(_selectionRectangle, x);
            Canvas.SetTop(_selectionRectangle, y);
            _selectionRectangle.Width = width;
            _selectionRectangle.Height = height;
            
            // Update node selection
            var selectionRect = new Rect(x, y, width, height);
            
            foreach (var node in viewModel.Nodes)
            {
                var nodeRect = new Rect(
                    node.X * viewModel.Zoom + viewModel.PanX,
                    node.Y * viewModel.Zoom + viewModel.PanY,
                    node.Width * viewModel.Zoom,
                    node.Height * viewModel.Zoom
                );
                
                node.IsSelected = selectionRect.Intersects(nodeRect);
            }
        }
    }
    
    private void OnPointerReleased(object? sender, PointerReleasedEventArgs e)
    {
        if (_isSelecting)
        {
            _isSelecting = false;
            
            if (_selectionRectangle != null)
            {
                AssociatedObject?.Children.Remove(_selectionRectangle);
                _selectionRectangle = null;
            }
        }
    }
}
```

---

## 🔄 Converters

### NodeTypeToColorConverter.cs

```csharp
// Converters/NodeTypeToColorConverter.cs
using System;
using System.Globalization;
using Avalonia.Data.Converters;
using Avalonia.Media;

namespace BahyWay.KGEditorWay.Desktop.Converters;

public class NodeTypeToColorConverter : IValueConverter
{
    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is string colorHex)
        {
            return new SolidColorBrush(Color.Parse(colorHex));
        }
        
        return new SolidColorBrush(Colors.Gray);
    }
    
    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}
```

### BoolToVisibilityConverter.cs

```csharp
// Converters/BoolToVisibilityConverter.cs
using System;
using System.Globalization;
using Avalonia.Data.Converters;

namespace BahyWay.KGEditorWay.Desktop.Converters;

public class BoolToVisibilityConverter : IValueConverter
{
    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is bool boolValue)
        {
            return boolValue;
        }
        
        return false;
    }
    
    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}
```

---

## 🔧 Services

### IGraphService.cs

```csharp
// Services/IGraphService.cs
using System.Threading.Tasks;
using BahyWay.SharedKernel.Results;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.KGEditorWay.Desktop.Services;

public interface IGraphService
{
    Task<Result<Graph>> CreateNewGraphAsync(string name, GraphType type);
    Task<Result<Graph>> LoadGraphAsync(string filePath);
    Task<Result> SaveGraphAsync(Graph graph, string filePath);
    Task<Result> ExecuteGraphAsync(Graph graph);
}
```

### GraphService.cs

```csharp
// Services/GraphService.cs
using System;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using BahyWay.SharedKernel.Results;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.KGEditorWay.Desktop.Services;

public class GraphService : IGraphService
{
    public Task<Result<Graph>> CreateNewGraphAsync(string name, GraphType type)
    {
        try
        {
            var graph = Graph.Create(name, type);
            return Task.FromResult(Result.Success(graph));
        }
        catch (Exception ex)
        {
            return Task.FromResult(Result.Failure<Graph>(
                new Error("Graph.CreateFailed", ex.Message)));
        }
    }
    
    public async Task<Result<Graph>> LoadGraphAsync(string filePath)
    {
        try
        {
            if (!File.Exists(filePath))
            {
                return Result.Failure<Graph>(
                    new Error("File.NotFound", $"File not found: {filePath}"));
            }
            
            var json = await File.ReadAllTextAsync(filePath);
            // TODO: Deserialize and reconstruct graph
            
            return Result.Failure<Graph>(
                new Error("NotImplemented", "Graph loading not yet implemented"));
        }
        catch (Exception ex)
        {
            return Result.Failure<Graph>(
                new Error("Graph.LoadFailed", ex.Message));
        }
    }
    
    public async Task<Result> SaveGraphAsync(Graph graph, string filePath)
    {
        try
        {
            // TODO: Serialize graph to JSON
            var json = JsonSerializer.Serialize(new { graph.Name, graph.Type });
            
            await File.WriteAllTextAsync(filePath, json);
            
            return Result.Success();
        }
        catch (Exception ex)
        {
            return Result.Failure(
                new Error("Graph.SaveFailed", ex.Message));
        }
    }
    
    public Task<Result> ExecuteGraphAsync(Graph graph)
    {
        // TODO: Implement graph execution
        return Task.FromResult(Result.Success());
    }
}
```

### IClipboardService.cs

```csharp
// Services/IClipboardService.cs
using System.Collections.Generic;
using System.Threading.Tasks;
using BahyWay.KGEditorWay.Desktop.ViewModels;

namespace BahyWay.KGEditorWay.Desktop.Services;

public interface IClipboardService
{
    Task CopyNodesAsync(IEnumerable<NodeViewModel> nodes);
    Task<IEnumerable<NodeViewModel>?> PasteNodesAsync();
    bool HasNodes { get; }
}
```

### ClipboardService.cs

```csharp
// Services/ClipboardService.cs
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BahyWay.KGEditorWay.Desktop.ViewModels;

namespace BahyWay.KGEditorWay.Desktop.Services;

public class ClipboardService : IClipboardService
{
    private List<NodeViewModel>? _clipboard;
    
    public bool HasNodes => _clipboard != null && _clipboard.Any();
    
    public Task CopyNodesAsync(IEnumerable<NodeViewModel> nodes)
    {
        _clipboard = nodes.ToList();
        return Task.CompletedTask;
    }
    
    public Task<IEnumerable<NodeViewModel>?> PasteNodesAsync()
    {
        if (_clipboard == null || !_clipboard.Any())
            return Task.FromResult<IEnumerable<NodeViewModel>?>(null);
        
        // Create copies of nodes with offset
        var copies = _clipboard.Select(n => new NodeViewModel(
            Guid.NewGuid(),
            n.Name + " (Copy)",
            n.NodeType,
            n.X + 50,
            n.Y + 50
        )).ToList();
        
        return Task.FromResult<IEnumerable<NodeViewModel>?>(copies);
    }
}
```

### IFileService.cs

```csharp
// Services/IFileService.cs
using System.Threading.Tasks;

namespace BahyWay.KGEditorWay.Desktop.Services;

public interface IFileService
{
    Task<string?> OpenFileDialogAsync(string title, params string[] filters);
    Task<string?> SaveFileDialogAsync(string title, string defaultFileName, params string[] filters);
}
```

### FileService.cs

```csharp
// Services/FileService.cs
using System.Linq;
using System.Threading.Tasks;
using Avalonia.Controls;
using Avalonia.Platform.Storage;

namespace BahyWay.KGEditorWay.Desktop.Services;

public class FileService : IFileService
{
    public async Task<string?> OpenFileDialogAsync(string title, params string[] filters)
    {
        var mainWindow = GetMainWindow();
        if (mainWindow == null) return null;
        
        var options = new FilePickerOpenOptions
        {
            Title = title,
            AllowMultiple = false,
            FileTypeFilter = CreateFileTypeFilters(filters)
        };
        
        var result = await mainWindow.StorageProvider.OpenFilePickerAsync(options);
        
        return result?.FirstOrDefault()?.Path.LocalPath;
    }
    
    public async Task<string?> SaveFileDialogAsync(string title, string defaultFileName, params string[] filters)
    {
        var mainWindow = GetMainWindow();
        if (mainWindow == null) return null;
        
        var options = new FilePickerSaveOptions
        {
            Title = title,
            SuggestedFileName = defaultFileName,
            FileTypeChoices = CreateFileTypeFilters(filters)
        };
        
        var result = await mainWindow.StorageProvider.SaveFilePickerAsync(options);
        
        return result?.Path.LocalPath;
    }
    
    private Window? GetMainWindow()
    {
        return Avalonia.Application.Current?.ApplicationLifetime is
            Avalonia.Controls.ApplicationLifetimes.IClassicDesktopStyleApplicationLifetime desktop
            ? desktop.MainWindow
            : null;
    }
    
    private FilePickerFileType[] CreateFileTypeFilters(string[] filters)
    {
        return filters.Select(f =>
        {
            var parts = f.Split('|');
            return new FilePickerFileType(parts[0])
            {
                Patterns = new[] { parts[1] }
            };
        }).ToArray();
    }
}
```

### IDialogService.cs

```csharp
// Services/IDialogService.cs
using System.Threading.Tasks;

namespace BahyWay.KGEditorWay.Desktop.Services;

public interface IDialogService
{
    Task ShowMessageAsync(string title, string message);
    Task<bool> ShowConfirmationAsync(string title, string message);
    Task ShowErrorAsync(string title, string message);
}
```

### DialogService.cs

```csharp
// Services/DialogService.cs
using System.Threading.Tasks;
using Avalonia.Controls;

namespace BahyWay.KGEditorWay.Desktop.Services;

public class DialogService : IDialogService
{
    public async Task ShowMessageAsync(string title, string message)
    {
        var mainWindow = GetMainWindow();
        if (mainWindow != null)
        {
            var dialog = new Window
            {
                Title = title,
                Width = 400,
                Height = 200,
                Content = new TextBlock { Text = message, Margin = new Avalonia.Thickness(20) }
            };
            
            await dialog.ShowDialog(mainWindow);
        }
    }
    
    public async Task<bool> ShowConfirmationAsync(string title, string message)
    {
        // TODO: Implement proper confirmation dialog
        await ShowMessageAsync(title, message);
        return true;
    }
    
    public async Task ShowErrorAsync(string title, string message)
    {
        await ShowMessageAsync($"Error: {title}", message);
    }
    
    private Window? GetMainWindow()
    {
        return Avalonia.Application.Current?.ApplicationLifetime is
            Avalonia.Controls.ApplicationLifetimes.IClassicDesktopStyleApplicationLifetime desktop
            ? desktop.MainWindow
            : null;
    }
}
```

---

## 🎯 MainViewModel

### MainViewModel.cs

```csharp
// ViewModels/MainViewModel.cs
using System;
using System.Reactive;
using ReactiveUI;
using BahyWay.KGEditorWay.Desktop.Services;

namespace BahyWay.KGEditorWay.Desktop.ViewModels;

public class MainViewModel : ViewModelBase
{
    private readonly IGraphService _graphService;
    private readonly IFileService _fileService;
    private readonly IDialogService _dialogService;
    
    private string _statusMessage = "Ready";
    private string _currentGraphName = "Untitled";
    private bool _canExecute = true;
    
    public GraphCanvasViewModel CanvasViewModel { get; }
    public ToolboxViewModel ToolboxViewModel { get; }
    public PropertiesPanelViewModel PropertiesViewModel { get; }
    
    public string StatusMessage
    {
        get => _statusMessage;
        set => this.RaiseAndSetIfChanged(ref _statusMessage, value);
    }
    
    public string CurrentGraphName
    {
        get => _currentGraphName;
        set => this.RaiseAndSetIfChanged(ref _currentGraphName, value);
    }
    
    public bool CanExecute
    {
        get => _canExecute;
        set => this.RaiseAndSetIfChanged(ref _canExecute, value);
    }
    
    // Commands
    public ReactiveCommand<Unit, Unit> NewGraphCommand { get; }
    public ReactiveCommand<Unit, Unit> OpenGraphCommand { get; }
    public ReactiveCommand<Unit, Unit> SaveGraphCommand { get; }
    public ReactiveCommand<Unit, Unit> SaveAsGraphCommand { get; }
    public ReactiveCommand<Unit, Unit> UndoCommand { get; }
    public ReactiveCommand<Unit, Unit> RedoCommand { get; }
    public ReactiveCommand<Unit, Unit> AutoLayoutCommand { get; }
    public ReactiveCommand<Unit, Unit> ExecuteGraphCommand { get; }
    public ReactiveCommand<Unit, Unit> PauseExecutionCommand { get; }
    public ReactiveCommand<Unit, Unit> StopExecutionCommand { get; }
    
    public MainViewModel(
        IGraphService graphService,
        IFileService fileService,
        IDialogService dialogService)
    {
        _graphService = graphService;
        _fileService = fileService;
        _dialogService = dialogService;
        
        CanvasViewModel = new GraphCanvasViewModel();
        ToolboxViewModel = new ToolboxViewModel(CanvasViewModel);
        PropertiesViewModel = new PropertiesPanelViewModel(CanvasViewModel);
        
        NewGraphCommand = ReactiveCommand.CreateFromTask(NewGraph);
        OpenGraphCommand = ReactiveCommand.CreateFromTask(OpenGraph);
        SaveGraphCommand = ReactiveCommand.CreateFromTask(SaveGraph);
        SaveAsGraphCommand = ReactiveCommand.CreateFromTask(SaveAsGraph);
        UndoCommand = ReactiveCommand.Create(Undo);
        RedoCommand = ReactiveCommand.Create(Redo);
        AutoLayoutCommand = ReactiveCommand.Create(AutoLayout);
        ExecuteGraphCommand = ReactiveCommand.CreateFromTask(ExecuteGraph);
        PauseExecutionCommand = ReactiveCommand.Create(PauseExecution);
        StopExecutionCommand = ReactiveCommand.Create(StopExecution);
    }
    
    private async Task NewGraph()
    {
        CurrentGraphName = "Untitled";
        CanvasViewModel.Nodes.Clear();
        CanvasViewModel.Connections.Clear();
        StatusMessage = "New graph created";
    }
    
    private async Task OpenGraph()
    {
        var filePath = await _fileService.OpenFileDialogAsync(
            "Open Graph",
            "KGEditor Files|*.kge",
            "All Files|*.*"
        );
        
        if (filePath != null)
        {
            StatusMessage = $"Opening {filePath}...";
            // TODO: Load graph
            CurrentGraphName = Path.GetFileNameWithoutExtension(filePath);
        }
    }
    
    private async Task SaveGraph()
    {
        StatusMessage = "Saving...";
        // TODO: Save graph
        StatusMessage = "Graph saved";
    }
    
    private async Task SaveAsGraph()
    {
        var filePath = await _fileService.SaveFileDialogAsync(
            "Save Graph As",
            $"{CurrentGraphName}.kge",
            "KGEditor Files|*.kge"
        );
        
        if (filePath != null)
        {
            StatusMessage = $"Saving to {filePath}...";
            // TODO: Save graph
            CurrentGraphName = Path.GetFileNameWithoutExtension(filePath);
        }
    }
    
    private void Undo()
    {
        StatusMessage = "Undo";
        // TODO: Implement undo
    }
    
    private void Redo()
    {
        StatusMessage = "Redo";
        // TODO: Implement redo
    }
    
    private void AutoLayout()
    {
        StatusMessage = "Auto layout...";
        // TODO: Implement auto layout
    }
    
    private async Task ExecuteGraph()
    {
        CanExecute = false;
        StatusMessage = "Executing graph...";
        
        try
        {
            // TODO: Execute graph
            await Task.Delay(2000); // Simulate execution
            
            StatusMessage = "Execution completed";
        }
        finally
        {
            CanExecute = true;
        }
    }
    
    private void PauseExecution()
    {
        StatusMessage = "Execution paused";
    }
    
    private void StopExecution()
    {
        StatusMessage = "Execution stopped";
        CanExecute = true;
    }
}
```

---

**Complete! Part 4 continues with ToolboxViewModel, PropertiesPanelViewModel, and MinimapView...**
