# KGEditorWay - Part 7: BahyWay Project Integrations

## 🎯 Overview

Complete integration of **KGEditorWay** with all BahyWay platform projects:
- **ETLway** - Universal ETL platform
- **SSISight** - SSIS package analysis and visualization
- **AlarmInsight** - Alarm processing and analytics
- **SteerView** - Geospatial data management

---

## 📦 Integration Architecture

```
┌──────────────────────────────────────────────────────────┐
│                    KGEditorWay Core                       │
│  (Visual Graph Editor + Execution Engine + AGE)          │
└─────────────┬────────────────────────────────────────────┘
              │
       ┌──────┴──────┬──────────┬──────────┬──────────┐
       │             │          │          │          │
   ┌───▼───┐    ┌───▼───┐  ┌───▼───┐  ┌───▼───┐  ┌───▼───┐
   │ETLway │    │SSIS   │  │Alarm  │  │Steer  │  │Future │
   │Plugin │    │Sight  │  │Insight│  │View   │  │Projects│
   └───────┘    │Plugin │  │Plugin │  │Plugin │  └────────┘
                └───────┘  └───────┘  └───────┘
```

---

## 1️⃣ ETLway Integration

### Overview
Integrate KGEditorWay as the visual designer for ETLway data pipelines.

### ETLwayNodeTypes.cs

```csharp
// Integrations/ETLway/ETLwayNodeTypes.cs
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.KGEditorWay.Integrations.ETLway;

public static class ETLwayNodeTypes
{
    // Data Sources
    public static readonly NodeType CsvSource = new(100, "CsvSource", "📄", "#4CAF50");
    public static readonly NodeType ExcelSource = new(101, "ExcelSource", "📊", "#4CAF50");
    public static readonly NodeType SqlServerSource = new(102, "SqlServerSource", "🗄️", "#336791");
    public static readonly NodeType PostgreSqlSource = new(103, "PostgreSqlSource", "🐘", "#336791");
    public static readonly NodeType RestApiSource = new(104, "RestApiSource", "🌐", "#4CAF50");
    public static readonly NodeType JsonFileSource = new(105, "JsonFileSource", "📋", "#4CAF50");
    
    // Transformations
    public static readonly NodeType MapColumns = new(200, "MapColumns", "🗺️", "#2196F3");
    public static readonly NodeType FilterRows = new(201, "FilterRows", "🔍", "#2196F3");
    public static readonly NodeType JoinTables = new(202, "JoinTables", "🔗", "#2196F3");
    public static readonly NodeType Aggregate = new(203, "Aggregate", "📊", "#2196F3");
    public static readonly NodeType SortRows = new(204, "SortRows", "⬆️", "#2196F3");
    public static readonly NodeType Pivot = new(205, "Pivot", "🔄", "#2196F3");
    public static readonly NodeType Unpivot = new(206, "Unpivot", "🔃", "#2196F3");
    public static readonly NodeType ScriptComponent = new(207, "ScriptComponent", "💻", "#9C27B0");
    
    // Data Quality
    public static readonly NodeType ValidateData = new(300, "ValidateData", "✅", "#FF9800");
    public static readonly NodeType CleanseData = new(301, "CleanseData", "🧹", "#FF9800");
    public static readonly NodeType DeduplicateRows = new(302, "DeduplicateRows", "🎯", "#FF9800");
    public static readonly NodeType HandleNulls = new(303, "HandleNulls", "⚠️", "#FF9800");
    
    // Data Sinks
    public static readonly NodeType CsvSink = new(400, "CsvSink", "📁", "#F44336");
    public static readonly NodeType SqlServerSink = new(401, "SqlServerSink", "🗄️", "#336791");
    public static readonly NodeType PostgreSqlSink = new(402, "PostgreSqlSink", "🐘", "#336791");
    public static readonly NodeType RestApiSink = new(403, "RestApiSink", "🌐", "#F44336");
    public static readonly NodeType EmailSink = new(404, "EmailSink", "✉️", "#F44336");
}
```

### ETLwayExecutors.cs

```csharp
// Integrations/ETLway/Executors/SqlServerSourceExecutor.cs
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;
using BahyWay.SharedKernel.Results;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;
using BahyWay.KGEditorWay.Execution.Nodes;
using Dapper;

namespace BahyWay.KGEditorWay.Integrations.ETLway.Executors;

public class SqlServerSourceExecutor : INodeExecutor
{
    public async Task<Result<object?>> ExecuteAsync(
        Node node,
        Dictionary<string, object?> inputData,
        ExecutionContext context,
        CancellationToken cancellationToken)
    {
        try
        {
            var connectionString = node.GetProperty<string>("ConnectionString");
            var query = node.GetProperty<string>("Query");
            var commandTimeout = node.GetProperty<int>("CommandTimeout") ?? 30;
            
            if (string.IsNullOrEmpty(connectionString))
            {
                return Result.Failure<object?>(
                    new Error("SqlServer.NoConnectionString", 
                        "Connection string is required"));
            }
            
            if (string.IsNullOrEmpty(query))
            {
                return Result.Failure<object?>(
                    new Error("SqlServer.NoQuery", "Query is required"));
            }
            
            await using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync(cancellationToken);
            
            var result = await connection.QueryAsync<dynamic>(
                query,
                commandTimeout: commandTimeout);
            
            var data = result.AsList();
            
            context.SetMetric($"{node.Name}.RowsRead", data.Count);
            
            return Result.Success<object?>(data);
        }
        catch (Exception ex)
        {
            return Result.Failure<object?>(
                new Error("SqlServer.ExecutionFailed", ex.Message));
        }
    }
    
    public async Task<r> ValidateAsync(Node node)
    {
        var connectionString = node.GetProperty<string>("ConnectionString");
        var query = node.GetProperty<string>("Query");
        
        if (string.IsNullOrEmpty(connectionString))
        {
            return Result.Failure(
                new Error("SqlServer.Validation", 
                    "Connection string is required"));
        }
        
        if (string.IsNullOrEmpty(query))
        {
            return Result.Failure(
                new Error("SqlServer.Validation", "Query is required"));
        }
        
        return await Task.FromResult(Result.Success());
    }
}

public class JoinTablesExecutor : INodeExecutor
{
    public async Task<Result<object?>> ExecuteAsync(
        Node node,
        Dictionary<string, object?> inputData,
        ExecutionContext context,
        CancellationToken cancellationToken)
    {
        try
        {
            var leftTable = inputData.GetValueOrDefault("left") as IEnumerable<dynamic>;
            var rightTable = inputData.GetValueOrDefault("right") as IEnumerable<dynamic>;
            var joinType = node.GetProperty<string>("JoinType") ?? "Inner"; // Inner, Left, Right, Full
            var leftKey = node.GetProperty<string>("LeftKey");
            var rightKey = node.GetProperty<string>("RightKey");
            
            if (leftTable == null || rightTable == null)
            {
                return Result.Failure<object?>(
                    new Error("Join.InvalidInput", 
                        "Both left and right tables are required"));
            }
            
            // Perform join based on type
            var result = joinType.ToLower() switch
            {
                "inner" => PerformInnerJoin(leftTable, rightTable, leftKey, rightKey),
                "left" => PerformLeftJoin(leftTable, rightTable, leftKey, rightKey),
                "right" => PerformRightJoin(leftTable, rightTable, leftKey, rightKey),
                "full" => PerformFullJoin(leftTable, rightTable, leftKey, rightKey),
                _ => PerformInnerJoin(leftTable, rightTable, leftKey, rightKey)
            };
            
            context.SetMetric($"{node.Name}.ResultRows", result.Count());
            
            return Result.Success<object?>(result);
        }
        catch (Exception ex)
        {
            return Result.Failure<object?>(
                new Error("Join.ExecutionFailed", ex.Message));
        }
    }
    
    private IEnumerable<dynamic> PerformInnerJoin(
        IEnumerable<dynamic> left,
        IEnumerable<dynamic> right,
        string leftKey,
        string rightKey)
    {
        // Implementation of inner join
        // Using LINQ or custom logic
        return new List<dynamic>();
    }
    
    private IEnumerable<dynamic> PerformLeftJoin(
        IEnumerable<dynamic> left,
        IEnumerable<dynamic> right,
        string leftKey,
        string rightKey)
    {
        return new List<dynamic>();
    }
    
    private IEnumerable<dynamic> PerformRightJoin(
        IEnumerable<dynamic> left,
        IEnumerable<dynamic> right,
        string leftKey,
        string rightKey)
    {
        return new List<dynamic>();
    }
    
    private IEnumerable<dynamic> PerformFullJoin(
        IEnumerable<dynamic> left,
        IEnumerable<dynamic> right,
        string leftKey,
        string rightKey)
    {
        return new List<dynamic>();
    }
    
    public async Task<r> ValidateAsync(Node node)
    {
        return await Task.FromResult(Result.Success());
    }
}
```

### ETLway Template

```csharp
// Integrations/ETLway/Templates/ETLPipelineTemplate.cs
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;
using BahyWay.KGEditorWay.Infrastructure.AGE.Templates;

namespace BahyWay.KGEditorWay.Integrations.ETLway.Templates;

public class ETLPipelineTemplate : IGraphTemplate
{
    public string Name => "ETL Pipeline";
    public string Description => "Standard Extract-Transform-Load data pipeline";
    public string Icon => "🔄";
    
    public async Task<Result<Graph>> GenerateAsync()
    {
        var graph = Graph.Create("ETL Pipeline", GraphType.Process);
        
        // Extract - CSV Source
        var csvSource = graph.AddNode("Source Data", 
            ETLwayNodeTypes.CsvSource, 
            Position.Create(100, 100));
        csvSource.Value.SetProperty("FilePath", "data/input.csv");
        csvSource.Value.SetProperty("Delimiter", ",");
        csvSource.Value.SetProperty("HasHeader", true);
        
        // Transform - Clean Data
        var cleanse = graph.AddNode("Clean Data", 
            ETLwayNodeTypes.CleanseData, 
            Position.Create(300, 100));
        
        // Transform - Filter
        var filter = graph.AddNode("Filter Rows", 
            ETLwayNodeTypes.FilterRows, 
            Position.Create(500, 100));
        filter.Value.SetProperty("Condition", "Amount > 1000");
        
        // Load - Database Sink
        var dbSink = graph.AddNode("Load to Database", 
            ETLwayNodeTypes.SqlServerSink, 
            Position.Create(700, 100));
        dbSink.Value.SetProperty("ConnectionString", 
            "Server=localhost;Database=MyDB;Trusted_Connection=True;");
        dbSink.Value.SetProperty("TableName", "SalesData");
        
        // Create connections
        graph.CreateEdge(csvSource.Value.Id, null, cleanse.Value.Id, null, EdgeType.DataFlow);
        graph.CreateEdge(cleanse.Value.Id, null, filter.Value.Id, null, EdgeType.DataFlow);
        graph.CreateEdge(filter.Value.Id, null, dbSink.Value.Id, null, EdgeType.DataFlow);
        
        return await Task.FromResult(Result.Success(graph));
    }
    
    public async Task<r> ApplyToGraphAsync(Graph graph)
    {
        return await Task.FromResult(Result.Success());
    }
}
```

---

## 2️⃣ SSISight Integration

### Overview
Visualize and analyze SSIS packages as graphs.

### SSISPackageImporter.cs

```csharp
// Integrations/SSISight/SSISPackageImporter.cs
using System;
using System.Threading.Tasks;
using System.Xml.Linq;
using BahyWay.SharedKernel.Results;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.KGEditorWay.Integrations.SSISight;

public interface ISSISPackageImporter
{
    Task<Result<Graph>> ImportPackageAsync(string dtsx FilePath);
    Task<Result<Graph>> ImportFromSqlServerAsync(string serverName, string packagePath);
}

public class SSISPackageImporter : ISSISPackageImporter
{
    public async Task<Result<Graph>> ImportPackageAsync(string dtsxFilePath)
    {
        try
        {
            var xml = await File.ReadAllTextAsync(dtsxFilePath);
            var doc = XDocument.Parse(xml);
            
            var graph = Graph.Create(
                Path.GetFileNameWithoutExtension(dtsxFilePath), 
                GraphType.Process);
            
            // Parse SSIS package XML
            var ns = doc.Root?.Name.Namespace ?? XNamespace.None;
            
            // Extract executables (tasks)
            var executables = doc.Descendants(ns + "Executable");
            
            var nodePositionY = 100;
            var nodePositionX = 100;
            
            foreach (var executable in executables)
            {
                var taskName = executable.Attribute("Name")?.Value ?? "Unknown";
                var taskType = executable.Attribute("ExecutableType")?.Value ?? "Unknown";
                
                var nodeType = MapSSISTaskToNodeType(taskType);
                
                var node = graph.AddNode(taskName, nodeType, 
                    Position.Create(nodePositionX, nodePositionY));
                
                // Extract properties
                var properties = executable.Descendants(ns + "Property");
                foreach (var prop in properties)
                {
                    var propName = prop.Attribute("Name")?.Value;
                    var propValue = prop.Value;
                    
                    if (!string.IsNullOrEmpty(propName))
                    {
                        node.Value.SetProperty(propName, propValue);
                    }
                }
                
                nodePositionX += 200;
                if (nodePositionX > 1000)
                {
                    nodePositionX = 100;
                    nodePositionY += 200;
                }
            }
            
            // Extract precedence constraints (connections)
            var constraints = doc.Descendants(ns + "PrecedenceConstraint");
            
            foreach (var constraint in constraints)
            {
                var fromId = constraint.Attribute("From")?.Value;
                var toId = constraint.Attribute("To")?.Value;
                
                // Find nodes by SSIS IDs and create edges
                // TODO: Map SSIS IDs to graph node IDs
            }
            
            return Result.Success(graph);
        }
        catch (Exception ex)
        {
            return Result.Failure<Graph>(
                new Error("SSIS.ImportFailed", ex.Message));
        }
    }
    
    public async Task<Result<Graph>> ImportFromSqlServerAsync(
        string serverName,
        string packagePath)
    {
        // TODO: Connect to SQL Server and retrieve SSIS package
        return await Task.FromResult(Result.Failure<Graph>(
            new Error("SSIS.NotImplemented", "SQL Server import not yet implemented")));
    }
    
    private NodeType MapSSISTaskToNodeType(string ssisTaskType)
    {
        return ssisTaskType switch
        {
            "Microsoft.DataTransformationServices.Tasks.ExecuteSQLTask" 
                => new NodeType(500, "ExecuteSQL", "🗄️", "#336791"),
            "Microsoft.DataTransformationServices.Tasks.DataFlowTask" 
                => new NodeType(501, "DataFlow", "🔄", "#2196F3"),
            "Microsoft.DataTransformationServices.Tasks.FileSystemTask" 
                => new NodeType(502, "FileSystem", "📁", "#4CAF50"),
            "Microsoft.DataTransformationServices.Tasks.ScriptTask" 
                => new NodeType(503, "Script", "💻", "#9C27B0"),
            _ => NodeType.Source
        };
    }
}
```

### SSISAnalyzer.cs

```csharp
// Integrations/SSISight/SSISAnalyzer.cs
public class SSISAnalyzer
{
    public async Task<Result<SSISAnalysisReport>> AnalyzePackageAsync(Graph ssisGraph)
    {
        var report = new SSISAnalysisReport
        {
            PackageName = ssisGraph.Name,
            TotalTasks = ssisGraph.Nodes.Count,
            TotalConnections = ssisGraph.Edges.Count
        };
        
        // Complexity analysis
        report.ComplexityScore = CalculateComplexity(ssisGraph);
        
        // Performance bottlenecks
        report.PotentialBottlenecks = IdentifyBottlenecks(ssisGraph);
        
        // Dependency analysis
        report.DependencyChains = AnalyzeDependencies(ssisGraph);
        
        // Best practice violations
        report.BestPracticeViolations = CheckBestPractices(ssisGraph);
        
        return await Task.FromResult(Result.Success(report));
    }
    
    private int CalculateComplexity(Graph graph)
    {
        // McCabe cyclomatic complexity or custom metric
        return graph.Nodes.Count + graph.Edges.Count;
    }
    
    private List<string> IdentifyBottlenecks(Graph graph)
    {
        var bottlenecks = new List<string>();
        
        // Identify nodes with high fan-in or fan-out
        foreach (var node in graph.Nodes)
        {
            var incomingEdges = graph.Edges.Count(e => e.TargetNodeId == node.Id);
            var outgoingEdges = graph.Edges.Count(e => e.SourceNodeId == node.Id);
            
            if (incomingEdges > 5 || outgoingEdges > 5)
            {
                bottlenecks.Add($"Node '{node.Name}' has high connection count");
            }
        }
        
        return bottlenecks;
    }
    
    private List<string> AnalyzeDependencies(Graph graph)
    {
        // Analyze dependency chains
        return new List<string>();
    }
    
    private List<string> CheckBestPractices(Graph graph)
    {
        var violations = new List<string>();
        
        // Check for common SSIS anti-patterns
        // - Overuse of Execute SQL tasks
        // - Missing error handling
        // - Inefficient data flow paths
        
        return violations;
    }
}

public class SSISAnalysisReport
{
    public string PackageName { get; set; } = "";
    public int TotalTasks { get; set; }
    public int TotalConnections { get; set; }
    public int ComplexityScore { get; set; }
    public List<string> PotentialBottlenecks { get; set; } = new();
    public List<string> DependencyChains { get; set; } = new();
    public List<string> BestPracticeViolations { get; set; } = new();
}
```

---

## 3️⃣ AlarmInsight Integration

### Overview
Visualize alarm processing rules and dependencies.

### AlarmRuleGraphBuilder.cs

```csharp
// Integrations/AlarmInsight/AlarmRuleGraphBuilder.cs
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;
using BahyWay.AlarmManagement.Domain.Aggregates;

namespace BahyWay.KGEditorWay.Integrations.AlarmInsight;

public class AlarmRuleGraphBuilder
{
    public async Task<Result<Graph>> BuildAlarmRuleGraphAsync(
        IEnumerable<Alarm> alarms,
        IEnumerable<Asset> assets)
    {
        var graph = Graph.Create("Alarm Rules", GraphType.Knowledge);
        
        // Create asset nodes
        var assetNodes = new Dictionary<AssetId, Node>();
        
        foreach (var asset in assets)
        {
            var node = graph.AddNode(
                asset.Name,
                new NodeType(600, "Asset", "🏭", "#2196F3"),
                Position.Create(0, 0)); // Auto-layout later
            
            node.Value.SetProperty("AssetType", asset.Type);
            node.Value.SetProperty("Location", asset.Location.ToString());
            
            assetNodes[asset.Id] = node.Value;
        }
        
        // Create alarm nodes and connections
        foreach (var alarm in alarms)
        {
            var alarmNode = graph.AddNode(
                alarm.Name,
                new NodeType(601, "Alarm", "🚨", "#F44336"),
                Position.Create(0, 0));
            
            alarmNode.Value.SetProperty("Severity", alarm.Severity.Name);
            alarmNode.Value.SetProperty("Status", alarm.Status.Name);
            alarmNode.Value.SetProperty("ThresholdMin", alarm.Threshold.Min);
            alarmNode.Value.SetProperty("ThresholdMax", alarm.Threshold.Max);
            
            // Connect to asset
            if (assetNodes.TryGetValue(alarm.AssetId, out var assetNode))
            {
                graph.CreateEdge(
                    alarmNode.Value.Id, null,
                    assetNode.Id, null,
                    new EdgeType(1, "monitors", "#FF9800"));
            }
        }
        
        // Apply auto-layout
        await ApplyAutoLayoutAsync(graph);
        
        return Result.Success(graph);
    }
    
    private async Task ApplyAutoLayoutAsync(Graph graph)
    {
        // Implement hierarchical or force-directed layout
        // Position nodes automatically
        await Task.CompletedTask;
    }
}
```

---

## 4️⃣ SteerView Integration

### Overview
Visualize geospatial relationships and workflows.

### GeoWorkflowBuilder.cs

```csharp
// Integrations/SteerView/GeoWorkflowBuilder.cs
public class GeoWorkflowBuilder
{
    public async Task<Result<Graph>> BuildGeoWorkflowAsync()
    {
        var graph = Graph.Create("Geo Workflow", GraphType.Process);
        
        // GeoJSON Source
        var geoSource = graph.AddNode("GeoJSON Source",
            new NodeType(700, "GeoJsonSource", "🗺️", "#4CAF50"),
            Position.Create(100, 100));
        
        // Buffer operation
        var buffer = graph.AddNode("Buffer",
            new NodeType(701, "Buffer", "⭕", "#2196F3"),
            Position.Create(300, 100));
        buffer.Value.SetProperty("Distance", 100);
        buffer.Value.SetProperty("Unit", "meters");
        
        // Intersect operation
        var intersect = graph.AddNode("Intersect",
            new NodeType(702, "Intersect", "✂️", "#2196F3"),
            Position.Create(500, 100));
        
        // Map output
        var mapOutput = graph.AddNode("Map Display",
            new NodeType(703, "MapOutput", "🗺️", "#F44336"),
            Position.Create(700, 100));
        
        // Create workflow
        graph.CreateEdge(geoSource.Value.Id, null, buffer.Value.Id, null, EdgeType.DataFlow);
        graph.CreateEdge(buffer.Value.Id, null, intersect.Value.Id, null, EdgeType.DataFlow);
        graph.CreateEdge(intersect.Value.Id, null, mapOutput.Value.Id, null, EdgeType.DataFlow);
        
        return await Task.FromResult(Result.Success(graph));
    }
}
```

---

**Part 7 continues with complete integration examples and deployment...**

**Continue to Part 7B: Complete Integration Examples?**
