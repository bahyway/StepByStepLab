# SimulateWay.Unity - Part 2: UI, VR, WebGL & Deployment

## 🎮 Interactive UI Controls

### Timeline UI Controller

```csharp
// Assets/Scripts/UI/TimelineUI.cs
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace BahyWay.SimulateWay.Unity.UI
{
    public class TimelineUI : MonoBehaviour
    {
        [Header("UI Components")]
        public Button playButton;
        public Button pauseButton;
        public Button resetButton;
        public Button stepForwardButton;
        public Button stepBackButton;
        public Slider timelineSlider;
        public TextMeshProUGUI currentTimeText;
        public TextMeshProUGUI totalTimeText;
        public Dropdown speedDropdown;
        
        [Header("Icons")]
        public Sprite playIcon;
        public Sprite pauseIcon;
        
        private SimulationEngine simulationEngine;
        private bool isPlaying = false;
        
        void Start()
        {
            simulationEngine = FindObjectOfType<SimulationEngine>();
            SetupUI();
        }
        
        void SetupUI()
        {
            // Play/Pause button
            playButton.onClick.AddListener(TogglePlayPause);
            
            // Reset button
            resetButton.onClick.AddListener(() =>
            {
                simulationEngine.Reset();
                UpdateUI();
            });
            
            // Step buttons
            stepForwardButton.onClick.AddListener(() =>
            {
                simulationEngine.StepForward();
                UpdateUI();
            });
            
            stepBackButton.onClick.AddListener(() =>
            {
                simulationEngine.StepBack();
                UpdateUI();
            });
            
            // Timeline slider
            timelineSlider.onValueChanged.AddListener(OnTimelineChanged);
            
            // Speed dropdown
            speedDropdown.onValueChanged.AddListener(OnSpeedChanged);
        }
        
        void TogglePlayPause()
        {
            if (isPlaying)
            {
                simulationEngine.Pause();
                playButton.GetComponent<Image>().sprite = playIcon;
                isPlaying = false;
            }
            else
            {
                simulationEngine.Play();
                playButton.GetComponent<Image>().sprite = pauseIcon;
                isPlaying = true;
            }
        }
        
        void OnTimelineChanged(float value)
        {
            // Seek to specific time
            simulationEngine.SeekToTime(value);
            UpdateUI();
        }
        
        void OnSpeedChanged(int index)
        {
            float speed = index switch
            {
                0 => 0.25f,
                1 => 0.5f,
                2 => 1f,
                3 => 1.5f,
                4 => 2f,
                _ => 1f
            };
            
            simulationEngine.SetSpeed(speed);
        }
        
        void Update()
        {
            UpdateUI();
        }
        
        void UpdateUI()
        {
            // Update timeline slider
            timelineSlider.value = simulationEngine.GetProgress();
            
            // Update time text
            float currentTime = simulationEngine.GetCurrentTime();
            float totalTime = simulationEngine.GetTotalDuration();
            
            currentTimeText.text = FormatTime(currentTime);
            totalTimeText.text = FormatTime(totalTime);
        }
        
        string FormatTime(float seconds)
        {
            int minutes = Mathf.FloorToInt(seconds / 60f);
            int secs = Mathf.FloorToInt(seconds % 60f);
            return $"{minutes:00}:{secs:00}";
        }
    }
}
```

### Details Panel

```csharp
// Assets/Scripts/Interaction/DetailsPanel.cs
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace BahyWay.SimulateWay.Unity.Interaction
{
    public class DetailsPanel : MonoBehaviour
    {
        [Header("UI Components")]
        public GameObject panelRoot;
        public TextMeshProUGUI nodeTitleText;
        public TextMeshProUGUI nodeTypeText;
        public TextMeshProUGUI nodeIdText;
        public Transform propertiesContainer;
        public GameObject propertyRowPrefab;
        public Button closeButton;
        
        private NodeRenderer currentNode;
        
        void Start()
        {
            closeButton.onClick.AddListener(HidePanel);
            HidePanel();
        }
        
        public void ShowNodeDetails(NodeRenderer node)
        {
            currentNode = node;
            
            // Set basic info
            nodeTitleText.text = node.nodeName;
            nodeTypeText.text = node.nodeType;
            nodeIdText.text = node.nodeId;
            
            // Clear existing properties
            foreach (Transform child in propertiesContainer)
            {
                Destroy(child.gameObject);
            }
            
            // Add properties
            // This would come from the node's data
            AddProperty("Status", "Active");
            AddProperty("Last Updated", System.DateTime.Now.ToString("HH:mm:ss"));
            
            panelRoot.SetActive(true);
        }
        
        void AddProperty(string key, string value)
        {
            GameObject row = Instantiate(propertyRowPrefab, propertiesContainer);
            
            var keyText = row.transform.Find("Key").GetComponent<TextMeshProUGUI>();
            var valueText = row.transform.Find("Value").GetComponent<TextMeshProUGUI>();
            
            keyText.text = key;
            valueText.text = value;
        }
        
        public void HidePanel()
        {
            panelRoot.SetActive(false);
            currentNode = null;
        }
    }
}
```

---

## 📷 Camera Controls

### Orbit Camera Controller

```csharp
// Assets/Scripts/Visualization/CameraController.cs
using UnityEngine;

namespace BahyWay.SimulateWay.Unity.Visualization
{
    public class CameraController : MonoBehaviour
    {
        [Header("Target")]
        public Transform target;
        
        [Header("Orbit Settings")]
        public float orbitSpeed = 100f;
        public float zoomSpeed = 10f;
        public float panSpeed = 0.5f;
        
        [Header("Limits")]
        public float minDistance = 5f;
        public float maxDistance = 50f;
        public float minVerticalAngle = 10f;
        public float maxVerticalAngle = 80f;
        
        private float currentDistance = 15f;
        private float currentHorizontalAngle = 0f;
        private float currentVerticalAngle = 30f;
        
        private Vector3 targetOffset = Vector3.zero;
        
        void Start()
        {
            if (target == null)
            {
                // Create empty target at origin
                GameObject targetObj = new GameObject("CameraTarget");
                target = targetObj.transform;
                target.position = Vector3.zero;
            }
            
            UpdateCameraPosition();
        }
        
        void LateUpdate()
        {
            HandleInput();
            UpdateCameraPosition();
        }
        
        void HandleInput()
        {
            // Orbit with right mouse button
            if (Input.GetMouseButton(1))
            {
                float horizontalInput = Input.GetAxis("Mouse X");
                float verticalInput = Input.GetAxis("Mouse Y");
                
                currentHorizontalAngle += horizontalInput * orbitSpeed * Time.deltaTime;
                currentVerticalAngle -= verticalInput * orbitSpeed * Time.deltaTime;
                
                // Clamp vertical angle
                currentVerticalAngle = Mathf.Clamp(
                    currentVerticalAngle,
                    minVerticalAngle,
                    maxVerticalAngle);
            }
            
            // Pan with middle mouse button
            if (Input.GetMouseButton(2))
            {
                float horizontalInput = Input.GetAxis("Mouse X");
                float verticalInput = Input.GetAxis("Mouse Y");
                
                Vector3 right = transform.right;
                Vector3 up = transform.up;
                
                targetOffset -= (right * horizontalInput + up * verticalInput) * panSpeed;
            }
            
            // Zoom with mouse wheel
            float scrollInput = Input.GetAxis("Mouse ScrollWheel");
            if (Mathf.Abs(scrollInput) > 0.01f)
            {
                currentDistance -= scrollInput * zoomSpeed;
                currentDistance = Mathf.Clamp(currentDistance, minDistance, maxDistance);
            }
            
            // Reset view with 'R' key
            if (Input.GetKeyDown(KeyCode.R))
            {
                ResetCamera();
            }
            
            // Focus on selected node with 'F' key
            if (Input.GetKeyDown(KeyCode.F))
            {
                FocusOnSelection();
            }
        }
        
        void UpdateCameraPosition()
        {
            // Calculate position based on angles and distance
            Quaternion rotation = Quaternion.Euler(currentVerticalAngle, currentHorizontalAngle, 0);
            Vector3 offset = rotation * Vector3.back * currentDistance;
            
            Vector3 targetPosition = target.position + targetOffset;
            transform.position = targetPosition + offset;
            transform.LookAt(targetPosition);
        }
        
        public void ResetCamera()
        {
            currentDistance = 15f;
            currentHorizontalAngle = 0f;
            currentVerticalAngle = 30f;
            targetOffset = Vector3.zero;
        }
        
        public void FocusOnSelection()
        {
            // Find selected node
            var selectedNode = FindObjectOfType<NodeRenderer>();
            if (selectedNode != null)
            {
                FocusOnTarget(selectedNode.transform.position);
            }
        }
        
        public void FocusOnTarget(Vector3 position)
        {
            // Smooth transition to target
            LeanTween.value(gameObject, targetOffset, position - target.position, 0.5f)
                .setOnUpdate((Vector3 val) =>
                {
                    targetOffset = val;
                })
                .setEase(LeanTweenType.easeInOutCubic);
        }
    }
}
```

---

## 🥽 VR Support

### VR Interaction Manager

```csharp
// Assets/Scripts/VR/VRInteractionManager.cs
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;

namespace BahyWay.SimulateWay.Unity.VR
{
    public class VRInteractionManager : MonoBehaviour
    {
        [Header("XR Components")]
        public XRRayInteractor rightHandRay;
        public XRRayInteractor leftHandRay;
        public XRInteractionManager interactionManager;
        
        [Header("Teleport Settings")]
        public TeleportationProvider teleportProvider;
        public float teleportCooldown = 1f;
        
        [Header("UI")]
        public GameObject vrUICanvas;
        
        private float lastTeleportTime;
        
        void Start()
        {
            SetupVRInteractions();
        }
        
        void SetupVRInteractions()
        {
            // Setup ray interactors
            if (rightHandRay != null)
            {
                rightHandRay.selectEntered.AddListener(OnNodeSelected);
            }
            
            if (leftHandRay != null)
            {
                leftHandRay.selectEntered.AddListener(OnNodeSelected);
            }
        }
        
        void OnNodeSelected(SelectEnterEventArgs args)
        {
            var nodeRenderer = args.interactableObject.transform.GetComponent<NodeRenderer>();
            
            if (nodeRenderer != null)
            {
                // Show details in VR UI
                ShowVRNodeDetails(nodeRenderer);
                
                // Haptic feedback
                SendHapticFeedback(args.interactorObject);
            }
        }
        
        void ShowVRNodeDetails(NodeRenderer node)
        {
            // Position VR UI canvas near the node
            if (vrUICanvas != null)
            {
                vrUICanvas.transform.position = node.transform.position + Vector3.up * 2f;
                vrUICanvas.transform.LookAt(Camera.main.transform);
                
                var detailsPanel = vrUICanvas.GetComponentInChildren<DetailsPanel>();
                if (detailsPanel != null)
                {
                    detailsPanel.ShowNodeDetails(node);
                }
            }
        }
        
        void SendHapticFeedback(IXRInteractor interactor)
        {
            if (interactor is XRBaseControllerInteractor controller)
            {
                controller.SendHapticImpulse(0.5f, 0.2f);
            }
        }
        
        void Update()
        {
            // Handle VR-specific input
            HandleVRInput();
        }
        
        void HandleVRInput()
        {
            // Teleport with trigger
            if (Input.GetButton("XRI_Right_Trigger") && 
                Time.time - lastTeleportTime > teleportCooldown)
            {
                // Teleport handled by TeleportationProvider
                lastTeleportTime = Time.time;
            }
            
            // Reset view with grip button
            if (Input.GetButtonDown("XRI_Right_Grip"))
            {
                ResetVRView();
            }
        }
        
        void ResetVRView()
        {
            // Reset to center of workflow
            var simulationEngine = FindObjectOfType<SimulationEngine>();
            if (simulationEngine != null)
            {
                Vector3 center = CalculateGraphCenter();
                transform.position = center - transform.forward * 5f;
            }
        }
        
        Vector3 CalculateGraphCenter()
        {
            var nodes = FindObjectsOfType<NodeRenderer>();
            if (nodes.Length == 0)
                return Vector3.zero;
            
            Vector3 sum = Vector3.zero;
            foreach (var node in nodes)
            {
                sum += node.transform.position;
            }
            
            return sum / nodes.Length;
        }
    }
}
```

---

## 🌐 WebGL Export Configuration

### WebGL Template (index.html)

```html
<!-- Assets/WebGLTemplates/BahyWay/index.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>BahyWay Workflow Simulator</title>
    <style>
        * { margin: 0; padding: 0; }
        html, body { 
            width: 100%; 
            height: 100%; 
            background: #1e1e1e;
            overflow: hidden;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        #unity-container {
            width: 100%;
            height: 100%;
            position: relative;
        }
        
        #unity-canvas {
            width: 100%;
            height: 100%;
            background: #1e1e1e;
        }
        
        #loading-cover {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: #1e1e1e;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        
        #loading-cover.hidden {
            display: none;
        }
        
        .loader {
            border: 8px solid #3e3e42;
            border-top: 8px solid #4ec9b0;
            border-radius: 50%;
            width: 60px;
            height: 60px;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        #loading-text {
            color: #cccccc;
            margin-top: 20px;
            font-size: 18px;
        }
        
        #unity-progress-bar-full {
            width: 300px;
            height: 4px;
            background: #3e3e42;
            margin-top: 10px;
            border-radius: 2px;
            overflow: hidden;
        }
        
        #unity-progress-bar-empty {
            width: 0%;
            height: 100%;
            background: #4ec9b0;
            transition: width 0.3s;
        }
        
        #header {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            background: rgba(30, 30, 30, 0.9);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 100;
        }
        
        #header h1 {
            color: #4ec9b0;
            font-size: 24px;
            margin: 0;
        }
        
        .button {
            background: #4ec9b0;
            color: #1e1e1e;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
        }
        
        .button:hover {
            background: #6fd9c0;
        }
    </style>
</head>
<body>
    <div id="unity-container">
        <!-- Header -->
        <div id="header">
            <h1>🎬 BahyWay Workflow Simulator</h1>
            <div>
                <button class="button" onclick="ToggleFullscreen()">Fullscreen</button>
                <button class="button" onclick="ResetSimulation()">Reset</button>
            </div>
        </div>
        
        <!-- Unity Canvas -->
        <canvas id="unity-canvas" tabindex="1"></canvas>
        
        <!-- Loading Screen -->
        <div id="loading-cover">
            <div class="loader"></div>
            <div id="loading-text">Loading Workflow Simulator...</div>
            <div id="unity-progress-bar-full">
                <div id="unity-progress-bar-empty"></div>
            </div>
        </div>
    </div>
    
    <script>
        var canvas = document.querySelector("#unity-canvas");
        var loadingCover = document.querySelector("#loading-cover");
        var progressBarEmpty = document.querySelector("#unity-progress-bar-empty");
        var loadingText = document.querySelector("#loading-text");
        
        var buildUrl = "Build";
        var loaderUrl = buildUrl + "/{{{ LOADER_FILENAME }}}";
        var config = {
            dataUrl: buildUrl + "/{{{ DATA_FILENAME }}}",
            frameworkUrl: buildUrl + "/{{{ FRAMEWORK_FILENAME }}}",
            codeUrl: buildUrl + "/{{{ CODE_FILENAME }}}",
            streamingAssetsUrl: "StreamingAssets",
            companyName: "BahyWay",
            productName: "SimulateWay",
            productVersion: "1.0.0",
        };
        
        var script = document.createElement("script");
        script.src = loaderUrl;
        script.onload = () => {
            createUnityInstance(canvas, config, (progress) => {
                progressBarEmpty.style.width = (100 * progress) + "%";
                loadingText.textContent = `Loading... ${Math.round(progress * 100)}%`;
            }).then((unityInstance) => {
                window.unityInstance = unityInstance;
                loadingCover.classList.add('hidden');
                canvas.focus();
            }).catch((message) => {
                alert("Failed to load: " + message);
            });
        };
        document.body.appendChild(script);
        
        function ToggleFullscreen() {
            if (!document.fullscreenElement) {
                canvas.requestFullscreen();
            } else {
                document.exitFullscreen();
            }
        }
        
        function ResetSimulation() {
            if (window.unityInstance) {
                window.unityInstance.SendMessage('SimulationEngine', 'Reset');
            }
        }
        
        // Communication from Unity
        function OnSimulationLoaded(graphName) {
            console.log("Loaded graph:", graphName);
        }
        
        function OnSimulationComplete() {
            console.log("Simulation complete");
        }
    </script>
</body>
</html>
```

### Build Script

```csharp
// Assets/Editor/WebGLBuilder.cs
using UnityEditor;
using UnityEngine;

namespace BahyWay.SimulateWay.Unity.Editor
{
    public class WebGLBuilder
    {
        [MenuItem("BahyWay/Build WebGL")]
        public static void BuildWebGL()
        {
            string[] scenes = new string[] { 
                "Assets/Scenes/WorkflowSimulator.unity" 
            };
            
            BuildPlayerOptions buildOptions = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = "Builds/WebGL",
                target = BuildTarget.WebGL,
                options = BuildOptions.None
            };
            
            // Set WebGL template
            PlayerSettings.WebGL.template = "PROJECT:BahyWay";
            
            // Optimize for size
            PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Brotli;
            PlayerSettings.WebGL.decompressionFallback = true;
            
            // Build
            BuildReport report = BuildPipeline.BuildPlayer(buildOptions);
            
            if (report.summary.result == BuildResult.Succeeded)
            {
                Debug.Log($"Build succeeded: {report.summary.totalSize} bytes");
                EditorUtility.RevealInFinder("Builds/WebGL");
            }
            else
            {
                Debug.LogError("Build failed");
            }
        }
    }
}
```

---

## 🔗 Complete Integration Example

### BahyWay REST API Client

```csharp
// Assets/Scripts/Integration/BahyWayClient.cs
using UnityEngine;
using UnityEngine.Networking;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace BahyWay.SimulateWay.Unity.Integration
{
    public class BahyWayClient : MonoBehaviour
    {
        [Header("API Configuration")]
        public string apiBaseUrl = "http://localhost:5000/api";
        public string apiKey = "";
        
        public async Task<GraphData> LoadGraphFromAPIAsync(string graphId)
        {
            string url = $"{apiBaseUrl}/graphs/{graphId}";
            
            using (UnityWebRequest request = UnityWebRequest.Get(url))
            {
                // Add auth header
                if (!string.IsNullOrEmpty(apiKey))
                {
                    request.SetRequestHeader("Authorization", $"Bearer {apiKey}");
                }
                
                await request.SendWebRequest();
                
                if (request.result != UnityWebRequest.Result.Success)
                {
                    Debug.LogError($"API Error: {request.error}");
                    return null;
                }
                
                string json = request.downloadHandler.text;
                return JsonConvert.DeserializeObject<GraphData>(json);
            }
        }
        
        public async Task<AnimationData> LoadAnimationFromAPIAsync(string animationId)
        {
            string url = $"{apiBaseUrl}/animations/{animationId}";
            
            using (UnityWebRequest request = UnityWebRequest.Get(url))
            {
                if (!string.IsNullOrEmpty(apiKey))
                {
                    request.SetRequestHeader("Authorization", $"Bearer {apiKey}");
                }
                
                await request.SendWebRequest();
                
                if (request.result != UnityWebRequest.Result.Success)
                {
                    Debug.LogError($"API Error: {request.error}");
                    return null;
                }
                
                string json = request.downloadHandler.text;
                return JsonConvert.DeserializeObject<AnimationData>(json);
            }
        }
    }
    
    [System.Serializable]
    public class AnimationData
    {
        public string Id;
        public string Name;
        public string GraphId;
        public List<AnimationScene> Scenes;
        public float TotalDuration;
    }
    
    [System.Serializable]
    public class AnimationScene
    {
        public string Name;
        public float Duration;
        public string Narration;
        public List<string> HighlightedNodes;
        public List<DataFlowDefinition> DataFlows;
    }
    
    [System.Serializable]
    public class DataFlowDefinition
    {
        public string EdgeId;
        public string SourceNodeId;
        public string TargetNodeId;
        public string Color;
        public int ParticleCount;
    }
}
```

---

**Continue to Part 3: Deployment, Performance, and Complete Examples?**
