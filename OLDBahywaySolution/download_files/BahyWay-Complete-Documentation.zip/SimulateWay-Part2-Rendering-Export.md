# SimulateWay - Part 2: Rendering Engine & Export

## 🎨 Rendering Infrastructure

### IAnimationRenderer.cs

```csharp
// Infrastructure/Rendering/IAnimationRenderer.cs
using System.Threading;
using System.Threading.Tasks;
using SkiaSharp;
using BahyWay.SharedKernel.Results;

namespace BahyWay.SimulateWay.Infrastructure.Rendering;

public interface IAnimationRenderer
{
    Task<Result<SKBitmap>> RenderFrameAsync(
        Animation animation,
        Duration currentTime,
        CancellationToken cancellationToken = default);
    
    Task<Result<List<SKBitmap>>> RenderAllFramesAsync(
        Animation animation,
        CancellationToken cancellationToken = default);
}
```

### SkiaSharpRenderer.cs

```csharp
// Infrastructure/Rendering/SkiaSharpRenderer.cs
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using SkiaSharp;
using BahyWay.SharedKernel.Results;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.SimulateWay.Infrastructure.Rendering;

public class SkiaSharpRenderer : IAnimationRenderer
{
    private readonly IGraphService _graphService;
    private readonly IEffectRendererFactory _effectRendererFactory;
    
    public SkiaSharpRenderer(
        IGraphService graphService,
        IEffectRendererFactory effectRendererFactory)
    {
        _graphService = graphService;
        _effectRendererFactory = effectRendererFactory;
    }
    
    public async Task<Result<SKBitmap>> RenderFrameAsync(
        Animation animation,
        Duration currentTime,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var settings = animation.Settings;
            var bitmap = new SKBitmap(settings.Width, settings.Height);
            
            using var canvas = new SKCanvas(bitmap);
            
            // Clear background
            canvas.Clear(ToSkColor(settings.BackgroundColor));
            
            // Get current scene
            var sceneResult = animation.GetSceneAtTime(currentTime);
            if (sceneResult.IsFailure)
                return Result.Failure<SKBitmap>(sceneResult.Error);
            
            var scene = sceneResult.Value;
            
            // Load source graph
            var graph = await _graphService.LoadGraphAsync(animation.SourceGraphId);
            if (graph == null)
            {
                return Result.Failure<SKBitmap>(
                    new Error("Renderer.GraphNotFound", "Source graph not found"));
            }
            
            // Render graph elements
            await RenderGraphAsync(canvas, graph, scene, currentTime);
            
            // Apply effects
            await RenderEffectsAsync(canvas, scene, currentTime);
            
            // Render narration text
            if (!string.IsNullOrEmpty(scene.Narration))
            {
                RenderNarration(canvas, scene.Narration, settings);
            }
            
            // Render timestamp if enabled
            if (settings.ShowTimestamps)
            {
                RenderTimestamp(canvas, currentTime, settings);
            }
            
            return Result.Success(bitmap);
        }
        catch (Exception ex)
        {
            return Result.Failure<SKBitmap>(
                new Error("Renderer.Failed", ex.Message));
        }
    }
    
    public async Task<Result<List<SKBitmap>>> RenderAllFramesAsync(
        Animation animation,
        CancellationToken cancellationToken = default)
    {
        var frames = new List<SKBitmap>();
        var frameRate = animation.Settings.FrameRate;
        var totalFrames = (int)(animation.TotalDuration.TotalSeconds * frameRate);
        
        for (int i = 0; i < totalFrames; i++)
        {
            if (cancellationToken.IsCancellationRequested)
                break;
            
            var time = Duration.FromSeconds(i / (double)frameRate);
            var frameResult = await RenderFrameAsync(animation, time, cancellationToken);
            
            if (frameResult.IsFailure)
                return Result.Failure<List<SKBitmap>>(frameResult.Error);
            
            frames.Add(frameResult.Value);
        }
        
        return Result.Success(frames);
    }
    
    private async Task RenderGraphAsync(
        SKCanvas canvas,
        Graph graph,
        Scene scene,
        Duration currentTime)
    {
        // Render edges first (behind nodes)
        foreach (var edge in graph.Edges)
        {
            var element = scene.Elements.FirstOrDefault(e => 
                e.ElementId == edge.Id.Value.ToString() && 
                e.Type == ElementType.Edge);
            
            if (element == null || !element.IsVisible)
                continue;
            
            RenderEdge(canvas, edge, element);
        }
        
        // Render nodes
        foreach (var node in graph.Nodes)
        {
            var element = scene.Elements.FirstOrDefault(e => 
                e.ElementId == node.Id.Value.ToString() && 
                e.Type == ElementType.Node);
            
            if (element == null || !element.IsVisible)
                continue;
            
            RenderNode(canvas, node, element);
        }
    }
    
    private void RenderNode(SKCanvas canvas, Node node, SceneElement element)
    {
        var x = (float)node.Position.X;
        var y = (float)node.Position.Y;
        var width = (float)(node.Width ?? 120);
        var height = (float)(node.Height ?? 60);
        
        using var paint = new SKPaint
        {
            Style = SKPaintStyle.Fill,
            Color = ToSkColor(node.GetColorFromType()),
            IsAntialias = true
        };
        
        // Apply opacity
        paint.Color = paint.Color.WithAlpha((byte)(element.Opacity * 255));
        
        // Draw node shape (rounded rectangle)
        var rect = new SKRect(x, y, x + width, y + height);
        canvas.DrawRoundRect(rect, 8, 8, paint);
        
        // Draw border
        using var borderPaint = new SKPaint
        {
            Style = SKPaintStyle.Stroke,
            Color = element.IsHighlighted 
                ? SKColors.Yellow 
                : SKColors.Gray,
            StrokeWidth = element.IsHighlighted ? 3 : 1,
            IsAntialias = true
        };
        canvas.DrawRoundRect(rect, 8, 8, borderPaint);
        
        // Draw icon
        if (!string.IsNullOrEmpty(node.Type.Icon))
        {
            using var textPaint = new SKPaint
            {
                Color = SKColors.White,
                TextSize = 24,
                IsAntialias = true,
                TextAlign = SKTextAlign.Center
            };
            canvas.DrawText(node.Type.Icon, x + width / 2, y + 30, textPaint);
        }
        
        // Draw label
        using var labelPaint = new SKPaint
        {
            Color = SKColors.White,
            TextSize = 14,
            IsAntialias = true,
            TextAlign = SKTextAlign.Center
        };
        canvas.DrawText(node.Name, x + width / 2, y + height - 10, labelPaint);
    }
    
    private void RenderEdge(SKCanvas canvas, Edge edge, SceneElement element)
    {
        // Get source and target node positions from graph
        // For simplicity, assuming straight lines
        
        using var paint = new SKPaint
        {
            Style = SKPaintStyle.Stroke,
            Color = element.IsHighlighted 
                ? SKColors.Yellow 
                : SKColors.Gray,
            StrokeWidth = element.IsHighlighted ? 3 : 2,
            IsAntialias = true
        };
        
        paint.Color = paint.Color.WithAlpha((byte)(element.Opacity * 255));
        
        // Draw arrow
        // Implementation depends on edge routing algorithm
    }
    
    private async Task RenderEffectsAsync(
        SKCanvas canvas,
        Scene scene,
        Duration currentTime)
    {
        foreach (var effect in scene.Effects)
        {
            // Check if effect is active at current time
            if (currentTime < effect.StartTime || 
                currentTime > effect.StartTime.Add(effect.Duration))
                continue;
            
            var renderer = _effectRendererFactory.GetRenderer(effect.GetEffectType());
            
            if (renderer != null)
            {
                await renderer.RenderAsync(canvas, effect, currentTime);
            }
        }
    }
    
    private void RenderNarration(
        SKCanvas canvas,
        string narration,
        AnimationSettings settings)
    {
        using var paint = new SKPaint
        {
            Color = SKColors.White,
            TextSize = 18,
            IsAntialias = true,
            TextAlign = SKTextAlign.Left
        };
        
        // Draw background box
        var textBounds = new SKRect();
        paint.MeasureText(narration, ref textBounds);
        
        var padding = 20f;
        var boxRect = new SKRect(
            padding,
            settings.Height - textBounds.Height - padding * 2,
            textBounds.Width + padding * 3,
            settings.Height - padding);
        
        using var bgPaint = new SKPaint
        {
            Color = new SKColor(0, 0, 0, 180),
            Style = SKPaintStyle.Fill
        };
        canvas.DrawRoundRect(boxRect, 8, 8, bgPaint);
        
        // Draw text
        canvas.DrawText(
            narration,
            padding * 1.5f,
            settings.Height - padding * 1.5f,
            paint);
    }
    
    private void RenderTimestamp(
        SKCanvas canvas,
        Duration currentTime,
        AnimationSettings settings)
    {
        using var paint = new SKPaint
        {
            Color = new SKColor(255, 255, 255, 180),
            TextSize = 14,
            IsAntialias = true,
            TextAlign = SKTextAlign.Right
        };
        
        var timestamp = $"{currentTime.TotalSeconds:F2}s";
        canvas.DrawText(
            timestamp,
            settings.Width - 20,
            30,
            paint);
    }
    
    private SKColor ToSkColor(Color color)
    {
        return new SKColor(
            (byte)color.R,
            (byte)color.G,
            (byte)color.B,
            (byte)color.A);
    }
}
```

---

## 🎬 Effect Renderers

### DataFlowEffectRenderer.cs

```csharp
// Infrastructure/Effects/DataFlowEffectRenderer.cs
public class DataFlowEffectRenderer : IEffectRenderer
{
    public async Task RenderAsync(
        SKCanvas canvas,
        Effect effect,
        Duration currentTime)
    {
        if (effect is not DataFlowEffect dataFlow)
            return;
        
        // Calculate progress (0 to 1)
        var elapsed = currentTime.Subtract(effect.StartTime);
        var progress = elapsed.TotalSeconds / effect.Duration.TotalSeconds;
        progress = Math.Clamp(progress, 0, 1);
        
        // Apply easing
        // progress = dataFlow.Easing?.Apply(progress) ?? progress;
        
        // Get edge path (simplified - assumes straight line)
        // In production, get actual edge path from graph
        var startX = 100f;
        var startY = 100f;
        var endX = 500f;
        var endY = 300f;
        
        // Render particles along the path
        for (int i = 0; i < dataFlow.ParticleCount; i++)
        {
            var offset = (i / (float)dataFlow.ParticleCount) * dataFlow.ParticleSpeed;
            var particleProgress = (progress + offset) % 1.0;
            
            var x = startX + (endX - startX) * (float)particleProgress;
            var y = startY + (endY - startY) * (float)particleProgress;
            
            using var paint = new SKPaint
            {
                Color = ToSkColor(dataFlow.FlowColor),
                Style = SKPaintStyle.Fill,
                IsAntialias = true
            };
            
            // Draw particle
            canvas.DrawCircle(x, y, 5, paint);
            
            // Draw glow effect
            using var glowPaint = new SKPaint
            {
                Color = ToSkColor(dataFlow.FlowColor).WithAlpha(100),
                Style = SKPaintStyle.Fill,
                IsAntialias = true
            };
            canvas.DrawCircle(x, y, 10, glowPaint);
        }
        
        await Task.CompletedTask;
    }
    
    private SKColor ToSkColor(Color color)
    {
        return new SKColor((byte)color.R, (byte)color.G, (byte)color.B, (byte)color.A);
    }
}
```

### HighlightEffectRenderer.cs

```csharp
// Infrastructure/Effects/HighlightEffectRenderer.cs
public class HighlightEffectRenderer : IEffectRenderer
{
    public async Task RenderAsync(
        SKCanvas canvas,
        Effect effect,
        Duration currentTime)
    {
        if (effect is not HighlightEffect highlight)
            return;
        
        // Calculate pulse if animated
        var alpha = 255;
        if (highlight.Animated)
        {
            var elapsed = currentTime.Subtract(effect.StartTime);
            var progress = elapsed.TotalSeconds / effect.Duration.TotalSeconds;
            
            // Pulse effect: alpha oscillates between 128 and 255
            alpha = (int)(128 + 127 * Math.Sin(progress * Math.PI * 4));
        }
        
        // Get target element bounds
        // For now, using placeholder
        var x = 100f;
        var y = 100f;
        var width = 120f;
        var height = 60f;
        
        using var paint = new SKPaint
        {
            Color = ToSkColor(highlight.HighlightColor).WithAlpha((byte)alpha),
            Style = SKPaintStyle.Stroke,
            StrokeWidth = (float)highlight.BorderWidth,
            IsAntialias = true
        };
        
        // Draw highlight border
        var rect = new SKRect(
            x - 5,
            y - 5,
            x + width + 5,
            y + height + 5);
        
        canvas.DrawRoundRect(rect, 10, 10, paint);
        
        await Task.CompletedTask;
    }
    
    private SKColor ToSkColor(Color color)
    {
        return new SKColor((byte)color.R, (byte)color.G, (byte)color.B, (byte)color.A);
    }
}
```

---

## 📤 Export Infrastructure

### IGifExporter.cs

```csharp
// Infrastructure/Export/IGifExporter.cs
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using SkiaSharp;
using BahyWay.SharedKernel.Results;

namespace BahyWay.SimulateWay.Infrastructure.Export;

public interface IGifExporter
{
    Task<r> ExportAsync(
        Animation animation,
        string outputPath,
        IProgress<double>? progress = null,
        CancellationToken cancellationToken = default);
    
    Task<r> ExportFramesAsync(
        List<SKBitmap> frames,
        string outputPath,
        int frameRate,
        IProgress<double>? progress = null,
        CancellationToken cancellationToken = default);
}
```

### GifExporter.cs

```csharp
// Infrastructure/Export/GifExporter.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using SkiaSharp;
using AnimatedGif;
using BahyWay.SharedKernel.Results;

namespace BahyWay.SimulateWay.Infrastructure.Export;

public class GifExporter : IGifExporter
{
    private readonly IAnimationRenderer _renderer;
    
    public GifExporter(IAnimationRenderer renderer)
    {
        _renderer = renderer;
    }
    
    public async Task<r> ExportAsync(
        Animation animation,
        string outputPath,
        IProgress<double>? progress = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            // Render all frames
            progress?.Report(0.1);
            var framesResult = await _renderer.RenderAllFramesAsync(animation, cancellationToken);
            
            if (framesResult.IsFailure)
                return Result.Failure(framesResult.Error);
            
            progress?.Report(0.5);
            
            // Export frames to GIF
            var frameRate = animation.Settings.FrameRate;
            var result = await ExportFramesAsync(
                framesResult.Value,
                outputPath,
                frameRate,
                progress,
                cancellationToken);
            
            return result;
        }
        catch (Exception ex)
        {
            return Result.Failure(new Error("GifExport.Failed", ex.Message));
        }
    }
    
    public async Task<r> ExportFramesAsync(
        List<SKBitmap> frames,
        string outputPath,
        int frameRate,
        IProgress<double>? progress = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var delay = (int)(1000.0 / frameRate); // Delay in milliseconds
            
            using var gif = AnimatedGif.AnimatedGif.Create(outputPath, delay);
            
            for (int i = 0; i < frames.Count; i++)
            {
                if (cancellationToken.IsCancellationRequested)
                    break;
                
                var frame = frames[i];
                
                // Convert SKBitmap to System.Drawing.Image
                using var image = SKBitmapToImage(frame);
                gif.AddFrame(image, delay: delay, quality: GifQuality.Default);
                
                // Report progress
                var currentProgress = 0.5 + (0.5 * (i + 1) / frames.Count);
                progress?.Report(currentProgress);
            }
            
            return await Task.FromResult(Result.Success());
        }
        catch (Exception ex)
        {
            return Result.Failure(new Error("GifExport.FramesFailed", ex.Message));
        }
    }
    
    private System.Drawing.Image SKBitmapToImage(SKBitmap bitmap)
    {
        using var data = bitmap.Encode(SKEncodedImageFormat.Png, 100);
        using var stream = data.AsStream();
        return System.Drawing.Image.FromStream(stream);
    }
}
```

### Mp4Exporter.cs

```csharp
// Infrastructure/Export/Mp4Exporter.cs
using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using BahyWay.SharedKernel.Results;

namespace BahyWay.SimulateWay.Infrastructure.Export;

public class Mp4Exporter : IVideoExporter
{
    private readonly IAnimationRenderer _renderer;
    
    public Mp4Exporter(IAnimationRenderer renderer)
    {
        _renderer = renderer;
    }
    
    public async Task<r> ExportAsync(
        Animation animation,
        string outputPath,
        VideoSettings settings,
        IProgress<double>? progress = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            // Render all frames
            progress?.Report(0.1);
            var framesResult = await _renderer.RenderAllFramesAsync(animation, cancellationToken);
            
            if (framesResult.IsFailure)
                return Result.Failure(framesResult.Error);
            
            progress?.Report(0.4);
            
            // Save frames to temporary directory
            var tempDir = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString());
            Directory.CreateDirectory(tempDir);
            
            try
            {
                // Save each frame as PNG
                for (int i = 0; i < framesResult.Value.Count; i++)
                {
                    var framePath = Path.Combine(tempDir, $"frame_{i:D6}.png");
                    using var image = framesResult.Value[i].Encode(SKEncodedImageFormat.Png, 100);
                    using var file = File.OpenWrite(framePath);
                    image.SaveTo(file);
                }
                
                progress?.Report(0.7);
                
                // Use FFmpeg to create video
                var result = await ConvertFramesToVideoAsync(
                    tempDir,
                    outputPath,
                    animation.Settings.FrameRate,
                    settings,
                    cancellationToken);
                
                progress?.Report(1.0);
                
                return result;
            }
            finally
            {
                // Cleanup temp directory
                if (Directory.Exists(tempDir))
                {
                    Directory.Delete(tempDir, recursive: true);
                }
            }
        }
        catch (Exception ex)
        {
            return Result.Failure(new Error("Mp4Export.Failed", ex.Message));
        }
    }
    
    private async Task<r> ConvertFramesToVideoAsync(
        string framesDirectory,
        string outputPath,
        int frameRate,
        VideoSettings settings,
        CancellationToken cancellationToken)
    {
        try
        {
            // FFmpeg command to create MP4 from image sequence
            var ffmpegArgs = $"-framerate {frameRate} " +
                           $"-i \"{Path.Combine(framesDirectory, "frame_%06d.png")}\" " +
                           $"-c:v libx264 " +
                           $"-preset {settings.Preset} " +
                           $"-crf {settings.Quality} " +
                           $"-pix_fmt yuv420p " +
                           $"\"{outputPath}\"";
            
            var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "ffmpeg",
                    Arguments = ffmpegArgs,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                }
            };
            
            process.Start();
            
            await process.WaitForExitAsync(cancellationToken);
            
            if (process.ExitCode != 0)
            {
                var error = await process.StandardError.ReadToEndAsync();
                return Result.Failure(
                    new Error("Mp4Export.FFmpegFailed", error));
            }
            
            return Result.Success();
        }
        catch (Exception ex)
        {
            return Result.Failure(
                new Error("Mp4Export.ConversionFailed", ex.Message));
        }
    }
}

public class VideoSettings
{
    public string Preset { get; set; } = "medium"; // ultrafast, fast, medium, slow
    public int Quality { get; set; } = 23; // CRF value (lower = better quality)
    public string PixelFormat { get; set; } = "yuv420p";
}
```

---

## 🎛️ Timeline UI (Avalonia)

### TimelineView.axaml

```xml
<!-- Desktop/Views/TimelineView.axaml -->
<UserControl xmlns="https://github.com/avaloniaui"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
             xmlns:vm="using:BahyWay.SimulateWay.Desktop.ViewModels"
             x:Class="BahyWay.SimulateWay.Desktop.Views.TimelineView"
             x:DataType="vm:TimelineViewModel">
    
    <Grid RowDefinitions="Auto,*,Auto">
        
        <!-- Timeline Header -->
        <Border Grid.Row="0" 
                Background="#2D2D30" 
                BorderBrush="#3E3E42" 
                BorderThickness="0,0,0,1"
                Padding="12,8">
            <Grid ColumnDefinitions="Auto,*,Auto">
                <TextBlock Grid.Column="0" 
                          Text="Timeline" 
                          FontWeight="Bold" 
                          FontSize="14"
                          Foreground="White"/>
                
                <StackPanel Grid.Column="2" Orientation="Horizontal" Spacing="8">
                    <TextBlock Text="Duration:" 
                              VerticalAlignment="Center" 
                              Foreground="#CCCCCC"/>
                    <TextBlock Text="{Binding TotalDuration}" 
                              VerticalAlignment="Center"
                              Foreground="#4EC9B0"
                              FontFamily="Cascadia Code,Consolas"/>
                </StackPanel>
            </Grid>
        </Border>
        
        <!-- Timeline Canvas -->
        <ScrollViewer Grid.Row="1" 
                     HorizontalScrollBarVisibility="Auto"
                     VerticalScrollBarVisibility="Auto">
            <Canvas Background="#1E1E1E" 
                   Width="{Binding TimelineWidth}"
                   Height="{Binding TimelineHeight}">
                
                <!-- Time Ruler -->
                <ItemsControl Items="{Binding TimeMarkers}">
                    <ItemsControl.ItemsPanel>
                        <ItemsPanelTemplate>
                            <Canvas/>
                        </ItemsPanelTemplate>
                    </ItemsControl.ItemsPanel>
                    <ItemsControl.ItemTemplate>
                        <DataTemplate>
                            <StackPanel>
                                <Line X1="{Binding Position}" 
                                     Y1="0" 
                                     X2="{Binding Position}" 
                                     Y2="10"
                                     Stroke="#666666" 
                                     StrokeThickness="1"/>
                                <TextBlock Text="{Binding TimeText}" 
                                          Canvas.Left="{Binding TextPosition}"
                                          Canvas.Top="12"
                                          FontSize="10" 
                                          Foreground="#888888"/>
                            </StackPanel>
                        </DataTemplate>
                    </ItemsControl.ItemTemplate>
                </ItemsControl>
                
                <!-- Scene Tracks -->
                <ItemsControl Items="{Binding SceneTracks}" 
                             Canvas.Top="40">
                    <ItemsControl.ItemsPanel>
                        <ItemsPanelTemplate>
                            <StackPanel Spacing="5"/>
                        </ItemsPanelTemplate>
                    </ItemsControl.ItemsPanel>
                    <ItemsControl.ItemTemplate>
                        <DataTemplate>
                            <Grid Height="60" Margin="0,0,0,5">
                                <!-- Track Label -->
                                <Border Width="150" 
                                       HorizontalAlignment="Left"
                                       Background="#252526" 
                                       BorderBrush="#3E3E42" 
                                       BorderThickness="1"
                                       Padding="8">
                                    <TextBlock Text="{Binding SceneName}" 
                                              VerticalAlignment="Center"
                                              Foreground="White"/>
                                </Border>
                                
                                <!-- Keyframes -->
                                <ItemsControl Items="{Binding Keyframes}" 
                                             Margin="160,0,0,0">
                                    <ItemsControl.ItemsPanel>
                                        <ItemsPanelTemplate>
                                            <Canvas/>
                                        </ItemsPanelTemplate>
                                    </ItemsControl.ItemsPanel>
                                    <ItemsControl.ItemTemplate>
                                        <DataTemplate>
                                            <Border Width="{Binding Width}" 
                                                   Height="50"
                                                   Canvas.Left="{Binding Position}"
                                                   Background="{Binding Color}" 
                                                   BorderBrush="#4EC9B0" 
                                                   BorderThickness="2"
                                                   CornerRadius="4"
                                                   Cursor="Hand">
                                                <TextBlock Text="{Binding SceneName}" 
                                                          VerticalAlignment="Center"
                                                          HorizontalAlignment="Center"
                                                          Foreground="White"
                                                          FontSize="12"/>
                                            </Border>
                                        </DataTemplate>
                                    </ItemsControl.ItemTemplate>
                                </ItemsControl>
                            </Grid>
                        </DataTemplate>
                    </ItemsControl.ItemTemplate>
                </ItemsControl>
                
                <!-- Playhead -->
                <Line X1="{Binding PlayheadPosition}" 
                     Y1="0" 
                     X2="{Binding PlayheadPosition}" 
                     Y2="{Binding TimelineHeight}"
                     Stroke="#FF0000" 
                     StrokeThickness="2"/>
                
            </Canvas>
        </ScrollViewer>
        
        <!-- Playback Controls -->
        <Border Grid.Row="2" 
                Background="#2D2D30" 
                BorderBrush="#3E3E42" 
                BorderThickness="0,1,0,0"
                Padding="12,8">
            <StackPanel Orientation="Horizontal" Spacing="8">
                <Button Content="⏮" 
                       Command="{Binding SkipToStartCommand}"
                       Classes="toolbar"
                       ToolTip.Tip="Skip to Start"/>
                <Button Content="◀" 
                       Command="{Binding StepBackCommand}"
                       Classes="toolbar"
                       ToolTip.Tip="Step Back"/>
                <Button Content="{Binding PlayButtonText}" 
                       Command="{Binding PlayPauseCommand}"
                       Classes="toolbar primary"
                       ToolTip.Tip="Play/Pause"/>
                <Button Content="▶" 
                       Command="{Binding StepForwardCommand}"
                       Classes="toolbar"
                       ToolTip.Tip="Step Forward"/>
                <Button Content="⏭" 
                       Command="{Binding SkipToEndCommand}"
                       Classes="toolbar"
                       ToolTip.Tip="Skip to End"/>
                
                <Separator Width="1" Height="24" Background="#3E3E42" Margin="8,0"/>
                
                <TextBlock Text="Current:" 
                          VerticalAlignment="Center" 
                          Foreground="#CCCCCC"/>
                <TextBlock Text="{Binding CurrentTime}" 
                          VerticalAlignment="Center"
                          FontFamily="Cascadia Code,Consolas"
                          Foreground="#4EC9B0"/>
                
                <Separator Width="1" Height="24" Background="#3E3E42" Margin="8,0"/>
                
                <TextBlock Text="Speed:" 
                          VerticalAlignment="Center" 
                          Foreground="#CCCCCC"/>
                <ComboBox SelectedItem="{Binding PlaybackSpeed}"
                         Width="80">
                    <ComboBoxItem Content="0.25x"/>
                    <ComboBoxItem Content="0.5x"/>
                    <ComboBoxItem Content="1x" IsSelected="True"/>
                    <ComboBoxItem Content="1.5x"/>
                    <ComboBoxItem Content="2x"/>
                </ComboBox>
            </StackPanel>
        </Border>
        
    </Grid>
</UserControl>
```

---

**Continue to Part 3: Timeline ViewModel, Animation Builder, and Complete Integration?**
