# BahyWay Rules Engine - Download Options

Choose your preferred format:

## 📦 Compressed Archives (Recommended)

**Option 1: TAR.GZ Format (33 KB)**
- Best for Linux/Mac
- [Download bahyway-rules-engine.tar.gz](computer:///mnt/user-data/outputs/bahyway-rules-engine.tar.gz)

**Option 2: ZIP Format (45 KB)**
- Best for Windows
- [Download bahyway-rules-engine.zip](computer:///mnt/user-data/outputs/bahyway-rules-engine.zip)

## 📂 Individual Files

If you prefer to browse individual files:
- [View complete folder](computer:///mnt/user-data/outputs/bahyway-rules-engine)

## 📋 What's Inside

```
bahyway-rules-engine/
├── START_HERE.md              ⭐ Read this first!
├── README.md                  📚 Complete documentation
├── QUICKSTART.md              🚀 5-minute guide
├── ARCHITECTURE.md            📐 System design
├── Cargo.toml                 🦀 Rust workspace
├── docker-compose.yml         🐳 Full stack setup
├── Dockerfile                 📦 Production container
│
├── crates/
│   ├── core/                  ⚙️ Core rules engine
│   │   ├── src/
│   │   │   ├── lib.rs
│   │   │   ├── condition.rs
│   │   │   ├── action.rs
│   │   │   ├── rule.rs
│   │   │   ├── engine.rs
│   │   │   ├── executor.rs
│   │   │   └── ml_integration.rs
│   │   └── Cargo.toml
│   │
│   └── ssis-rules/            📊 SSISight rules
│       ├── src/lib.rs
│       └── Cargo.toml
│
├── rules/                     📜 YAML rules
│   ├── ssis-validation.yaml
│   └── alarm-processing.yaml
│
└── python-ml-service/         🐍 ML integration
    └── main.py

```

## 🚀 Quick Start After Download

### Extract the Archive

**For TAR.GZ:**
```bash
tar -xzf bahyway-rules-engine.tar.gz
cd bahyway-rules-engine
```

**For ZIP:**
```bash
unzip bahyway-rules-engine.zip
cd bahyway-rules-engine
```

### Build & Test

```bash
# Build
cargo build --release

# Run tests
cargo test --workspace

# Start with Docker
docker-compose up -d
```

## 💡 Next Steps

1. Read `START_HERE.md` for overview
2. Follow `QUICKSTART.md` for examples
3. Customize rules in `rules/` folder
4. Deploy with Docker or Kubernetes

---

**Need help?** Check the documentation files included in the download!
