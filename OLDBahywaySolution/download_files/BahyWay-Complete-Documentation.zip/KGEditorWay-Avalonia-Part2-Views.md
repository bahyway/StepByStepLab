# KGEditorWay - Avalonia UI Part 2: Complete XAML Views

## 🎨 Main Window

### MainWindow.axaml

```xml
<!-- Views/MainWindow.axaml -->
<Window xmlns="https://github.com/avaloniaui"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        xmlns:vm="using:BahyWay.KGEditorWay.Desktop.ViewModels"
        xmlns:views="using:BahyWay.KGEditorWay.Desktop.Views"
        x:Class="BahyWay.KGEditorWay.Desktop.Views.MainWindow"
        x:DataType="vm:MainViewModel"
        Title="KGEditorWay - Knowledge Graph Editor"
        Width="1400"
        Height="900"
        MinWidth="800"
        MinHeight="600"
        Icon="/Assets/logo.ico"
        Background="#1E1E1E">
    
    <Window.Styles>
        <Style Selector="Window">
            <Setter Property="TransparencyLevelHint" Value="None"/>
        </Style>
    </Window.Styles>
    
    <Grid RowDefinitions="Auto,*,Auto">
        
        <!-- Top Toolbar -->
        <Border Grid.Row="0" 
                Background="#2D2D30" 
                BorderBrush="#3E3E42" 
                BorderThickness="0,0,0,1"
                Padding="8">
            <StackPanel Orientation="Horizontal" Spacing="8">
                
                <!-- File Operations -->
                <Button Content="📁 New" Command="{Binding NewGraphCommand}" Classes="toolbar"/>
                <Button Content="📂 Open" Command="{Binding OpenGraphCommand}" Classes="toolbar"/>
                <Button Content="💾 Save" Command="{Binding SaveGraphCommand}" Classes="toolbar"/>
                <Button Content="💾 Save As" Command="{Binding SaveAsGraphCommand}" Classes="toolbar"/>
                
                <Separator Width="1" Height="24" Background="#3E3E42"/>
                
                <!-- Edit Operations -->
                <Button Content="↶ Undo" Command="{Binding UndoCommand}" Classes="toolbar"/>
                <Button Content="↷ Redo" Command="{Binding RedoCommand}" Classes="toolbar"/>
                
                <Separator Width="1" Height="24" Background="#3E3E42"/>
                
                <!-- Zoom Controls -->
                <Button Content="🔍+" Command="{Binding CanvasViewModel.ZoomInCommand}" Classes="toolbar"/>
                <Button Content="🔍-" Command="{Binding CanvasViewModel.ZoomOutCommand}" Classes="toolbar"/>
                <Button Content="⊡ Fit" Command="{Binding CanvasViewModel.FitToViewCommand}" Classes="toolbar"/>
                <TextBlock Text="{Binding CanvasViewModel.Zoom, StringFormat={}{0:P0}}" 
                          VerticalAlignment="Center"
                          Margin="8,0"/>
                
                <Separator Width="1" Height="24" Background="#3E3E42"/>
                
                <!-- Layout -->
                <Button Content="📐 Auto Layout" Command="{Binding AutoLayoutCommand}" Classes="toolbar"/>
                
                <Separator Width="1" Height="24" Background="#3E3E42"/>
                
                <!-- Execution -->
                <Button Content="▶ Execute" 
                        Command="{Binding ExecuteGraphCommand}" 
                        Classes="toolbar primary"
                        IsEnabled="{Binding CanExecute}"/>
                <Button Content="⏸ Pause" Command="{Binding PauseExecutionCommand}" Classes="toolbar"/>
                <Button Content="⏹ Stop" Command="{Binding StopExecutionCommand}" Classes="toolbar"/>
                
            </StackPanel>
        </Border>
        
        <!-- Main Content Area -->
        <Grid Grid.Row="1" ColumnDefinitions="250,*,300">
            
            <!-- Left Panel - Toolbox -->
            <Border Grid.Column="0" 
                    Background="#252526" 
                    BorderBrush="#3E3E42" 
                    BorderThickness="0,0,1,0">
                <views:ToolboxView DataContext="{Binding ToolboxViewModel}"/>
            </Border>
            
            <!-- Center - Canvas -->
            <Border Grid.Column="1" Background="#1E1E1E">
                <views:GraphCanvasView DataContext="{Binding CanvasViewModel}"/>
            </Border>
            
            <!-- Right Panel - Properties -->
            <Border Grid.Column="2" 
                    Background="#252526" 
                    BorderBrush="#3E3E42" 
                    BorderThickness="1,0,0,0">
                <views:PropertiesPanelView DataContext="{Binding PropertiesViewModel}"/>
            </Border>
            
        </Grid>
        
        <!-- Bottom Status Bar -->
        <Border Grid.Row="2" 
                Background="#007ACC" 
                BorderBrush="#3E3E42" 
                BorderThickness="0,1,0,0"
                Height="24"
                Padding="8,0">
            <Grid ColumnDefinitions="Auto,*,Auto,Auto,Auto">
                <TextBlock Grid.Column="0" 
                          Text="{Binding StatusMessage}" 
                          Foreground="White"
                          VerticalAlignment="Center"/>
                
                <TextBlock Grid.Column="2" 
                          Text="{Binding CanvasViewModel.Nodes.Count, StringFormat='Nodes: {0}'}" 
                          Foreground="White"
                          Margin="0,0,16,0"
                          VerticalAlignment="Center"/>
                
                <TextBlock Grid.Column="3" 
                          Text="{Binding CanvasViewModel.Connections.Count, StringFormat='Connections: {0}'}" 
                          Foreground="White"
                          Margin="0,0,16,0"
                          VerticalAlignment="Center"/>
                
                <TextBlock Grid.Column="4" 
                          Text="{Binding CurrentGraphName, StringFormat='Graph: {0}'}" 
                          Foreground="White"
                          VerticalAlignment="Center"/>
            </Grid>
        </Border>
        
    </Grid>
</Window>
```

### MainWindow.axaml.cs

```csharp
// Views/MainWindow.axaml.cs
using Avalonia.Controls;

namespace BahyWay.KGEditorWay.Desktop.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
```

---

## 🎨 Graph Canvas View

### GraphCanvasView.axaml

```xml
<!-- Views/GraphCanvasView.axaml -->
<UserControl xmlns="https://github.com/avaloniaui"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
             xmlns:vm="using:BahyWay.KGEditorWay.Desktop.ViewModels"
             xmlns:behaviors="using:BahyWay.KGEditorWay.Desktop.Behaviors"
             xmlns:controls="using:BahyWay.KGEditorWay.Desktop.Views.Controls"
             x:Class="BahyWay.KGEditorWay.Desktop.Views.GraphCanvasView"
             x:DataType="vm:GraphCanvasViewModel">
    
    <Panel Name="CanvasRoot" 
           Background="{StaticResource CanvasBackgroundBrush}"
           ClipToBounds="True">
        
        <!-- Grid Background -->
        <Canvas Name="GridCanvas">
            <Canvas.Background>
                <VisualBrush TileMode="Tile" 
                            SourceRect="0,0,50,50" 
                            DestinationRect="0,0,50,50">
                    <VisualBrush.Visual>
                        <Grid Width="50" Height="50">
                            <Line StartPoint="0,0" EndPoint="50,0" Stroke="#2A2A2A" StrokeThickness="1"/>
                            <Line StartPoint="0,0" EndPoint="0,50" Stroke="#2A2A2A" StrokeThickness="1"/>
                        </Grid>
                    </VisualBrush.Visual>
                </VisualBrush>
            </Canvas.Background>
        </Canvas>
        
        <!-- Main Canvas with Pan/Zoom Transform -->
        <Panel RenderTransform="{Binding CanvasTransform}">
            
            <!-- Connections Layer -->
            <Canvas Name="ConnectionsCanvas">
                <ItemsControl Items="{Binding Connections}">
                    <ItemsControl.ItemsPanel>
                        <ItemsPanelTemplate>
                            <Canvas/>
                        </ItemsPanelTemplate>
                    </ItemsControl.ItemsPanel>
                    
                    <ItemsControl.ItemTemplate>
                        <DataTemplate>
                            <controls:ConnectionView/>
                        </DataTemplate>
                    </ItemsControl.ItemTemplate>
                </ItemsControl>
            </Canvas>
            
            <!-- Nodes Layer -->
            <ItemsControl Items="{Binding Nodes}" Name="NodesContainer">
                <ItemsControl.ItemsPanel>
                    <ItemsPanelTemplate>
                        <Canvas/>
                    </ItemsPanelTemplate>
                </ItemsControl.ItemsPanel>
                
                <ItemsControl.ItemTemplate>
                    <DataTemplate>
                        <controls:NodeView/>
                    </DataTemplate>
                </ItemsControl.ItemTemplate>
                
                <ItemsControl.Styles>
                    <Style Selector="ContentPresenter">
                        <Setter Property="Canvas.Left" Value="{Binding X}"/>
                        <Setter Property="Canvas.Top" Value="{Binding Y}"/>
                    </Style>
                </ItemsControl.Styles>
            </ItemsControl>
            
            <!-- Connection Being Drawn -->
            <Path IsVisible="{Binding IsDrawingConnection}"
                  Stroke="#2196F3"
                  StrokeThickness="2"
                  StrokeDashArray="5,5">
                <!-- Path geometry will be set in code-behind -->
            </Path>
            
        </Panel>
        
        <!-- Minimap -->
        <Border Background="#1E1E1ECC"
                BorderBrush="#3E3E42"
                BorderThickness="1"
                CornerRadius="4"
                Width="200"
                Height="150"
                HorizontalAlignment="Right"
                VerticalAlignment="Bottom"
                Margin="16"
                Padding="4">
            <controls:MinimapView DataContext="{Binding}"/>
        </Border>
        
        <!-- Interaction Behaviors -->
        <Interaction.Behaviors>
            <behaviors:CanvasPanBehavior/>
            <behaviors:CanvasZoomBehavior/>
            <behaviors:NodeDragBehavior/>
            <behaviors:SelectionBehavior/>
        </Interaction.Behaviors>
        
    </Panel>
</UserControl>
```

### GraphCanvasView.axaml.cs

```csharp
// Views/GraphCanvasView.axaml.cs
using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Media;
using BahyWay.KGEditorWay.Desktop.ViewModels;

namespace BahyWay.KGEditorWay.Desktop.Views;

public partial class GraphCanvasView : UserControl
{
    private GraphCanvasViewModel? ViewModel => DataContext as GraphCanvasViewModel;
    private Path? _connectionDrawingPath;
    
    public GraphCanvasView()
    {
        InitializeComponent();
        
        _connectionDrawingPath = this.FindControl<Path>("ConnectionDrawingPath");
        
        // Handle mouse events for panning and connection drawing
        PointerPressed += OnPointerPressed;
        PointerMoved += OnPointerMoved;
        PointerReleased += OnPointerReleased;
        PointerWheelChanged += OnPointerWheelChanged;
    }
    
    private void OnPointerPressed(object? sender, PointerPressedEventArgs e)
    {
        var point = e.GetPosition(this);
        var props = e.GetCurrentPoint(this).Properties;
        
        if (props.IsMiddleButtonPressed)
        {
            // Start panning
            ViewModel?.StartPan(point);
            e.Handled = true;
        }
    }
    
    private void OnPointerMoved(object? sender, PointerEventArgs e)
    {
        var point = e.GetPosition(this);
        
        if (ViewModel != null)
        {
            // Update pan
            ViewModel.UpdatePan(point);
            
            // Update connection drawing
            if (ViewModel.IsDrawingConnection)
            {
                ViewModel.UpdateConnectionDrawing(point);
                UpdateConnectionDrawingPath();
            }
        }
    }
    
    private void OnPointerReleased(object? sender, PointerReleasedEventArgs e)
    {
        ViewModel?.EndPan();
    }
    
    private void OnPointerWheelChanged(object? sender, PointerWheelEventArgs e)
    {
        if (ViewModel != null)
        {
            var delta = e.Delta.Y;
            if (delta > 0)
                ViewModel.Zoom *= 1.1;
            else
                ViewModel.Zoom /= 1.1;
            
            e.Handled = true;
        }
    }
    
    private void UpdateConnectionDrawingPath()
    {
        // Update the path geometry for connection being drawn
        // Implementation depends on your connection drawing logic
    }
}
```

---

## 🎨 Node View

### NodeView.axaml

```xml
<!-- Views/Controls/NodeView.axaml -->
<UserControl xmlns="https://github.com/avaloniaui"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
             xmlns:vm="using:BahyWay.KGEditorWay.Desktop.ViewModels"
             x:Class="BahyWay.KGEditorWay.Desktop.Views.Controls.NodeView"
             x:DataType="vm:NodeViewModel"
             Width="{Binding Width}"
             Height="{Binding Height}">
    
    <Border Name="NodeBorder"
            Background="{StaticResource NodeBackgroundBrush}"
            BorderThickness="2"
            CornerRadius="8"
            Padding="12"
            Cursor="Hand">
        
        <Border.BorderBrush>
            <SolidColorBrush Color="{Binding TypeColor}"/>
        </Border.BorderBrush>
        
        <!-- Selection highlight -->
        <Border.Styles>
            <Style Selector="Border:pointerover">
                <Setter Property="Background" Value="#252525"/>
            </Style>
            <Style Selector="Border[IsSelected=True]">
                <Setter Property="BorderThickness" Value="3"/>
                <Setter Property="Effect">
                    <DropShadowEffect Color="{Binding TypeColor}" 
                                    BlurRadius="12" 
                                    OffsetX="0" 
                                    OffsetY="0"/>
                </Setter>
            </Style>
        </Border.Styles>
        
        <Grid RowDefinitions="Auto,*,Auto">
            
            <!-- Header -->
            <Grid Grid.Row="0" ColumnDefinitions="Auto,*,Auto" Margin="0,0,0,8">
                
                <!-- Icon -->
                <TextBlock Grid.Column="0"
                          Text="{Binding TypeIcon}"
                          FontSize="18"
                          VerticalAlignment="Center"/>
                
                <!-- Name -->
                <TextBlock Grid.Column="1"
                          Text="{Binding Name}"
                          FontWeight="Bold"
                          FontSize="14"
                          Margin="8,0"
                          VerticalAlignment="Center"
                          Foreground="White"/>
                
                <!-- Settings Button -->
                <Button Grid.Column="2"
                       Content="⚙"
                       Command="{Binding EditPropertiesCommand}"
                       Background="Transparent"
                       BorderThickness="0"
                       FontSize="12"
                       Width="24"
                       Height="24"/>
                
            </Grid>
            
            <!-- Body with Ports -->
            <Grid Grid.Row="1" ColumnDefinitions="Auto,*,Auto">
                
                <!-- Input Ports -->
                <ItemsControl Grid.Column="0" Items="{Binding InputPorts}">
                    <ItemsControl.ItemTemplate>
                        <DataTemplate>
                            <Grid Margin="0,4">
                                <Ellipse Width="12" 
                                        Height="12"
                                        Fill="#4CAF50"
                                        Stroke="White"
                                        StrokeThickness="1"
                                        Cursor="Hand"
                                        ToolTip.Tip="{Binding Name}"
                                        PointerPressed="OnPortPressed"/>
                                <TextBlock Text="{Binding Name}"
                                          FontSize="10"
                                          Margin="16,0,0,0"
                                          VerticalAlignment="Center"
                                          Foreground="#CCCCCC"/>
                            </Grid>
                        </DataTemplate>
                    </ItemsControl.ItemTemplate>
                </ItemsControl>
                
                <!-- Center Space -->
                <Border Grid.Column="1"/>
                
                <!-- Output Ports -->
                <ItemsControl Grid.Column="2" Items="{Binding OutputPorts}">
                    <ItemsControl.ItemTemplate>
                        <DataTemplate>
                            <Grid Margin="0,4">
                                <Grid.ColumnDefinitions>
                                    <ColumnDefinition Width="*"/>
                                    <ColumnDefinition Width="Auto"/>
                                </Grid.ColumnDefinitions>
                                
                                <TextBlock Grid.Column="0"
                                          Text="{Binding Name}"
                                          FontSize="10"
                                          Margin="0,0,16,0"
                                          HorizontalAlignment="Right"
                                          VerticalAlignment="Center"
                                          Foreground="#CCCCCC"/>
                                
                                <Ellipse Grid.Column="1"
                                        Width="12" 
                                        Height="12"
                                        Fill="#2196F3"
                                        Stroke="White"
                                        StrokeThickness="1"
                                        Cursor="Hand"
                                        ToolTip.Tip="{Binding Name}"
                                        PointerPressed="OnPortPressed"/>
                            </Grid>
                        </DataTemplate>
                    </ItemsControl.ItemTemplate>
                </ItemsControl>
                
            </Grid>
            
            <!-- Footer (optional - status, etc.) -->
            <TextBlock Grid.Row="2"
                      Text="{Binding StatusText}"
                      FontSize="10"
                      Foreground="#888888"
                      Margin="0,8,0,0"
                      TextWrapping="Wrap"/>
            
        </Grid>
    </Border>
</UserControl>
```

### NodeView.axaml.cs

```csharp
// Views/Controls/NodeView.axaml.cs
using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using BahyWay.KGEditorWay.Desktop.ViewModels;

namespace BahyWay.KGEditorWay.Desktop.Views.Controls;

public partial class NodeView : UserControl
{
    private Point _dragStartPoint;
    private bool _isDragging;
    
    public NodeView()
    {
        InitializeComponent();
        
        PointerPressed += OnNodePointerPressed;
        PointerMoved += OnNodePointerMoved;
        PointerReleased += OnNodePointerReleased;
    }
    
    private void OnNodePointerPressed(object? sender, PointerPressedEventArgs e)
    {
        if (DataContext is NodeViewModel node)
        {
            var props = e.GetCurrentPoint(this).Properties;
            
            if (props.IsLeftButtonPressed)
            {
                _dragStartPoint = e.GetPosition(this.Parent as Visual);
                _isDragging = true;
                node.IsSelected = true;
                e.Handled = true;
            }
            else if (props.IsRightButtonPressed)
            {
                // Show context menu
                ShowContextMenu();
                e.Handled = true;
            }
        }
    }
    
    private void OnNodePointerMoved(object? sender, PointerEventArgs e)
    {
        if (_isDragging && DataContext is NodeViewModel node)
        {
            var currentPoint = e.GetPosition(this.Parent as Visual);
            var delta = currentPoint - _dragStartPoint;
            
            node.IsDragging = true;
            
            // Get canvas ViewModel to apply zoom factor
            var canvas = this.FindAncestorOfType<GraphCanvasView>();
            if (canvas?.DataContext is GraphCanvasViewModel canvasVm)
            {
                canvasVm.HandleNodeDrag(node, delta.X, delta.Y);
            }
            
            _dragStartPoint = currentPoint;
            e.Handled = true;
        }
    }
    
    private void OnNodePointerReleased(object? sender, PointerReleasedEventArgs e)
    {
        if (DataContext is NodeViewModel node)
        {
            _isDragging = false;
            node.IsDragging = false;
        }
    }
    
    private void OnPortPressed(object? sender, PointerPressedEventArgs e)
    {
        if (sender is Ellipse ellipse && ellipse.DataContext is PortViewModel port)
        {
            port.OnClicked();
            e.Handled = true;
        }
    }
    
    private void ShowContextMenu()
    {
        var contextMenu = new ContextMenu();
        
        if (DataContext is NodeViewModel node)
        {
            contextMenu.Items = new[]
            {
                new MenuItem { Header = "Edit Properties", Command = node.EditPropertiesCommand },
                new MenuItem { Header = "Duplicate", Command = node.DuplicateCommand },
                new Separator(),
                new MenuItem { Header = "Delete", Command = node.DeleteCommand }
            };
            
            contextMenu.Open(this);
        }
    }
}

// Helper extension
public static class VisualExtensions
{
    public static T? FindAncestorOfType<T>(this IControl control) where T : class
    {
        var parent = control.Parent;
        while (parent != null)
        {
            if (parent is T typedParent)
                return typedParent;
            parent = parent.Parent;
        }
        return null;
    }
}
```

---

## 🎨 Connection View

### ConnectionView.axaml

```xml
<!-- Views/Controls/ConnectionView.axaml -->
<UserControl xmlns="https://github.com/avaloniaui"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
             xmlns:vm="using:BahyWay.KGEditorWay.Desktop.ViewModels"
             x:Class="BahyWay.KGEditorWay.Desktop.Views.Controls.ConnectionView"
             x:DataType="vm:ConnectionViewModel">
    
    <Path Stroke="{Binding StrokeBrush}"
          StrokeThickness="{Binding StrokeThickness}"
          Data="{Binding PathGeometry}"
          Cursor="Hand"
          PointerPressed="OnConnectionPressed">
        
        <Path.Styles>
            <Style Selector="Path:pointerover">
                <Setter Property="StrokeThickness" Value="3"/>
                <Setter Property="Stroke" Value="#2196F3"/>
            </Style>
        </Path.Styles>
        
        <!-- Selection indicator -->
        <Path.IsVisible>
            <MultiBinding Converter="{x:Static BoolConverters.Or}">
                <Binding Path="IsSelected"/>
                <Binding Path="!IsSelected"/>
            </MultiBinding>
        </Path.IsVisible>
        
    </Path>
</UserControl>
```

### ConnectionView.axaml.cs

```csharp
// Views/Controls/ConnectionView.axaml.cs
using Avalonia.Controls;
using Avalonia.Input;
using BahyWay.KGEditorWay.Desktop.ViewModels;

namespace BahyWay.KGEditorWay.Desktop.Views.Controls;

public partial class ConnectionView : UserControl
{
    public ConnectionView()
    {
        InitializeComponent();
    }
    
    private void OnConnectionPressed(object? sender, PointerPressedEventArgs e)
    {
        if (DataContext is ConnectionViewModel connection)
        {
            var props = e.GetCurrentPoint(this).Properties;
            
            if (props.IsLeftButtonPressed)
            {
                connection.IsSelected = !connection.IsSelected;
                e.Handled = true;
            }
            else if (props.IsRightButtonPressed)
            {
                ShowContextMenu();
                e.Handled = true;
            }
        }
    }
    
    private void ShowContextMenu()
    {
        var contextMenu = new ContextMenu();
        
        if (DataContext is ConnectionViewModel connection)
        {
            contextMenu.Items = new[]
            {
                new MenuItem 
                { 
                    Header = "Delete", 
                    Command = ReactiveCommand.Create(() => 
                    {
                        // Delete connection - handled by parent
                    })
                }
            };
            
            contextMenu.Open(this);
        }
    }
}
```

---

## 🎨 Toolbox View

### ToolboxView.axaml

```xml
<!-- Views/ToolboxView.axaml -->
<UserControl xmlns="https://github.com/avaloniaui"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
             xmlns:vm="using:BahyWay.KGEditorWay.Desktop.ViewModels"
             x:Class="BahyWay.KGEditorWay.Desktop.Views.ToolboxView"
             x:DataType="vm:ToolboxViewModel">
    
    <Grid RowDefinitions="Auto,*">
        
        <!-- Header -->
        <Border Grid.Row="0" 
                Background="#2D2D30" 
                BorderBrush="#3E3E42" 
                BorderThickness="0,0,0,1"
                Padding="12,8">
            <TextBlock Text="Toolbox" 
                      FontWeight="Bold" 
                      FontSize="14"
                      Foreground="White"/>
        </Border>
        
        <!-- Node Categories -->
        <ScrollViewer Grid.Row="1">
            <StackPanel Spacing="8" Margin="8">
                
                <!-- Search Box -->
                <TextBox Watermark="Search nodes..."
                        Text="{Binding SearchText}"
                        Margin="0,0,0,8"/>
                
                <!-- Source Nodes -->
                <Expander Header="📥 Source Nodes" IsExpanded="True">
                    <ItemsControl Items="{Binding SourceNodes}">
                        <ItemsControl.ItemTemplate>
                            <DataTemplate>
                                <Button Content="{Binding Name}"
                                       Command="{Binding $parent[UserControl].((vm:ToolboxViewModel)DataContext).AddNodeCommand}"
                                       CommandParameter="{Binding}"
                                       Classes="toolbox-node"
                                       HorizontalAlignment="Stretch"
                                       Margin="0,2"/>
                            </DataTemplate>
                        </ItemsControl.ItemTemplate>
                    </ItemsControl>
                </Expander>
                
                <!-- Transform Nodes -->
                <Expander Header="⚙ Transform Nodes" IsExpanded="True">
                    <ItemsControl Items="{Binding TransformNodes}">
                        <ItemsControl.ItemTemplate>
                            <DataTemplate>
                                <Button Content="{Binding Name}"
                                       Command="{Binding $parent[UserControl].((vm:ToolboxViewModel)DataContext).AddNodeCommand}"
                                       CommandParameter="{Binding}"
                                       Classes="toolbox-node"
                                       HorizontalAlignment="Stretch"
                                       Margin="0,2"/>
                            </DataTemplate>
                        </ItemsControl.ItemTemplate>
                    </ItemsControl>
                </Expander>
                
                <!-- Filter Nodes -->
                <Expander Header="🔍 Filter Nodes">
                    <ItemsControl Items="{Binding FilterNodes}">
                        <ItemsControl.ItemTemplate>
                            <DataTemplate>
                                <Button Content="{Binding Name}"
                                       Command="{Binding $parent[UserControl].((vm:ToolboxViewModel)DataContext).AddNodeCommand}"
                                       CommandParameter="{Binding}"
                                       Classes="toolbox-node"
                                       HorizontalAlignment="Stretch"
                                       Margin="0,2"/>
                            </DataTemplate>
                        </ItemsControl.ItemTemplate>
                    </ItemsControl>
                </Expander>
                
                <!-- Sink Nodes -->
                <Expander Header="📤 Sink Nodes" IsExpanded="True">
                    <ItemsControl Items="{Binding SinkNodes}">
                        <ItemsControl.ItemTemplate>
                            <DataTemplate>
                                <Button Content="{Binding Name}"
                                       Command="{Binding $parent[UserControl].((vm:ToolboxViewModel)DataContext).AddNodeCommand}"
                                       CommandParameter="{Binding}"
                                       Classes="toolbox-node"
                                       HorizontalAlignment="Stretch"
                                       Margin="0,2"/>
                            </DataTemplate>
                        </ItemsControl.ItemTemplate>
                    </ItemsControl>
                </Expander>
                
                <!-- Utility Nodes -->
                <Expander Header="🔧 Utility Nodes">
                    <ItemsControl Items="{Binding UtilityNodes}">
                        <ItemsControl.ItemTemplate>
                            <DataTemplate>
                                <Button Content="{Binding Name}"
                                       Command="{Binding $parent[UserControl].((vm:ToolboxViewModel)DataContext).AddNodeCommand}"
                                       CommandParameter="{Binding}"
                                       Classes="toolbox-node"
                                       HorizontalAlignment="Stretch"
                                       Margin="0,2"/>
                            </DataTemplate>
                        </ItemsControl.ItemTemplate>
                    </ItemsControl>
                </Expander>
                
            </StackPanel>
        </ScrollViewer>
        
    </Grid>
</UserControl>
```

---

## 🎨 Properties Panel View

### PropertiesPanelView.axaml

```xml
<!-- Views/PropertiesPanelView.axaml -->
<UserControl xmlns="https://github.com/avaloniaui"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
             xmlns:vm="using:BahyWay.KGEditorWay.Desktop.ViewModels"
             x:Class="BahyWay.KGEditorWay.Desktop.Views.PropertiesPanelView"
             x:DataType="vm:PropertiesPanelViewModel">
    
    <Grid RowDefinitions="Auto,*">
        
        <!-- Header -->
        <Border Grid.Row="0" 
                Background="#2D2D30" 
                BorderBrush="#3E3E42" 
                BorderThickness="0,0,0,1"
                Padding="12,8">
            <TextBlock Text="Properties" 
                      FontWeight="Bold" 
                      FontSize="14"
                      Foreground="White"/>
        </Border>
        
        <!-- Properties Content -->
        <ScrollViewer Grid.Row="1">
            <StackPanel Spacing="12" Margin="12" IsVisible="{Binding HasSelection}">
                
                <!-- Node Name -->
                <StackPanel Spacing="4">
                    <TextBlock Text="Name" FontWeight="SemiBold" Foreground="#CCCCCC"/>
                    <TextBox Text="{Binding SelectedNodeName}" />
                </StackPanel>
                
                <!-- Node Type -->
                <StackPanel Spacing="4">
                    <TextBlock Text="Type" FontWeight="SemiBold" Foreground="#CCCCCC"/>
                    <TextBlock Text="{Binding SelectedNodeType}" Foreground="White"/>
                </StackPanel>
                
                <!-- Position -->
                <StackPanel Spacing="4">
                    <TextBlock Text="Position" FontWeight="SemiBold" Foreground="#CCCCCC"/>
                    <Grid ColumnDefinitions="Auto,*,Auto,*">
                        <TextBlock Grid.Column="0" Text="X:" Margin="0,0,8,0" VerticalAlignment="Center"/>
                        <NumericUpDown Grid.Column="1" Value="{Binding SelectedNodeX}" Minimum="0" Maximum="5000"/>
                        <TextBlock Grid.Column="2" Text="Y:" Margin="16,0,8,0" VerticalAlignment="Center"/>
                        <NumericUpDown Grid.Column="3" Value="{Binding SelectedNodeY}" Minimum="0" Maximum="5000"/>
                    </Grid>
                </StackPanel>
                
                <!-- Dynamic Properties -->
                <ItemsControl Items="{Binding NodeProperties}">
                    <ItemsControl.ItemTemplate>
                        <DataTemplate>
                            <StackPanel Spacing="4" Margin="0,0,0,8">
                                <TextBlock Text="{Binding Name}" FontWeight="SemiBold" Foreground="#CCCCCC"/>
                                
                                <!-- Text Property -->
                                <TextBox Text="{Binding Value}" 
                                        IsVisible="{Binding IsTextProperty}"/>
                                
                                <!-- Number Property -->
                                <NumericUpDown Value="{Binding Value}" 
                                             IsVisible="{Binding IsNumberProperty}"/>
                                
                                <!-- Boolean Property -->
                                <CheckBox Content="{Binding Name}" 
                                         IsChecked="{Binding Value}"
                                         IsVisible="{Binding IsBooleanProperty}"/>
                                
                                <!-- Choice Property -->
                                <ComboBox Items="{Binding Choices}"
                                         SelectedItem="{Binding Value}"
                                         IsVisible="{Binding IsChoiceProperty}"/>
                                
                                <!-- File Path Property -->
                                <Grid ColumnDefinitions="*,Auto" IsVisible="{Binding IsFilePathProperty}">
                                    <TextBox Grid.Column="0" Text="{Binding Value}"/>
                                    <Button Grid.Column="1" Content="..." Width="30" Margin="4,0,0,0"/>
                                </Grid>
                                
                                <!-- Code Property -->
                                <TextBox Text="{Binding Value}"
                                        AcceptsReturn="True"
                                        MinHeight="100"
                                        FontFamily="Cascadia Code,Consolas,monospace"
                                        IsVisible="{Binding IsCodeProperty}"/>
                                
                            </StackPanel>
                        </DataTemplate>
                    </ItemsControl.ItemTemplate>
                </ItemsControl>
                
                <!-- Validation Errors -->
                <Border Background="#FF4444"
                       BorderBrush="#FF0000"
                       BorderThickness="1"
                       CornerRadius="4"
                       Padding="8"
                       IsVisible="{Binding HasValidationErrors}">
                    <StackPanel Spacing="4">
                        <TextBlock Text="⚠ Validation Errors" FontWeight="Bold" Foreground="White"/>
                        <ItemsControl Items="{Binding ValidationErrors}">
                            <ItemsControl.ItemTemplate>
                                <DataTemplate>
                                    <TextBlock Text="{Binding}" Foreground="White" TextWrapping="Wrap"/>
                                </DataTemplate>
                            </ItemsControl.ItemTemplate>
                        </ItemsControl>
                    </StackPanel>
                </Border>
                
            </StackPanel>
            
            <!-- No Selection Message -->
            <TextBlock Text="No node selected"
                      Foreground="#888888"
                      HorizontalAlignment="Center"
                      VerticalAlignment="Center"
                      Margin="12"
                      IsVisible="{Binding !HasSelection}"/>
        </ScrollViewer>
        
    </Grid>
</UserControl>
```

---

**Part 3 continues with Styles, Behaviors, and Services...**
