# BahyWay Visual Process Editor - Complete Architecture

## 🎯 Building Node-Based Graph Editors (n8n/NiFi style)

You can create sophisticated visual editors like:
- **n8n** - Workflow automation
- **Apache NiFi** - Data flow programming
- **Altova XMLSpy** - Visual XML/schema editor
- **Houdini** - Procedural node networks
- **Unreal Blueprints** - Visual scripting

Using **Avalonia** for cross-platform native performance.

---

## 🎨 **Visual Editor Components**

### Core UI Elements

```
┌────────────────────────────────────────────────────────────┐
│  Toolbar (Add Nodes, Zoom, Layout)                         │
├────────────────────────────────────────────────────────────┤
│  ┌──────────────┐                                          │
│  │ Node Palette │  Canvas (Infinite Panning/Zooming)       │
│  │              │  ┌──────────┐      ┌──────────┐          │
│  │ • Source     │  │  Source  │──────┤Transform│          │
│  │ • Transform  │  │  Node    │      │  Node    │          │
│  │ • Filter     │  └──────────┘      └──────────┘          │
│  │ • Sink       │       │                  │               │
│  │              │       │            ┌──────────┐          │
│  │              │       └────────────┤   Sink   │          │
│  │              │                    │   Node   │          │
│  └──────────────┘                    └──────────┘          │
│                                                             │
├────────────────────────────────────────────────────────────┤
│  Properties Panel (Selected Node Configuration)            │
└────────────────────────────────────────────────────────────┘
```

---

## 📦 **Technology Stack**

### Required NuGet Packages

```xml
<ItemGroup>
  <!-- Avalonia Core -->
  <PackageReference Include="Avalonia" Version="11.0.7" />
  <PackageReference Include="Avalonia.Desktop" Version="11.0.7" />
  <PackageReference Include="Avalonia.Themes.Fluent" Version="11.0.7" />
  
  <!-- MVVM -->
  <PackageReference Include="ReactiveUI.Avalonia" Version="19.5.31" />
  
  <!-- Graph/Canvas Libraries -->
  <PackageReference Include="Avalonia.Controls.ItemsRepeater" Version="11.0.7" />
  
  <!-- Serialization -->
  <PackageReference Include="System.Text.Json" Version="8.0.0" />
  
  <!-- Optional: Pre-built Graph Library -->
  <PackageReference Include="NodeNetwork" Version="2.0.0" />
  <!-- Or build your own! (recommended for full control) -->
</ItemGroup>
```

---

## 🎯 **Domain Model for Graph Editor**

### 1. Node Model

```csharp
// Domain/Models/Node.cs
using BahyWay.SharedKernel.Domain;

namespace BahyWay.ProcessEditor.Domain.Models;

/// <summary>
/// Represents a node in the process graph.
/// This is a domain entity with business logic.
/// </summary>
public sealed class ProcessNode : Entity<NodeId>
{
    public string Name { get; private set; }
    public NodeType Type { get; private set; }
    public Point Position { get; private set; }
    
    private readonly List<NodePort> _inputPorts = new();
    private readonly List<NodePort> _outputPorts = new();
    private readonly Dictionary<string, object> _properties = new();
    
    public IReadOnlyCollection<NodePort> InputPorts => _inputPorts.AsReadOnly();
    public IReadOnlyCollection<NodePort> OutputPorts => _outputPorts.AsReadOnly();
    public IReadOnlyDictionary<string, object> Properties => _properties.AsReadOnly();
    
    private ProcessNode() { }
    
    public static ProcessNode Create(string name, NodeType type, Point position)
    {
        Guard.Against.NullOrWhiteSpace(name, nameof(name));
        Guard.Against.Null(type, nameof(type));
        
        var node = new ProcessNode
        {
            Id = NodeId.New(),
            Name = name,
            Type = type,
            Position = position
        };
        
        // Initialize ports based on node type
        node.InitializePorts(type);
        
        node.AddDomainEvent(new NodeCreatedEvent(node.Id, node.Name, node.Type));
        
        return node;
    }
    
    public Result AddInputPort(string portName, PortDataType dataType)
    {
        if (_inputPorts.Any(p => p.Name == portName))
        {
            return Result.Failure("Port with this name already exists");
        }
        
        var port = NodePort.CreateInput(portName, dataType);
        _inputPorts.Add(port);
        
        return Result.Success();
    }
    
    public Result AddOutputPort(string portName, PortDataType dataType)
    {
        if (_outputPorts.Any(p => p.Name == portName))
        {
            return Result.Failure("Port with this name already exists");
        }
        
        var port = NodePort.CreateOutput(portName, dataType);
        _outputPorts.Add(port);
        
        return Result.Success();
    }
    
    public void MoveTo(Point newPosition)
    {
        Position = newPosition;
        AddDomainEvent(new NodeMovedEvent(Id, Position));
    }
    
    public Result SetProperty(string key, object value)
    {
        Guard.Against.NullOrWhiteSpace(key, nameof(key));
        
        _properties[key] = value;
        AddDomainEvent(new NodePropertyChangedEvent(Id, key, value));
        
        return Result.Success();
    }
    
    public Result<object> GetProperty(string key)
    {
        if (!_properties.ContainsKey(key))
        {
            return Result.Failure<object>(new Error("Property.NotFound", $"Property '{key}' not found"));
        }
        
        return Result.Success(_properties[key]);
    }
    
    public bool CanConnectTo(ProcessNode targetNode, string outputPortName, string inputPortName)
    {
        var outputPort = _outputPorts.FirstOrDefault(p => p.Name == outputPortName);
        var inputPort = targetNode._inputPorts.FirstOrDefault(p => p.Name == inputPortName);
        
        if (outputPort == null || inputPort == null)
            return false;
        
        // Check data type compatibility
        if (!outputPort.DataType.IsCompatibleWith(inputPort.DataType))
            return false;
        
        // Prevent cycles (would need graph traversal)
        // Prevent self-connections
        if (this.Id == targetNode.Id)
            return false;
        
        return true;
    }
    
    private void InitializePorts(NodeType type)
    {
        // Different node types have different port configurations
        switch (type.Name)
        {
            case "Source":
                AddOutputPort("Output", PortDataType.Any);
                break;
            
            case "Transform":
                AddInputPort("Input", PortDataType.Any);
                AddOutputPort("Output", PortDataType.Any);
                break;
            
            case "Filter":
                AddInputPort("Input", PortDataType.Any);
                AddOutputPort("Passed", PortDataType.Any);
                AddOutputPort("Filtered", PortDataType.Any);
                break;
            
            case "Sink":
                AddInputPort("Input", PortDataType.Any);
                break;
            
            case "Join":
                AddInputPort("Left", PortDataType.Any);
                AddInputPort("Right", PortDataType.Any);
                AddOutputPort("Output", PortDataType.Any);
                break;
        }
    }
}

// Domain/Models/NodeId.cs
public sealed record NodeId
{
    public Guid Value { get; }
    private NodeId(Guid value) { Value = value; }
    public static NodeId New() => new(Guid.NewGuid());
    public static NodeId From(Guid value) => new(value);
    public static NodeId From(string value) => new(Guid.Parse(value));
}

// Domain/Models/NodeType.cs
public sealed class NodeType : Enumeration
{
    public static readonly NodeType Source = new(1, nameof(Source), "📥", "#4CAF50");
    public static readonly NodeType Transform = new(2, nameof(Transform), "⚙️", "#2196F3");
    public static readonly NodeType Filter = new(3, nameof(Filter), "🔍", "#FF9800");
    public static readonly NodeType Join = new(4, nameof(Join), "🔗", "#9C27B0");
    public static readonly NodeType Sink = new(5, nameof(Sink), "📤", "#F44336");
    
    public string Icon { get; }
    public string Color { get; }
    
    private NodeType(int value, string name, string icon, string color) : base(value, name)
    {
        Icon = icon;
        Color = color;
    }
}

// Domain/Models/NodePort.cs
public sealed class NodePort : ValueObject
{
    public string Name { get; }
    public PortDirection Direction { get; }
    public PortDataType DataType { get; }
    
    private NodePort(string name, PortDirection direction, PortDataType dataType)
    {
        Name = name;
        Direction = direction;
        DataType = dataType;
    }
    
    public static NodePort CreateInput(string name, PortDataType dataType)
    {
        return new NodePort(name, PortDirection.Input, dataType);
    }
    
    public static NodePort CreateOutput(string name, PortDataType dataType)
    {
        return new NodePort(name, PortDirection.Output, dataType);
    }
    
    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return Name;
        yield return Direction;
        yield return DataType;
    }
}

public enum PortDirection { Input, Output }

// Domain/Models/PortDataType.cs
public sealed class PortDataType : ValueObject
{
    public static readonly PortDataType Any = new("Any");
    public static readonly PortDataType String = new("String");
    public static readonly PortDataType Number = new("Number");
    public static readonly PortDataType Boolean = new("Boolean");
    public static readonly PortDataType Object = new("Object");
    public static readonly PortDataType Array = new("Array");
    
    public string TypeName { get; }
    
    private PortDataType(string typeName)
    {
        TypeName = typeName;
    }
    
    public bool IsCompatibleWith(PortDataType other)
    {
        // Any type is compatible with everything
        if (this == Any || other == Any)
            return true;
        
        // Same types are compatible
        return this.TypeName == other.TypeName;
    }
    
    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return TypeName;
    }
}

// Domain/Models/Point.cs
public sealed class Point : ValueObject
{
    public double X { get; }
    public double Y { get; }
    
    private Point(double x, double y)
    {
        X = x;
        Y = y;
    }
    
    public static Point Create(double x, double y) => new(x, y);
    public static Point Origin => new(0, 0);
    
    public Point Add(Point other) => new(X + other.X, Y + other.Y);
    public Point Subtract(Point other) => new(X - other.X, Y - other.Y);
    public Point Scale(double factor) => new(X * factor, Y * factor);
    
    public double DistanceTo(Point other)
    {
        var dx = X - other.X;
        var dy = Y - other.Y;
        return Math.Sqrt(dx * dx + dy * dy);
    }
    
    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return X;
        yield return Y;
    }
}
```

### 2. Connection Model

```csharp
// Domain/Models/Connection.cs
public sealed class Connection : Entity<ConnectionId>
{
    public NodeId SourceNodeId { get; private set; }
    public string SourcePortName { get; private set; }
    public NodeId TargetNodeId { get; private set; }
    public string TargetPortName { get; private set; }
    
    private Connection() { }
    
    public static Connection Create(
        NodeId sourceNodeId,
        string sourcePortName,
        NodeId targetNodeId,
        string targetPortName)
    {
        Guard.Against.Null(sourceNodeId, nameof(sourceNodeId));
        Guard.Against.NullOrWhiteSpace(sourcePortName, nameof(sourcePortName));
        Guard.Against.Null(targetNodeId, nameof(targetNodeId));
        Guard.Against.NullOrWhiteSpace(targetPortName, nameof(targetPortName));
        
        var connection = new Connection
        {
            Id = ConnectionId.New(),
            SourceNodeId = sourceNodeId,
            SourcePortName = sourcePortName,
            TargetNodeId = targetNodeId,
            TargetPortName = targetPortName
        };
        
        connection.AddDomainEvent(new ConnectionCreatedEvent(
            connection.Id,
            sourceNodeId,
            sourcePortName,
            targetNodeId,
            targetPortName));
        
        return connection;
    }
}

public sealed record ConnectionId
{
    public Guid Value { get; }
    private ConnectionId(Guid value) { Value = value; }
    public static ConnectionId New() => new(Guid.NewGuid());
    public static ConnectionId From(Guid value) => new(value);
}
```

### 3. Process Graph Aggregate

```csharp
// Domain/Aggregates/ProcessGraph.cs
public sealed class ProcessGraph : AggregateRoot<ProcessGraphId>
{
    public string Name { get; private set; }
    public string? Description { get; private set; }
    
    private readonly List<ProcessNode> _nodes = new();
    private readonly List<Connection> _connections = new();
    
    public IReadOnlyCollection<ProcessNode> Nodes => _nodes.AsReadOnly();
    public IReadOnlyCollection<Connection> Connections => _connections.AsReadOnly();
    
    private ProcessGraph() { }
    
    public static ProcessGraph Create(string name, string? description = null)
    {
        Guard.Against.NullOrWhiteSpace(name, nameof(name));
        
        var graph = new ProcessGraph
        {
            Id = ProcessGraphId.New(),
            Name = name,
            Description = description
        };
        
        graph.AddDomainEvent(new ProcessGraphCreatedEvent(graph.Id, graph.Name));
        
        return graph;
    }
    
    public Result<ProcessNode> AddNode(string name, NodeType type, Point position)
    {
        var node = ProcessNode.Create(name, type, position);
        _nodes.Add(node);
        
        AddDomainEvent(new NodeAddedToGraphEvent(Id, node.Id));
        
        return Result.Success(node);
    }
    
    public Result RemoveNode(NodeId nodeId)
    {
        var node = _nodes.FirstOrDefault(n => n.Id == nodeId);
        if (node == null)
        {
            return Result.Failure(new Error("Node.NotFound", "Node not found"));
        }
        
        // Remove all connections to/from this node
        var connectionsToRemove = _connections
            .Where(c => c.SourceNodeId == nodeId || c.TargetNodeId == nodeId)
            .ToList();
        
        foreach (var connection in connectionsToRemove)
        {
            _connections.Remove(connection);
        }
        
        _nodes.Remove(node);
        
        AddDomainEvent(new NodeRemovedFromGraphEvent(Id, nodeId));
        
        return Result.Success();
    }
    
    public Result<Connection> Connect(
        NodeId sourceNodeId,
        string sourcePortName,
        NodeId targetNodeId,
        string targetPortName)
    {
        var sourceNode = _nodes.FirstOrDefault(n => n.Id == sourceNodeId);
        var targetNode = _nodes.FirstOrDefault(n => n.Id == targetNodeId);
        
        if (sourceNode == null || targetNode == null)
        {
            return Result.Failure<Connection>(new Error("Node.NotFound", "One or both nodes not found"));
        }
        
        // Check if connection is valid
        if (!sourceNode.CanConnectTo(targetNode, sourcePortName, targetPortName))
        {
            return Result.Failure<Connection>(new Error("Connection.Invalid", "Cannot create this connection"));
        }
        
        // Check for existing connection to the same input port
        var existingConnection = _connections.FirstOrDefault(c =>
            c.TargetNodeId == targetNodeId &&
            c.TargetPortName == targetPortName);
        
        if (existingConnection != null)
        {
            // Remove old connection (input ports can only have one connection)
            _connections.Remove(existingConnection);
        }
        
        var connection = Connection.Create(sourceNodeId, sourcePortName, targetNodeId, targetPortName);
        _connections.Add(connection);
        
        AddDomainEvent(new ConnectionCreatedEvent(
            connection.Id,
            sourceNodeId,
            sourcePortName,
            targetNodeId,
            targetPortName));
        
        return Result.Success(connection);
    }
    
    public Result Disconnect(ConnectionId connectionId)
    {
        var connection = _connections.FirstOrDefault(c => c.Id == connectionId);
        if (connection == null)
        {
            return Result.Failure(new Error("Connection.NotFound", "Connection not found"));
        }
        
        _connections.Remove(connection);
        
        AddDomainEvent(new ConnectionRemovedEvent(Id, connectionId));
        
        return Result.Success();
    }
    
    public Result ValidateGraph()
    {
        // Check for cycles
        if (HasCycles())
        {
            return Result.Failure(new Error("Graph.HasCycles", "Graph contains cycles"));
        }
        
        // Check for disconnected nodes
        var disconnectedNodes = _nodes
            .Where(n => !_connections.Any(c => c.SourceNodeId == n.Id || c.TargetNodeId == n.Id))
            .ToList();
        
        if (disconnectedNodes.Any())
        {
            return Result.Failure(new Error(
                "Graph.DisconnectedNodes",
                $"{disconnectedNodes.Count} nodes are not connected"));
        }
        
        return Result.Success();
    }
    
    private bool HasCycles()
    {
        var visited = new HashSet<NodeId>();
        var recursionStack = new HashSet<NodeId>();
        
        foreach (var node in _nodes)
        {
            if (HasCyclesUtil(node.Id, visited, recursionStack))
            {
                return true;
            }
        }
        
        return false;
    }
    
    private bool HasCyclesUtil(NodeId nodeId, HashSet<NodeId> visited, HashSet<NodeId> recursionStack)
    {
        if (recursionStack.Contains(nodeId))
            return true;
        
        if (visited.Contains(nodeId))
            return false;
        
        visited.Add(nodeId);
        recursionStack.Add(nodeId);
        
        var outgoingConnections = _connections.Where(c => c.SourceNodeId == nodeId);
        foreach (var connection in outgoingConnections)
        {
            if (HasCyclesUtil(connection.TargetNodeId, visited, recursionStack))
                return true;
        }
        
        recursionStack.Remove(nodeId);
        return false;
    }
    
    public List<ProcessNode> GetTopologicalOrder()
    {
        var result = new List<ProcessNode>();
        var visited = new HashSet<NodeId>();
        var stack = new Stack<ProcessNode>();
        
        foreach (var node in _nodes)
        {
            if (!visited.Contains(node.Id))
            {
                TopologicalSortUtil(node, visited, stack);
            }
        }
        
        while (stack.Count > 0)
        {
            result.Add(stack.Pop());
        }
        
        return result;
    }
    
    private void TopologicalSortUtil(ProcessNode node, HashSet<NodeId> visited, Stack<ProcessNode> stack)
    {
        visited.Add(node.Id);
        
        var outgoingConnections = _connections.Where(c => c.SourceNodeId == node.Id);
        foreach (var connection in outgoingConnections)
        {
            var targetNode = _nodes.First(n => n.Id == connection.TargetNodeId);
            if (!visited.Contains(targetNode.Id))
            {
                TopologicalSortUtil(targetNode, visited, stack);
            }
        }
        
        stack.Push(node);
    }
}

public sealed record ProcessGraphId
{
    public Guid Value { get; }
    private ProcessGraphId(Guid value) { Value = value; }
    public static ProcessGraphId New() => new(Guid.NewGuid());
    public static ProcessGraphId From(Guid value) => new(value);
}
```

---

## 🎨 **Avalonia UI Implementation**

### 1. Node View (XAML)

```xml
<!-- Views/Controls/NodeView.axaml -->
<UserControl xmlns="https://github.com/avaloniaui"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
             xmlns:vm="using:BahyWay.ProcessEditor.ViewModels"
             x:Class="BahyWay.ProcessEditor.Views.Controls.NodeView"
             x:DataType="vm:NodeViewModel"
             Width="200">
    
    <Border BorderBrush="{Binding TypeColor}"
            BorderThickness="2"
            CornerRadius="8"
            Background="#1E1E1E"
            Cursor="Hand"
            Padding="12">
        
        <StackPanel Spacing="8">
            <!-- Node Header -->
            <Grid ColumnDefinitions="Auto,*,Auto">
                <TextBlock Grid.Column="0"
                           Text="{Binding TypeIcon}"
                           FontSize="16"
                           VerticalAlignment="Center"/>
                
                <TextBlock Grid.Column="1"
                           Text="{Binding Name}"
                           FontWeight="Bold"
                           Margin="8,0"
                           VerticalAlignment="Center"/>
                
                <Button Grid.Column="2"
                        Content="⚙"
                        Command="{Binding OpenSettingsCommand}"
                        Background="Transparent"
                        BorderThickness="0"/>
            </Grid>
            
            <!-- Input Ports -->
            <ItemsControl Items="{Binding InputPorts}">
                <ItemsControl.ItemTemplate>
                    <DataTemplate>
                        <Grid ColumnDefinitions="Auto,*" Margin="0,4">
                            <Ellipse Grid.Column="0"
                                     Width="12" Height="12"
                                     Fill="#4CAF50"
                                     Cursor="Hand"/>
                            <TextBlock Grid.Column="1"
                                       Text="{Binding Name}"
                                       Margin="8,0"
                                       FontSize="12"/>
                        </Grid>
                    </DataTemplate>
                </ItemsControl.ItemTemplate>
            </ItemsControl>
            
            <!-- Output Ports -->
            <ItemsControl Items="{Binding OutputPorts}">
                <ItemsControl.ItemTemplate>
                    <DataTemplate>
                        <Grid ColumnDefinitions="*,Auto" Margin="0,4">
                            <TextBlock Grid.Column="0"
                                       Text="{Binding Name}"
                                       Margin="0,0,8,0"
                                       FontSize="12"
                                       HorizontalAlignment="Right"/>
                            <Ellipse Grid.Column="1"
                                     Width="12" Height="12"
                                     Fill="#2196F3"
                                     Cursor="Hand"/>
                        </Grid>
                    </DataTemplate>
                </ItemsControl.ItemTemplate>
            </ItemsControl>
        </StackPanel>
    </Border>
</UserControl>
```

### 2. Graph Canvas View

```xml
<!-- Views/GraphCanvasView.axaml -->
<UserControl xmlns="https://github.com/avaloniaui"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
             xmlns:vm="using:BahyWay.ProcessEditor.ViewModels"
             x:Class="BahyWay.ProcessEditor.Views.GraphCanvasView"
             x:DataType="vm:GraphCanvasViewModel">
    
    <Grid>
        <!-- Canvas with Pan/Zoom -->
        <Panel Name="CanvasPanel"
               Background="#252525"
               ClipToBounds="True">
            
            <!-- Grid Background -->
            <Canvas Name="GridCanvas">
                <!-- Draw grid lines here -->
            </Canvas>
            
            <!-- Transform for Pan/Zoom -->
            <Panel RenderTransform="{Binding CanvasTransform}">
                
                <!-- Connections Layer -->
                <Canvas Name="ConnectionsCanvas">
                    <ItemsControl Items="{Binding Connections}">
                        <ItemsControl.ItemTemplate>
                            <DataTemplate>
                                <!-- Connection Line (Bezier Curve) -->
                                <Path Stroke="#666"
                                      StrokeThickness="2"
                                      Data="{Binding PathGeometry}"/>
                            </DataTemplate>
                        </ItemsControl.ItemTemplate>
                    </ItemsControl>
                </Canvas>
                
                <!-- Nodes Layer -->
                <ItemsControl Items="{Binding Nodes}">
                    <ItemsControl.ItemsPanel>
                        <ItemsPanelTemplate>
                            <Canvas/>
                        </ItemsPanelTemplate>
                    </ItemsControl.ItemsPanel>
                    
                    <ItemsControl.ItemTemplate>
                        <DataTemplate>
                            <controls:NodeView DataContext="{Binding}"/>
                        </DataTemplate>
                    </ItemsControl.ItemTemplate>
                    
                    <ItemsControl.Styles>
                        <Style Selector="ContentPresenter">
                            <Setter Property="Canvas.Left" Value="{Binding X}"/>
                            <Setter Property="Canvas.Top" Value="{Binding Y}"/>
                        </Style>
                    </ItemsControl.Styles>
                </ItemsControl>
            </Panel>
        </Panel>
        
        <!-- Minimap (optional) -->
        <Border Background="#1E1E1E"
                BorderBrush="#444"
                BorderThickness="1"
                CornerRadius="4"
                Padding="8"
                Width="200"
                Height="150"
                HorizontalAlignment="Right"
                VerticalAlignment="Bottom"
                Margin="16">
            <!-- Minimap content -->
        </Border>
    </Grid>
</UserControl>
```

### 3. ViewModels

```csharp
// ViewModels/NodeViewModel.cs
using ReactiveUI;
using System.Reactive;

public class NodeViewModel : ViewModelBase
{
    private double _x;
    private double _y;
    private bool _isSelected;
    
    public NodeId NodeId { get; }
    public string Name { get; set; }
    public string TypeIcon { get; set; }
    public string TypeColor { get; set; }
    
    public double X
    {
        get => _x;
        set => this.RaiseAndSetIfChanged(ref _x, value);
    }
    
    public double Y
    {
        get => _y;
        set => this.RaiseAndSetIfChanged(ref _y, value);
    }
    
    public bool IsSelected
    {
        get => _isSelected;
        set => this.RaiseAndSetIfChanged(ref _isSelected, value);
    }
    
    public ObservableCollection<PortViewModel> InputPorts { get; } = new();
    public ObservableCollection<PortViewModel> OutputPorts { get; } = new();
    
    public ReactiveCommand<Unit, Unit> OpenSettingsCommand { get; }
    
    public NodeViewModel(ProcessNode node)
    {
        NodeId = node.Id;
        Name = node.Name;
        TypeIcon = node.Type.Icon;
        TypeColor = node.Type.Color;
        X = node.Position.X;
        Y = node.Position.Y;
        
        // Map ports
        foreach (var port in node.InputPorts)
        {
            InputPorts.Add(new PortViewModel(port, this));
        }
        
        foreach (var port in node.OutputPorts)
        {
            OutputPorts.Add(new PortViewModel(port, this));
        }
        
        OpenSettingsCommand = ReactiveCommand.Create(OpenSettings);
    }
    
    private void OpenSettings()
    {
        // Open properties panel
    }
    
    public void UpdatePosition(double newX, double newY)
    {
        X = newX;
        Y = newY;
    }
}

// ViewModels/GraphCanvasViewModel.cs
public class GraphCanvasViewModel : ViewModelBase
{
    private ProcessGraph _graph;
    private Matrix _canvasTransform = Matrix.Identity;
    private double _zoom = 1.0;
    
    public ObservableCollection<NodeViewModel> Nodes { get; } = new();
    public ObservableCollection<ConnectionViewModel> Connections { get; } = new();
    
    public Matrix CanvasTransform
    {
        get => _canvasTransform;
        set => this.RaiseAndSetIfChanged(ref _canvasTransform, value);
    }
    
    public ReactiveCommand<NodeType, Unit> AddNodeCommand { get; }
    public ReactiveCommand<Unit, Unit> DeleteSelectedCommand { get; }
    public ReactiveCommand<Unit, Unit> ZoomInCommand { get; }
    public ReactiveCommand<Unit, Unit> ZoomOutCommand { get; }
    
    public GraphCanvasViewModel(ProcessGraph graph)
    {
        _graph = graph;
        
        // Initialize from domain model
        foreach (var node in graph.Nodes)
        {
            Nodes.Add(new NodeViewModel(node));
        }
        
        foreach (var connection in graph.Connections)
        {
            Connections.Add(new ConnectionViewModel(connection, Nodes));
        }
        
        AddNodeCommand = ReactiveCommand.Create<NodeType>(AddNode);
        DeleteSelectedCommand = ReactiveCommand.Create(DeleteSelected);
        ZoomInCommand = ReactiveCommand.Create(ZoomIn);
        ZoomOutCommand = ReactiveCommand.Create(ZoomOut);
    }
    
    private void AddNode(NodeType type)
    {
        var centerPosition = Point.Create(400, 300); // Or calculate from viewport
        var result = _graph.AddNode($"New {type.Name}", type, centerPosition);
        
        if (result.IsSuccess)
        {
            Nodes.Add(new NodeViewModel(result.Value));
        }
    }
    
    private void DeleteSelected()
    {
        var selectedNodes = Nodes.Where(n => n.IsSelected).ToList();
        foreach (var node in selectedNodes)
        {
            _graph.RemoveNode(node.NodeId);
            Nodes.Remove(node);
            
            // Remove connections
            var relatedConnections = Connections
                .Where(c => c.SourceNodeId == node.NodeId || c.TargetNodeId == node.NodeId)
                .ToList();
            
            foreach (var conn in relatedConnections)
            {
                Connections.Remove(conn);
            }
        }
    }
    
    private void ZoomIn()
    {
        _zoom = Math.Min(_zoom * 1.2, 3.0);
        UpdateTransform();
    }
    
    private void ZoomOut()
    {
        _zoom = Math.Max(_zoom / 1.2, 0.25);
        UpdateTransform();
    }
    
    private void UpdateTransform()
    {
        CanvasTransform = Matrix.CreateScale(_zoom, _zoom);
    }
    
    public void HandleNodeDrag(NodeViewModel node, double deltaX, double deltaY)
    {
        node.UpdatePosition(node.X + deltaX, node.Y + deltaY);
        
        // Update connections
        UpdateConnections(node);
    }
    
    public void CreateConnection(PortViewModel sourcePort, PortViewModel targetPort)
    {
        var result = _graph.Connect(
            sourcePort.OwnerNode.NodeId,
            sourcePort.Name,
            targetPort.OwnerNode.NodeId,
            targetPort.Name);
        
        if (result.IsSuccess)
        {
            Connections.Add(new ConnectionViewModel(result.Value, Nodes));
        }
    }
    
    private void UpdateConnections(NodeViewModel node)
    {
        var relatedConnections = Connections
            .Where(c => c.SourceNodeId == node.NodeId || c.TargetNodeId == node.NodeId);
        
        foreach (var connection in relatedConnections)
        {
            connection.UpdatePath();
        }
    }
}
```

---

## ⚡ **Performance Optimizations**

### 1. Virtualization

```csharp
// Only render nodes visible in viewport
public class ViewportCulling
{
    public IEnumerable<NodeViewModel> GetVisibleNodes(
        Rect viewport,
        IEnumerable<NodeViewModel> allNodes)
    {
        return allNodes.Where(node =>
        {
            var nodeBounds = new Rect(node.X, node.Y, 200, 150);
            return viewport.Intersects(nodeBounds);
        });
    }
}
```

### 2. Connection Rendering

```csharp
// Use Bezier curves for smooth connections
public static PathGeometry CreateConnectionPath(
    Point start,
    Point end)
{
    var pathFigure = new PathFigure { StartPoint = start };
    
    // Calculate control points for Bezier curve
    var dx = Math.Abs(end.X - start.X);
    var handleDistance = Math.Min(dx * 0.5, 200);
    
    var control1 = new Point(start.X + handleDistance, start.Y);
    var control2 = new Point(end.X - handleDistance, end.Y);
    
    pathFigure.Segments.Add(new BezierSegment
    {
        Point1 = control1,
        Point2 = control2,
        Point3 = end
    });
    
    return new PathGeometry { Figures = { pathFigure } };
}
```

---

## 💾 **Serialization (Save/Load)**

```csharp
// Application/Services/GraphSerializationService.cs
public class GraphSerializationService
{
    public async Task<Result> SaveGraphAsync(ProcessGraph graph, string filePath)
    {
        try
        {
            var dto = new ProcessGraphDto
            {
                Id = graph.Id.Value,
                Name = graph.Name,
                Description = graph.Description,
                Nodes = graph.Nodes.Select(n => new NodeDto
                {
                    Id = n.Id.Value,
                    Name = n.Name,
                    Type = n.Type.Name,
                    X = n.Position.X,
                    Y = n.Position.Y,
                    Properties = n.Properties.ToDictionary(p => p.Key, p => p.Value)
                }).ToList(),
                Connections = graph.Connections.Select(c => new ConnectionDto
                {
                    Id = c.Id.Value,
                    SourceNodeId = c.SourceNodeId.Value,
                    SourcePort = c.SourcePortName,
                    TargetNodeId = c.TargetNodeId.Value,
                    TargetPort = c.TargetPortName
                }).ToList()
            };
            
            var json = JsonSerializer.Serialize(dto, new JsonSerializerOptions
            {
                WriteIndented = true
            });
            
            await File.WriteAllTextAsync(filePath, json);
            
            return Result.Success();
        }
        catch (Exception ex)
        {
            return Result.Failure(new Error("Graph.SaveFailed", ex.Message));
        }
    }
    
    public async Task<Result<ProcessGraph>> LoadGraphAsync(string filePath)
    {
        try
        {
            var json = await File.ReadAllTextAsync(filePath);
            var dto = JsonSerializer.Deserialize<ProcessGraphDto>(json);
            
            if (dto == null)
            {
                return Result.Failure<ProcessGraph>(new Error("Graph.LoadFailed", "Invalid file format"));
            }
            
            // Reconstruct domain model from DTO
            var graph = ProcessGraph.Create(dto.Name, dto.Description);
            
            // Add nodes
            foreach (var nodeDto in dto.Nodes)
            {
                var nodeType = NodeType.FromName<NodeType>(nodeDto.Type);
                var position = Point.Create(nodeDto.X, nodeDto.Y);
                var nodeResult = graph.AddNode(nodeDto.Name, nodeType, position);
                
                if (nodeResult.IsSuccess)
                {
                    // Set properties
                    foreach (var prop in nodeDto.Properties)
                    {
                        nodeResult.Value.SetProperty(prop.Key, prop.Value);
                    }
                }
            }
            
            // Add connections
            foreach (var connDto in dto.Connections)
            {
                graph.Connect(
                    NodeId.From(connDto.SourceNodeId),
                    connDto.SourcePort,
                    NodeId.From(connDto.TargetNodeId),
                    connDto.TargetPort);
            }
            
            return Result.Success(graph);
        }
        catch (Exception ex)
        {
            return Result.Failure<ProcessGraph>(new Error("Graph.LoadFailed", ex.Message));
        }
    }
}
```

---

## 🎯 **Complete Features List**

✅ **Node Management**
- Add/remove nodes
- Drag and drop
- Copy/paste
- Undo/redo

✅ **Connection Management**
- Visual connection drawing
- Type checking
- Cycle detection
- Connection validation

✅ **Canvas Operations**
- Pan (middle mouse drag)
- Zoom (mouse wheel)
- Fit to view
- Grid snapping

✅ **Node Editor**
- Properties panel
- Input validation
- Real-time preview

✅ **Graph Operations**
- Topological sort
- Execution order
- Validation
- Export/import

✅ **Advanced Features**
- Minimap
- Search/filter nodes
- Group/ungroup
- Layers
- Comments/annotations

---

**Next: I'll create the Avalonia project setup and interaction handlers!**
