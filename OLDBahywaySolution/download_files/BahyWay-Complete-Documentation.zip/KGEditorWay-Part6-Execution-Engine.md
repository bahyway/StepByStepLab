# KGEditorWay - Part 6: Graph Execution Engine

## 🚀 Overview

Complete **Process Execution Engine** for executing visual graphs as workflows, including:
- Node-by-node execution orchestration
- Step-by-step debugging
- Data flow between nodes
- Execution context management
- Progress monitoring
- Error handling and rollback

---

## 📦 Project Structure

```
BahyWay.KGEditorWay.Execution/
├── Core/
│   ├── IExecutionEngine.cs              # Main execution interface
│   ├── ExecutionEngine.cs               # Orchestrator
│   ├── ExecutionContext.cs              # Runtime context
│   └── ExecutionResult.cs               # Execution results
├── Nodes/
│   ├── INodeExecutor.cs                 # Base node executor
│   ├── SourceNodeExecutor.cs            # Data sources
│   ├── TransformNodeExecutor.cs         # Transformations
│   ├── FilterNodeExecutor.cs            # Filtering
│   ├── SinkNodeExecutor.cs              # Data sinks
│   └── ExecutorRegistry.cs              # Executor factory
├── DataFlow/
│   ├── DataPacket.cs                    # Data between nodes
│   ├── DataBuffer.cs                    # Node buffers
│   └── DataFlowManager.cs               # Flow control
├── Debugging/
│   ├── IDebugger.cs                     # Debugger interface
│   ├── Breakpoint.cs                    # Breakpoints
│   ├── StepExecutor.cs                  # Step-by-step
│   └── ExecutionTracer.cs               # Execution trace
├── Monitoring/
│   ├── ExecutionMonitor.cs              # Progress tracking
│   ├── PerformanceMetrics.cs            # Performance data
│   └── ExecutionLogger.cs               # Logging
└── Services/
    ├── ExecutionService.cs              # High-level service
    └── ExecutionScheduler.cs            # Scheduling
```

---

## 🎯 Core Execution Engine

### IExecutionEngine.cs

```csharp
// Execution/Core/IExecutionEngine.cs
using System;
using System.Threading;
using System.Threading.Tasks;
using BahyWay.SharedKernel.Results;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.KGEditorWay.Execution.Core;

public interface IExecutionEngine
{
    Task<Result<ExecutionResult>> ExecuteAsync(
        Graph graph,
        ExecutionContext context,
        CancellationToken cancellationToken = default);
    
    Task<r> PauseAsync();
    Task<r> ResumeAsync();
    Task<r> StopAsync();
    
    event EventHandler<NodeExecutedEventArgs> NodeExecuted;
    event EventHandler<ExecutionProgressEventArgs> ProgressChanged;
    event EventHandler<ExecutionErrorEventArgs> ExecutionError;
}

public class NodeExecutedEventArgs : EventArgs
{
    public NodeId NodeId { get; set; }
    public ExecutionStatus Status { get; set; }
    public object? OutputData { get; set; }
    public TimeSpan Duration { get; set; }
}

public class ExecutionProgressEventArgs : EventArgs
{
    public int CompletedNodes { get; set; }
    public int TotalNodes { get; set; }
    public double ProgressPercentage { get; set; }
}

public class ExecutionErrorEventArgs : EventArgs
{
    public NodeId NodeId { get; set; }
    public Exception Exception { get; set; }
    public bool CanContinue { get; set; }
}

public enum ExecutionStatus
{
    NotStarted,
    Running,
    Paused,
    Completed,
    Failed,
    Cancelled
}
```

### ExecutionEngine.cs

```csharp
// Execution/Core/ExecutionEngine.cs
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using BahyWay.SharedKernel.Results;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;
using BahyWay.KGEditorWay.Execution.Nodes;
using BahyWay.KGEditorWay.Execution.DataFlow;

namespace BahyWay.KGEditorWay.Execution.Core;

public class ExecutionEngine : IExecutionEngine
{
    private readonly IExecutorRegistry _executorRegistry;
    private readonly IDataFlowManager _dataFlowManager;
    private readonly IExecutionLogger _logger;
    
    private ExecutionStatus _status = ExecutionStatus.NotStarted;
    private CancellationTokenSource? _pauseTokenSource;
    
    public event EventHandler<NodeExecutedEventArgs>? NodeExecuted;
    public event EventHandler<ExecutionProgressEventArgs>? ProgressChanged;
    public event EventHandler<ExecutionErrorEventArgs>? ExecutionError;
    
    public ExecutionEngine(
        IExecutorRegistry executorRegistry,
        IDataFlowManager dataFlowManager,
        IExecutionLogger logger)
    {
        _executorRegistry = executorRegistry;
        _dataFlowManager = dataFlowManager;
        _logger = logger;
    }
    
    public async Task<Result<ExecutionResult>> ExecuteAsync(
        Graph graph,
        ExecutionContext context,
        CancellationToken cancellationToken = default)
    {
        try
        {
            _status = ExecutionStatus.Running;
            _logger.LogInfo($"Starting execution of graph: {graph.Name}");
            
            var result = new ExecutionResult
            {
                GraphId = graph.Id,
                StartTime = DateTime.UtcNow
            };
            
            // Validate graph
            var validationResult = await ValidateGraphAsync(graph);
            if (validationResult.IsFailure)
            {
                _status = ExecutionStatus.Failed;
                return Result.Failure<ExecutionResult>(validationResult.Error);
            }
            
            // Get execution order (topological sort)
            var executionOrder = GetExecutionOrder(graph);
            
            if (executionOrder.IsFailure)
            {
                _status = ExecutionStatus.Failed;
                return Result.Failure<ExecutionResult>(executionOrder.Error);
            }
            
            var totalNodes = executionOrder.Value.Count;
            var completedNodes = 0;
            
            // Execute nodes in order
            foreach (var node in executionOrder.Value)
            {
                // Check for cancellation
                if (cancellationToken.IsCancellationRequested)
                {
                    _status = ExecutionStatus.Cancelled;
                    result.Status = ExecutionStatus.Cancelled;
                    return Result.Success(result);
                }
                
                // Check for pause
                if (_pauseTokenSource != null)
                {
                    _status = ExecutionStatus.Paused;
                    await _pauseTokenSource.Token.WaitHandle.WaitOneAsync();
                    _status = ExecutionStatus.Running;
                }
                
                // Execute node
                var nodeResult = await ExecuteNodeAsync(node, context, cancellationToken);
                
                if (nodeResult.IsFailure)
                {
                    _status = ExecutionStatus.Failed;
                    
                    var errorArgs = new ExecutionErrorEventArgs
                    {
                        NodeId = node.Id,
                        Exception = new Exception(nodeResult.Error.Description),
                        CanContinue = false
                    };
                    
                    ExecutionError?.Invoke(this, errorArgs);
                    
                    if (!errorArgs.CanContinue)
                    {
                        result.Status = ExecutionStatus.Failed;
                        result.Error = nodeResult.Error;
                        return Result.Failure<ExecutionResult>(nodeResult.Error);
                    }
                }
                
                completedNodes++;
                
                // Report progress
                ProgressChanged?.Invoke(this, new ExecutionProgressEventArgs
                {
                    CompletedNodes = completedNodes,
                    TotalNodes = totalNodes,
                    ProgressPercentage = (double)completedNodes / totalNodes * 100
                });
            }
            
            _status = ExecutionStatus.Completed;
            result.Status = ExecutionStatus.Completed;
            result.EndTime = DateTime.UtcNow;
            result.Duration = result.EndTime - result.StartTime;
            
            _logger.LogInfo($"Graph execution completed in {result.Duration.TotalSeconds:F2}s");
            
            return Result.Success(result);
        }
        catch (Exception ex)
        {
            _status = ExecutionStatus.Failed;
            _logger.LogError($"Graph execution failed: {ex.Message}");
            return Result.Failure<ExecutionResult>(
                new Error("Execution.Failed", ex.Message));
        }
    }
    
    private async Task<Result<object?>> ExecuteNodeAsync(
        Node node,
        ExecutionContext context,
        CancellationToken cancellationToken)
    {
        var stopwatch = Stopwatch.StartNew();
        
        try
        {
            _logger.LogDebug($"Executing node: {node.Name} ({node.Type.Name})");
            
            // Get executor for node type
            var executor = _executorRegistry.GetExecutor(node.Type);
            
            if (executor == null)
            {
                return Result.Failure<object?>(
                    new Error("Execution.NoExecutor", 
                        $"No executor found for node type: {node.Type.Name}"));
            }
            
            // Get input data from connected nodes
            var inputData = await _dataFlowManager.GetInputDataAsync(node.Id);
            
            // Execute node
            var result = await executor.ExecuteAsync(node, inputData, context, cancellationToken);
            
            if (result.IsFailure)
            {
                _logger.LogError($"Node execution failed: {node.Name} - {result.Error.Description}");
                return result;
            }
            
            // Store output data for downstream nodes
            await _dataFlowManager.SetOutputDataAsync(node.Id, result.Value);
            
            stopwatch.Stop();
            
            // Raise event
            NodeExecuted?.Invoke(this, new NodeExecutedEventArgs
            {
                NodeId = node.Id,
                Status = ExecutionStatus.Completed,
                OutputData = result.Value,
                Duration = stopwatch.Elapsed
            });
            
            _logger.LogDebug($"Node executed successfully: {node.Name} ({stopwatch.ElapsedMilliseconds}ms)");
            
            return result;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            
            _logger.LogError($"Node execution exception: {node.Name} - {ex.Message}");
            
            NodeExecuted?.Invoke(this, new NodeExecutedEventArgs
            {
                NodeId = node.Id,
                Status = ExecutionStatus.Failed,
                Duration = stopwatch.Elapsed
            });
            
            return Result.Failure<object?>(
                new Error("Execution.NodeFailed", ex.Message));
        }
    }
    
    private Result<List<Node>> GetExecutionOrder(Graph graph)
    {
        try
        {
            // Topological sort
            var visited = new HashSet<NodeId>();
            var stack = new Stack<Node>();
            var inProgress = new HashSet<NodeId>();
            
            foreach (var node in graph.Nodes)
            {
                if (!visited.Contains(node.Id))
                {
                    var result = TopologicalSortVisit(graph, node, visited, stack, inProgress);
                    if (result.IsFailure)
                        return result;
                }
            }
            
            return Result.Success(stack.ToList());
        }
        catch (Exception ex)
        {
            return Result.Failure<List<Node>>(
                new Error("Execution.SortFailed", ex.Message));
        }
    }
    
    private Result<bool> TopologicalSortVisit(
        Graph graph,
        Node node,
        HashSet<NodeId> visited,
        Stack<Node> stack,
        HashSet<NodeId> inProgress)
    {
        if (inProgress.Contains(node.Id))
        {
            return Result.Failure<bool>(
                new Error("Execution.CyclicDependency", 
                    "Cyclic dependency detected in graph"));
        }
        
        if (visited.Contains(node.Id))
            return Result.Success(true);
        
        inProgress.Add(node.Id);
        
        // Visit dependencies (nodes connected to this node's inputs)
        var dependencies = graph.GetIncomingNodes(node.Id);
        
        foreach (var dependency in dependencies)
        {
            var result = TopologicalSortVisit(graph, dependency, visited, stack, inProgress);
            if (result.IsFailure)
                return result;
        }
        
        inProgress.Remove(node.Id);
        visited.Add(node.Id);
        stack.Push(node);
        
        return Result.Success(true);
    }
    
    private async Task<r> ValidateGraphAsync(Graph graph)
    {
        // Check for cycles
        var hasCycle = graph.HasCycle();
        if (hasCycle)
        {
            return Result.Failure(
                new Error("Execution.ValidationFailed", "Graph contains cycles"));
        }
        
        // Check all nodes have executors
        foreach (var node in graph.Nodes)
        {
            var executor = _executorRegistry.GetExecutor(node.Type);
            if (executor == null)
            {
                return Result.Failure(
                    new Error("Execution.ValidationFailed", 
                        $"No executor for node type: {node.Type.Name}"));
            }
        }
        
        return await Task.FromResult(Result.Success());
    }
    
    public async Task<r> PauseAsync()
    {
        _pauseTokenSource = new CancellationTokenSource();
        _status = ExecutionStatus.Paused;
        return await Task.FromResult(Result.Success());
    }
    
    public async Task<r> ResumeAsync()
    {
        _pauseTokenSource?.Cancel();
        _pauseTokenSource = null;
        _status = ExecutionStatus.Running;
        return await Task.FromResult(Result.Success());
    }
    
    public async Task<r> StopAsync()
    {
        _status = ExecutionStatus.Cancelled;
        return await Task.FromResult(Result.Success());
    }
}

public class ExecutionResult
{
    public GraphId GraphId { get; set; }
    public ExecutionStatus Status { get; set; }
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
    public TimeSpan Duration { get; set; }
    public Error? Error { get; set; }
    public Dictionary<string, object> Metrics { get; set; } = new();
}
```

---

## 🔧 Node Executors

### INodeExecutor.cs

```csharp
// Execution/Nodes/INodeExecutor.cs
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using BahyWay.SharedKernel.Results;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.KGEditorWay.Execution.Nodes;

public interface INodeExecutor
{
    Task<Result<object?>> ExecuteAsync(
        Node node,
        Dictionary<string, object?> inputData,
        ExecutionContext context,
        CancellationToken cancellationToken);
    
    Task<r> ValidateAsync(Node node);
}
```

### SourceNodeExecutor.cs

```csharp
// Execution/Nodes/SourceNodeExecutor.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using BahyWay.SharedKernel.Results;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.KGEditorWay.Execution.Nodes;

public class CsvSourceNodeExecutor : INodeExecutor
{
    public async Task<Result<object?>> ExecuteAsync(
        Node node,
        Dictionary<string, object?> inputData,
        ExecutionContext context,
        CancellationToken cancellationToken)
    {
        try
        {
            var filePath = node.GetProperty<string>("FilePath");
            var delimiter = node.GetProperty<string>("Delimiter") ?? ",";
            var hasHeader = node.GetProperty<bool>("HasHeader");
            
            if (string.IsNullOrEmpty(filePath))
            {
                return Result.Failure<object?>(
                    new Error("CsvSource.NoFilePath", "File path is required"));
            }
            
            if (!File.Exists(filePath))
            {
                return Result.Failure<object?>(
                    new Error("CsvSource.FileNotFound", $"File not found: {filePath}"));
            }
            
            var lines = await File.ReadAllLinesAsync(filePath, cancellationToken);
            
            if (lines.Length == 0)
            {
                return Result.Success<object?>(new List<Dictionary<string, string>>());
            }
            
            var data = new List<Dictionary<string, string>>();
            string[]? headers = null;
            
            var startIndex = 0;
            if (hasHeader)
            {
                headers = lines[0].Split(delimiter);
                startIndex = 1;
            }
            
            for (int i = startIndex; i < lines.Length; i++)
            {
                if (cancellationToken.IsCancellationRequested)
                    break;
                
                var values = lines[i].Split(delimiter);
                var row = new Dictionary<string, string>();
                
                for (int j = 0; j < values.Length; j++)
                {
                    var key = headers != null && j < headers.Length 
                        ? headers[j] 
                        : $"Column{j}";
                    row[key] = values[j];
                }
                
                data.Add(row);
            }
            
            context.SetMetric($"{node.Name}.RowsRead", data.Count);
            
            return Result.Success<object?>(data);
        }
        catch (Exception ex)
        {
            return Result.Failure<object?>(
                new Error("CsvSource.ExecutionFailed", ex.Message));
        }
    }
    
    public async Task<r> ValidateAsync(Node node)
    {
        var filePath = node.GetProperty<string>("FilePath");
        
        if (string.IsNullOrEmpty(filePath))
        {
            return Result.Failure(
                new Error("CsvSource.Validation", "File path is required"));
        }
        
        return await Task.FromResult(Result.Success());
    }
}

public class DatabaseSourceNodeExecutor : INodeExecutor
{
    public async Task<Result<object?>> ExecuteAsync(
        Node node,
        Dictionary<string, object?> inputData,
        ExecutionContext context,
        CancellationToken cancellationToken)
    {
        try
        {
            var connectionString = node.GetProperty<string>("ConnectionString");
            var query = node.GetProperty<string>("Query");
            
            // TODO: Execute database query using ADO.NET or Dapper
            // For now, return mock data
            
            var data = new List<Dictionary<string, object>>
            {
                new() { ["id"] = 1, ["name"] = "Item 1" },
                new() { ["id"] = 2, ["name"] = "Item 2" }
            };
            
            return Result.Success<object?>(data);
        }
        catch (Exception ex)
        {
            return Result.Failure<object?>(
                new Error("DbSource.ExecutionFailed", ex.Message));
        }
    }
    
    public async Task<r> ValidateAsync(Node node)
    {
        // Validate connection string and query
        return await Task.FromResult(Result.Success());
    }
}
```

### TransformNodeExecutor.cs

```csharp
// Execution/Nodes/TransformNodeExecutor.cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using BahyWay.SharedKernel.Results;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.KGEditorWay.Execution.Nodes;

public class MapTransformExecutor : INodeExecutor
{
    public async Task<Result<object?>> ExecuteAsync(
        Node node,
        Dictionary<string, object?> inputData,
        ExecutionContext context,
        CancellationToken cancellationToken)
    {
        try
        {
            var expression = node.GetProperty<string>("Expression");
            var input = inputData.GetValueOrDefault("input");
            
            if (input is not IEnumerable<object> inputList)
            {
                return Result.Failure<object?>(
                    new Error("Map.InvalidInput", "Input must be a list"));
            }
            
            var result = new List<object>();
            
            foreach (var item in inputList)
            {
                if (cancellationToken.IsCancellationRequested)
                    break;
                
                // Apply transformation expression
                // TODO: Implement expression evaluation (could use Roslyn or DLR)
                var transformedItem = TransformItem(item, expression);
                result.Add(transformedItem);
            }
            
            context.SetMetric($"{node.Name}.ItemsProcessed", result.Count);
            
            return Result.Success<object?>(result);
        }
        catch (Exception ex)
        {
            return Result.Failure<object?>(
                new Error("Map.ExecutionFailed", ex.Message));
        }
    }
    
    private object TransformItem(object item, string expression)
    {
        // Simple transformation logic
        // In production, use Roslyn or similar
        return item;
    }
    
    public async Task<r> ValidateAsync(Node node)
    {
        var expression = node.GetProperty<string>("Expression");
        
        if (string.IsNullOrEmpty(expression))
        {
            return Result.Failure(
                new Error("Map.Validation", "Expression is required"));
        }
        
        return await Task.FromResult(Result.Success());
    }
}

public class FilterTransformExecutor : INodeExecutor
{
    public async Task<Result<object?>> ExecuteAsync(
        Node node,
        Dictionary<string, object?> inputData,
        ExecutionContext context,
        CancellationToken cancellationToken)
    {
        try
        {
            var condition = node.GetProperty<string>("Condition");
            var input = inputData.GetValueOrDefault("input");
            
            if (input is not IEnumerable<object> inputList)
            {
                return Result.Failure<object?>(
                    new Error("Filter.InvalidInput", "Input must be a list"));
            }
            
            var result = new List<object>();
            
            foreach (var item in inputList)
            {
                if (cancellationToken.IsCancellationRequested)
                    break;
                
                if (EvaluateCondition(item, condition))
                {
                    result.Add(item);
                }
            }
            
            context.SetMetric($"{node.Name}.ItemsFiltered", 
                inputList.Count() - result.Count);
            
            return Result.Success<object?>(result);
        }
        catch (Exception ex)
        {
            return Result.Failure<object?>(
                new Error("Filter.ExecutionFailed", ex.Message));
        }
    }
    
    private bool EvaluateCondition(object item, string condition)
    {
        // Simple condition evaluation
        // In production, use expression evaluator
        return true;
    }
    
    public async Task<r> ValidateAsync(Node node)
    {
        return await Task.FromResult(Result.Success());
    }
}

public class AggregateTransformExecutor : INodeExecutor
{
    public async Task<Result<object?>> ExecuteAsync(
        Node node,
        Dictionary<string, object?> inputData,
        ExecutionContext context,
        CancellationToken cancellationToken)
    {
        try
        {
            var operation = node.GetProperty<string>("Operation"); // Sum, Count, Avg, Max, Min
            var field = node.GetProperty<string>("Field");
            var input = inputData.GetValueOrDefault("input");
            
            if (input is not IEnumerable<Dictionary<string, object>> inputList)
            {
                return Result.Failure<object?>(
                    new Error("Aggregate.InvalidInput", "Input must be a list of dictionaries"));
            }
            
            object? result = operation?.ToLower() switch
            {
                "count" => inputList.Count(),
                "sum" => inputList.Sum(item => Convert.ToDouble(item.GetValueOrDefault(field, 0))),
                "avg" => inputList.Average(item => Convert.ToDouble(item.GetValueOrDefault(field, 0))),
                "max" => inputList.Max(item => Convert.ToDouble(item.GetValueOrDefault(field, 0))),
                "min" => inputList.Min(item => Convert.ToDouble(item.GetValueOrDefault(field, 0))),
                _ => null
            };
            
            return Result.Success(result);
        }
        catch (Exception ex)
        {
            return Result.Failure<object?>(
                new Error("Aggregate.ExecutionFailed", ex.Message));
        }
    }
    
    public async Task<r> ValidateAsync(Node node)
    {
        return await Task.FromResult(Result.Success());
    }
}
```

### SinkNodeExecutor.cs

```csharp
// Execution/Nodes/SinkNodeExecutor.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BahyWay.SharedKernel.Results;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.KGEditorWay.Execution.Nodes;

public class CsvSinkNodeExecutor : INodeExecutor
{
    public async Task<Result<object?>> ExecuteAsync(
        Node node,
        Dictionary<string, object?> inputData,
        ExecutionContext context,
        CancellationToken cancellationToken)
    {
        try
        {
            var filePath = node.GetProperty<string>("FilePath");
            var delimiter = node.GetProperty<string>("Delimiter") ?? ",";
            var includeHeader = node.GetProperty<bool>("IncludeHeader");
            var input = inputData.GetValueOrDefault("input");
            
            if (string.IsNullOrEmpty(filePath))
            {
                return Result.Failure<object?>(
                    new Error("CsvSink.NoFilePath", "File path is required"));
            }
            
            if (input is not IEnumerable<Dictionary<string, object>> data)
            {
                return Result.Failure<object?>(
                    new Error("CsvSink.InvalidInput", "Input must be a list of dictionaries"));
            }
            
            var dataList = data.ToList();
            
            if (!dataList.Any())
            {
                return Result.Success<object?>(0);
            }
            
            var sb = new StringBuilder();
            
            // Write header
            if (includeHeader)
            {
                var headers = dataList[0].Keys;
                sb.AppendLine(string.Join(delimiter, headers));
            }
            
            // Write rows
            foreach (var row in dataList)
            {
                if (cancellationToken.IsCancellationRequested)
                    break;
                
                var values = row.Values.Select(v => v?.ToString() ?? "");
                sb.AppendLine(string.Join(delimiter, values));
            }
            
            await File.WriteAllTextAsync(filePath, sb.ToString(), cancellationToken);
            
            context.SetMetric($"{node.Name}.RowsWritten", dataList.Count);
            
            return Result.Success<object?>(dataList.Count);
        }
        catch (Exception ex)
        {
            return Result.Failure<object?>(
                new Error("CsvSink.ExecutionFailed", ex.Message));
        }
    }
    
    public async Task<r> ValidateAsync(Node node)
    {
        var filePath = node.GetProperty<string>("FilePath");
        
        if (string.IsNullOrEmpty(filePath))
        {
            return Result.Failure(
                new Error("CsvSink.Validation", "File path is required"));
        }
        
        return await Task.FromResult(Result.Success());
    }
}

public class LoggerSinkNodeExecutor : INodeExecutor
{
    private readonly IExecutionLogger _logger;
    
    public LoggerSinkNodeExecutor(IExecutionLogger logger)
    {
        _logger = logger;
    }
    
    public async Task<Result<object?>> ExecuteAsync(
        Node node,
        Dictionary<string, object?> inputData,
        ExecutionContext context,
        CancellationToken cancellationToken)
    {
        try
        {
            var input = inputData.GetValueOrDefault("input");
            var logLevel = node.GetProperty<string>("LogLevel") ?? "Info";
            
            var message = $"[{node.Name}] {input}";
            
            switch (logLevel.ToLower())
            {
                case "debug":
                    _logger.LogDebug(message);
                    break;
                case "info":
                    _logger.LogInfo(message);
                    break;
                case "warning":
                    _logger.LogWarning(message);
                    break;
                case "error":
                    _logger.LogError(message);
                    break;
            }
            
            return await Task.FromResult(Result.Success<object?>(input));
        }
        catch (Exception ex)
        {
            return Result.Failure<object?>(
                new Error("Logger.ExecutionFailed", ex.Message));
        }
    }
    
    public async Task<r> ValidateAsync(Node node)
    {
        return await Task.FromResult(Result.Success());
    }
}
```

---

## 📊 Data Flow Management

```csharp
// Execution/DataFlow/DataFlowManager.cs
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;
using BahyWay.KGEditorWay.Domain.Aggregates.Graph;

namespace BahyWay.KGEditorWay.Execution.DataFlow;

public interface IDataFlowManager
{
    Task<Dictionary<string, object?>> GetInputDataAsync(NodeId nodeId);
    Task SetOutputDataAsync(NodeId nodeId, object? data);
    void Clear();
}

public class DataFlowManager : IDataFlowManager
{
    private readonly ConcurrentDictionary<NodeId, object?> _nodeOutputs = new();
    private readonly Graph _graph;
    
    public DataFlowManager(Graph graph)
    {
        _graph = graph;
    }
    
    public async Task<Dictionary<string, object?>> GetInputDataAsync(NodeId nodeId)
    {
        var inputData = new Dictionary<string, object?>();
        
        // Get all edges that target this node
        var incomingEdges = _graph.Edges.Where(e => e.TargetNodeId == nodeId);
        
        foreach (var edge in incomingEdges)
        {
            if (_nodeOutputs.TryGetValue(edge.SourceNodeId, out var data))
            {
                // Use port name as key, or "input" as default
                var key = edge.SourcePortId?.ToString() ?? "input";
                inputData[key] = data;
            }
        }
        
        return await Task.FromResult(inputData);
    }
    
    public async Task SetOutputDataAsync(NodeId nodeId, object? data)
    {
        _nodeOutputs[nodeId] = data;
        await Task.CompletedTask;
    }
    
    public void Clear()
    {
        _nodeOutputs.Clear();
    }
}
```

---

**Part 6 continues with Debugger, Execution Context, and UI integration...**

**Continue to Part 6B?**
