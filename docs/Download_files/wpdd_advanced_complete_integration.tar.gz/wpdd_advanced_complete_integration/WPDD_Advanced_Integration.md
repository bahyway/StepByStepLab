# WPDD Advanced - Complete Integration Guide

## Project Structure

```
BahyWay.WPDD/
├── src/
│   ├── Domain/
│   │   ├── Entities/
│   │   │   ├── Pipeline.cs
│   │   │   ├── PipelineSegment.cs
│   │   │   ├── Defect.cs
│   │   │   └── DetectionResult.cs
│   │   ├── ValueObjects/
│   │   │   ├── GeoCoordinate.cs
│   │   │   ├── SpectralSignature.cs
│   │   │   ├── DefectSeverity.cs
│   │   │   └── ConfidenceScore.cs
│   │   └── Aggregates/
│   │       └── WaterNetworkAggregate.cs
│   │
│   ├── Application/
│   │   ├── Commands/
│   │   │   ├── ProcessSatelliteImage/
│   │   │   ├── ProcessHyperspectralImage/
│   │   │   └── FuseDetectionResults/
│   │   ├── Queries/
│   │   │   ├── GetNetworkStatus/
│   │   │   ├── GetDefectsByArea/
│   │   │   └── GetCriticalLeaks/
│   │   └── Interfaces/
│   │       ├── IImageProcessor.cs
│   │       ├── IDefectDetector.cs
│   │       ├── ISpectralAnalyzer.cs
│   │       └── IGraphRepository.cs
│   │
│   ├── Infrastructure/
│   │   ├── ML/
│   │   │   ├── YOLOv8Detector.cs
│   │   │   ├── SpectralAnalyzer.cs
│   │   │   └── DetectionFusion.cs
│   │   ├── Persistence/
│   │   │   ├── PostgreSQL/
│   │   │   └── TinkerPop/
│   │   └── Python/
│   │       └── PythonInterop.cs
│   │
│   ├── API/
│   │   ├── Controllers/
│   │   │   ├── DetectionController.cs
│   │   │   ├── GraphController.cs
│   │   │   └── VisualizationController.cs
│   │   └── Program.cs
│   │
│   └── WebUI/ (Optional - Blazor)
│       └── Components/
│
├── python/
│   ├── ml_service/
│   │   ├── __init__.py
│   │   ├── main.py (FastAPI server)
│   │   ├── models/
│   │   │   ├── yolo_detector.py
│   │   │   ├── spectral_analyzer.py
│   │   │   └── fusion_engine.py
│   │   ├── graph/
│   │   │   ├── tinkerpop_client.py
│   │   │   └── graph_builder.py
│   │   ├── visualization/
│   │   │   ├── networkx_viz.py
│   │   │   └── interactive_maps.py
│   │   └── utils/
│   │       ├── preprocessing.py
│   │       └── postprocessing.py
│   │
│   ├── notebooks/
│   │   ├── 01_SPy_Exploration.ipynb
│   │   ├── 02_YOLOv8_Training.ipynb
│   │   └── 03_Graph_Analysis.ipynb
│   │
│   └── tests/
│       ├── test_spectral.py
│       ├── test_detection.py
│       └── test_graph.py
│
├── docker/
│   ├── docker-compose.yml
│   ├── Dockerfile.api
│   ├── Dockerfile.ml
│   └── Dockerfile.visualization
│
├── scripts/
│   ├── setup_environment.sh
│   ├── download_sample_data.sh
│   └── train_model.sh
│
└── data/
    ├── satellite/
    ├── hyperspectral/
    ├── ground_truth/
    └── models/
```

## Technology Stack

### Backend (.NET 8)
- ASP.NET Core Web API
- Entity Framework Core (PostgreSQL)
- MediatR (CQRS)
- Hangfire (Background Jobs)
- Redis (Caching)
- Python.NET (Python Interop)

### ML/AI (Python 3.11)
- **Spectral Python (SPy)** - Hyperspectral analysis
- **YOLOv8 (Ultralytics)** - Object detection
- **PyTorch** - Deep learning
- **NumPy/SciPy** - Numerical computing
- **Rasterio** - Geospatial raster I/O
- **GDAL** - Geospatial data abstraction

### Graph Database
- **Apache TinkerPop (JanusGraph)** - Graph database
- **Gremlin.NET** - C# graph queries
- **gremlinpython** - Python graph queries

### Visualization
- **NetworkX** - Graph analysis and visualization
- **Folium** - Interactive maps
- **Plotly** - Interactive 3D visualizations
- **Matplotlib** - Static plots

### Infrastructure
- Docker & Docker Compose
- PostgreSQL + PostGIS
- Redis
- Apache Cassandra (JanusGraph backend)

## Key Features

1. **Multi-Modal Detection**: Combines RGB satellite imagery with hyperspectral data
2. **Real-Time Processing**: Processes imagery within minutes of acquisition
3. **Graph-Based Analysis**: Models entire water network with relationships
4. **Anomaly Detection**: Identifies leaks and defects using spectral signatures
5. **War Zone Resilience**: Works with partial data, damaged infrastructure
6. **Interactive Visualization**: 2D/3D network visualization with NetworkX
7. **Priority Scoring**: Ranks defects by humanitarian impact
8. **Temporal Analysis**: Tracks changes over time for damage assessment
