# BahyWay - Project Dependencies & Build Order

## 🏗️ Build Order Visual Guide

```
Phase 1: FOUNDATION (Week 1)
═══════════════════════════════════════════════════════════════
┌─────────────────────────────────────────────────────────────┐
│                                                               │
│  BahyWay.SharedKernel ⭐ BUILD THIS FIRST                    │
│  ════════════════════════════════════════════════════        │
│                                                               │
│  Domain/                                                      │
│  ├── Primitives/                                             │
│  │   ├── Entity.cs           ✅ ALL PROJECTS                 │
│  │   ├── Result.cs           ✅ ALL PROJECTS                 │
│  │   ├── ValueObject.cs      ✅ ALL PROJECTS                 │
│  │   └── Error.cs            ✅ ALL PROJECTS                 │
│  │                                                            │
│  ├── Entities/                                               │
│  │   └── AuditableEntity.cs  ✅ ALL PROJECTS                 │
│  │                                                            │
│  Application/                                                 │
│  ├── Abstractions/                                           │
│  │   ├── IApplicationLogger.cs        ✅ ALL                 │
│  │   ├── ICacheService.cs             ✅ ALL                 │
│  │   ├── IBackgroundJobService.cs     ✅ ALL                 │
│  │   ├── IFileStorageService.cs       ✅ ETL, Hire, Cemetery │
│  │   └── IFileWatcherService.cs       ✅ ETLway              │
│  │                                                            │
│  Infrastructure/                                              │
│  ├── Logging/               ✅ ALL PROJECTS                  │
│  ├── Caching/               ✅ ALL PROJECTS                  │
│  ├── BackgroundJobs/        ✅ ALL PROJECTS                  │
│  ├── Audit/                 ✅ ALL PROJECTS                  │
│  ├── FileWatcher/           ✅ ETLway (PRIMARY)              │
│  ├── FileStorage/           ✅ ETL, Hire, Cemetery, Forecast │
│  └── HealthChecks/          ✅ ALL PROJECTS                  │
│                                                               │
└─────────────────────────────────────────────────────────────┘


Phase 2: FIRST PROJECT (Week 2)
═══════════════════════════════════════════════════════════════
┌─────────────────────────────────────────────────────────────┐
│                                                               │
│  AlarmInsight ⭐ BUILD THIS SECOND                           │
│  ═══════════════════════════════════════════════════         │
│                                                               │
│  Why? Moderate complexity, tests all patterns                │
│                                                               │
│  ┌─────────────────────┐                                     │
│  │ AlarmInsight.Domain │  ← Depends on SharedKernel         │
│  └──────────┬──────────┘                                     │
│             │                                                 │
│  ┌──────────▼───────────────┐                                │
│  │ AlarmInsight.Application │ ← Depends on Domain            │
│  └──────────┬───────────────┘                                │
│             │                                                 │
│  ┌──────────▼─────────────────┐                              │
│  │ AlarmInsight.Infrastructure│ ← Depends on Application     │
│  └──────────┬─────────────────┘                              │
│             │                                                 │
│  ┌──────────▼──────┐                                         │
│  │ AlarmInsight.API│ ← Depends on Infrastructure            │
│  └─────────────────┘                                         │
│                                                               │
│  USES FROM SHARED:                                           │
│  ✅ Entity, Result, AuditableEntity                          │
│  ✅ Logging, Caching, Background Jobs                        │
│  ✅ Health Checks, Audit Interceptor                         │
│                                                               │
└─────────────────────────────────────────────────────────────┘


Phase 3: FILE PROCESSING (Week 3)
═══════════════════════════════════════════════════════════════
┌─────────────────────────────────────────────────────────────┐
│                                                               │
│  ETLway ⭐ BUILD THIS THIRD                                  │
│  ═══════════════════════                                     │
│                                                               │
│  Why? Tests FileWatcher, heavy background job usage          │
│                                                               │
│  ┌─────────────┐                                             │
│  │ ETLway.Domain│  ← Depends on SharedKernel                │
│  └──────┬──────┘                                             │
│         │                                                     │
│  ┌──────▼─────────────┐                                      │
│  │ ETLway.Application │ ← Depends on Domain                 │
│  └──────┬─────────────┘                                      │
│         │                                                     │
│  ┌──────▼───────────────┐                                    │
│  │ ETLway.Infrastructure│ ← Depends on Application           │
│  └──────┬───────────────┘                                    │
│         │                                                     │
│  ┌──────▼─────┐                                              │
│  │ ETLway.API │ ← Depends on Infrastructure                 │
│  └────────────┘                                              │
│                                                               │
│  USES FROM SHARED (HEAVILY):                                 │
│  ✅ FileWatcher ⭐ PRIMARY USER                              │
│  ✅ FileStorage ⭐ PRIMARY USER                              │
│  ✅ Background Jobs ⭐ HEAVY USAGE                           │
│  ✅ Caching, Logging, Audit                                  │
│                                                               │
│  NEW PATTERN INTRODUCED:                                     │
│  📁 File Detection → Background Processing → Archive         │
│                                                               │
└─────────────────────────────────────────────────────────────┘


Phase 4+: REMAINING PROJECTS (Weeks 4-12)
═══════════════════════════════════════════════════════════════

┌────────────────────┐  ┌────────────────────┐
│  SmartForesight    │  │  HireWay           │
│  (Week 4-5)        │  │  (Week 6-7)        │
├────────────────────┤  ├────────────────────┤
│ Focus:             │  │ Focus:             │
│ • ML Model Storage │  │ • File Storage     │
│ • Background Jobs  │  │ • Background Jobs  │
│ • Heavy Caching    │  │ • Audit (critical) │
└────────────────────┘  └────────────────────┘

┌────────────────────┐  ┌────────────────────┐
│  NajafCemetery     │  │  SteerView         │
│  (Week 8-9)        │  │  (Week 10-11)      │
├────────────────────┤  ├────────────────────┤
│ Focus:             │  │ Focus:             │
│ • PostGIS/H3       │  │ • Geospatial Cache │
│ • File Storage     │  │ • Heavy Caching    │
│ • Audit (critical) │  │ • Event Bus        │
└────────────────────┘  └────────────────────┘

┌────────────────────┐
│  SSISight          │
│  (Week 12)         │
├────────────────────┤
│ Focus:             │
│ • SSIS Analysis    │
│ • Caching          │
│ • Background Jobs  │
└────────────────────┘

```

---

## 📊 Dependency Matrix

```
Component Reusability Matrix
════════════════════════════════════════════════════════════════

Component           │ Alarm│ ETL │Forecast│ Hire│Cemetery│ Steer│ SSIS
────────────────────┼──────┼─────┼────────┼─────┼────────┼──────┼─────
Entity              │  ✅  │ ✅  │   ✅   │ ✅  │   ✅   │  ✅  │ ✅
Result              │  ✅  │ ✅  │   ✅   │ ✅  │   ✅   │  ✅  │ ✅
ValueObject         │  ✅  │ ✅  │   ✅   │ ✅  │   ✅   │  ✅  │ ✅
AuditableEntity     │  ✅  │ ✅  │   ✅   │ 🔴  │   🔴   │  ✅  │ ✅
────────────────────┼──────┼─────┼────────┼─────┼────────┼──────┼─────
Logging             │  ✅  │ ✅  │   ✅   │ ✅  │   ✅   │  ✅  │ ✅
Correlation ID      │  ✅  │ ✅  │   ✅   │ ✅  │   ✅   │  ✅  │ ✅
────────────────────┼──────┼─────┼────────┼─────┼────────┼──────┼─────
Caching             │  ✅  │ ✅  │   🔴   │ ✅  │   🔴   │  🔴  │ ✅
Background Jobs     │  ✅  │ 🔴  │   🔴   │ ✅  │   ✅   │  ✅  │ ✅
Health Checks       │  ✅  │ ✅  │   ✅   │ ✅  │   ✅   │  ✅  │ ✅
Audit Interceptor   │  ✅  │ ✅  │   ✅   │ 🔴  │   🔴   │  ✅  │ ✅
────────────────────┼──────┼─────┼────────┼─────┼────────┼──────┼─────
FileWatcher         │  ❌  │ 🔴  │   ❌   │ ❌  │   ❌   │  ❌  │ ❌
FileStorage         │  ❌  │ 🔴  │   ✅   │ 🔴  │   🔴   │  ❌  │ ❌
Event Bus           │  ✅  │ ✅  │   ✅   │ ✅  │   ✅   │  🔴  │ ✅
────────────────────┼──────┼─────┼────────┼─────┼────────┼──────┼─────

Legend:
✅ = Used
🔴 = Heavily Used / Critical
❌ = Not Used
```

---

## 🎯 Reference Project Matrix

```
When Building This:     Reference This:           Focus On:
═══════════════════════════════════════════════════════════════
AlarmInsight            SharedKernel              Core patterns
ETLway                  AlarmInsight              + FileWatcher
SmartForesight          ETLway                    + ML workflows
HireWay                 AlarmInsight + ETLway     + File handling
NajafCemetery           HireWay                   + Geospatial
SteerView               NajafCemetery             + Advanced GIS
SSISight                AlarmInsight              + SSIS specifics
```

---

## 📦 NuGet Package Dependencies

```
Layer Dependencies (All Projects Follow This):
═══════════════════════════════════════════════════════════════

┌─────────────────────────────────────────────────────────────┐
│ API Layer (ASP.NET Core)                                     │
│ ─────────────────────────────────────────────────────────── │
│ Packages:                                                     │
│ • Swashbuckle.AspNetCore                                     │
│ • Microsoft.AspNetCore.Mvc.Versioning                        │
│ • Serilog.AspNetCore                                         │
└──────────────────────────┬──────────────────────────────────┘
                           │ depends on
                           ▼
┌─────────────────────────────────────────────────────────────┐
│ Infrastructure Layer                                         │
│ ─────────────────────────────────────────────────────────── │
│ Packages:                                                     │
│ • Npgsql.EntityFrameworkCore.PostgreSQL                      │
│ • StackExchange.Redis                                        │
│ • Hangfire.PostgreSql                                        │
│ • MassTransit.RabbitMQ                                       │
└──────────────────────────┬──────────────────────────────────┘
                           │ depends on
                           ▼
┌─────────────────────────────────────────────────────────────┐
│ Application Layer                                            │
│ ─────────────────────────────────────────────────────────── │
│ Packages:                                                     │
│ • MediatR                                                     │
│ • FluentValidation                                           │
│ • AutoMapper (if needed)                                     │
└──────────────────────────┬──────────────────────────────────┘
                           │ depends on
                           ▼
┌─────────────────────────────────────────────────────────────┐
│ Domain Layer                                                 │
│ ─────────────────────────────────────────────────────────── │
│ Packages:                                                     │
│ • None (Pure domain logic)                                   │
│ • Only references: BahyWay.SharedKernel                      │
└──────────────────────────┬──────────────────────────────────┘
                           │ depends on
                           ▼
┌─────────────────────────────────────────────────────────────┐
│ BahyWay.SharedKernel                                         │
│ ─────────────────────────────────────────────────────────── │
│ Packages:                                                     │
│ • Serilog                                                     │
│ • MediatR                                                     │
│ • FluentValidation                                           │
│ • Microsoft.Extensions.* (DI, Logging, Config)              │
└─────────────────────────────────────────────────────────────┘
```

---

## 🏃 Build & Run Order

```
Development Workflow:
═══════════════════════════════════════════════════════════════

1. Start Infrastructure (Debian VDI)
   ┌──────────────────────────────────────┐
   │ docker-compose up -d                  │
   │                                       │
   │ Starts:                               │
   │ • PostgreSQL (5432)                   │
   │ • Redis (6379)                        │
   │ • RabbitMQ (5672, 15672)              │
   │ • Seq (5341)                          │
   └──────────────────────────────────────┘
                    ⬇️
2. Build SharedKernel (VS 2022)
   ┌──────────────────────────────────────┐
   │ cd BahyWay.SharedKernel               │
   │ dotnet build                          │
   │                                       │
   │ Must succeed before building projects │
   └──────────────────────────────────────┘
                    ⬇️
3. Build Project Layers (Bottom-Up)
   ┌──────────────────────────────────────┐
   │ cd AlarmInsight.Domain                │
   │ dotnet build                          │
   └──────────────────────────────────────┘
                    ⬇️
   ┌──────────────────────────────────────┐
   │ cd AlarmInsight.Application           │
   │ dotnet build                          │
   └──────────────────────────────────────┘
                    ⬇️
   ┌──────────────────────────────────────┐
   │ cd AlarmInsight.Infrastructure        │
   │ dotnet build                          │
   └──────────────────────────────────────┘
                    ⬇️
   ┌──────────────────────────────────────┐
   │ cd AlarmInsight.API                   │
   │ dotnet build                          │
   │ dotnet run                            │
   └──────────────────────────────────────┘
                    ⬇️
4. Verify Running
   ┌──────────────────────────────────────┐
   │ API: http://localhost:5000            │
   │ Swagger: http://localhost:5000/swagger│
   │ Health: http://localhost:5000/health  │
   │ Hangfire: http://localhost:5000/hangfire│
   └──────────────────────────────────────┘
```

---

## 🎯 Critical Success Path

```
Week 1: Foundation
══════════════════════════════════════════════════════════
Day 1-2:  SharedKernel.Domain       ✅ Must Complete
Day 3-4:  SharedKernel.Infrastructure ✅ Must Complete
Day 5-7:  AlarmInsight.Domain       ✅ Must Complete

⚠️  CHECKPOINT: Can create entities, use Result pattern


Week 2: First Working Project
══════════════════════════════════════════════════════════
Day 8-10:  AlarmInsight.Infrastructure ✅ Must Complete
Day 11-12: AlarmInsight.API           ✅ Must Complete
Day 13-14: Testing & Docker           ✅ Must Complete

⚠️  CHECKPOINT: Can create/process alarms via API


Week 3: File Processing
══════════════════════════════════════════════════════════
Day 15-17: ETLway.Domain + Application ✅ Must Complete
Day 18-19: ETLway FileWatcher         ✅ Must Complete
Day 20-21: Testing & Refinement       ✅ Must Complete

⚠️  CHECKPOINT: FileWatcher detects files, triggers jobs


Week 4-12: Scale to All Projects
══════════════════════════════════════════════════════════
• Each project: 1-2 weeks
• Reuse established patterns
• Each project gets easier
• By Week 12: Complete ecosystem

🎉 FINAL CHECKPOINT: All 8 projects working
```

---

## 📋 Pre-Flight Checklist

### Before Starting Each New Project:

```
Planning Phase:
☐ Review SharedKernel documentation
☐ Identify which shared components needed
☐ Review reference project (previous project)
☐ Create project structure
☐ Add project to solution
☐ Set up project references

Domain Phase:
☐ Identify aggregates
☐ Inherit from Entity/AuditableEntity
☐ Use Result pattern for validation
☐ Add domain events
☐ Write unit tests

Application Phase:
☐ Define commands/queries
☐ Create handlers
☐ Use IApplicationLogger
☐ Use ICacheService if needed
☐ Use IBackgroundJobService if needed
☐ Write integration tests

Infrastructure Phase:
☐ Create DbContext with AuditInterceptor
☐ Configure EF Core
☐ Implement repositories
☐ Add migrations
☐ Configure DI container

API Phase:
☐ Configure logging (Serilog)
☐ Configure caching (Redis)
☐ Configure background jobs (Hangfire)
☐ Add health checks
☐ Configure Swagger
☐ Add correlation ID middleware

Testing Phase:
☐ All unit tests pass
☐ All integration tests pass
☐ API tests with Postman/curl
☐ Health endpoint returns green
☐ Logs visible in Seq
☐ Jobs processing in Hangfire

Deployment Phase:
☐ Docker configuration ready
☐ Connection strings configured
☐ Environment variables set
☐ Database migrations applied
☐ Smoke tests pass
```

---

**REMEMBER: Build SharedKernel first, validate with AlarmInsight, then replicate!**
